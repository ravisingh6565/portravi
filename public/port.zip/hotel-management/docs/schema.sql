-- Hotel Management System Database Schema
-- Run this script to create the database and tables manually (JPA will auto-create on first run)

CREATE DATABASE IF NOT EXISTS hotel_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hotel_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    user_id VARCHAR(20) PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    mobile VARCHAR(20) NOT NULL UNIQUE,
    address TEXT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('ROLE_ADMIN', 'ROLE_CUSTOMER', 'ROLE_STAFF') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    failed_attempts INT DEFAULT 0,
    account_locked BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Rooms Table
CREATE TABLE IF NOT EXISTS rooms (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(20) NOT NULL UNIQUE,
    room_type ENUM('STANDARD', 'DELUXE', 'SUITE', 'EXECUTIVE', 'PRESIDENTIAL') NOT NULL,
    room_status ENUM('AVAILABLE', 'OCCUPIED', 'MAINTENANCE', 'BLOCKED') DEFAULT 'AVAILABLE',
    price_per_night DECIMAL(10,2) NOT NULL,
    max_adults INT NOT NULL DEFAULT 2,
    max_children INT NOT NULL DEFAULT 0,
    amenities TEXT,
    description VARCHAR(500),
    floor_number INT NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Bookings Table
CREATE TABLE IF NOT EXISTS bookings (
    booking_id VARCHAR(20) PRIMARY KEY,
    customer_id VARCHAR(20) NOT NULL,
    room_id BIGINT NOT NULL,
    check_in_date DATE NOT NULL,
    check_out_date DATE NOT NULL,
    total_nights INT NOT NULL,
    adults INT NOT NULL DEFAULT 1,
    children INT NOT NULL DEFAULT 0,
    special_request VARCHAR(500),
    booking_status ENUM('PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED', 'MODIFIED') DEFAULT 'PENDING',
    total_amount DECIMAL(10,2),
    tax_amount DECIMAL(10,2),
    grand_total DECIMAL(10,2),
    refund_amount DECIMAL(10,2),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(user_id),
    FOREIGN KEY (room_id) REFERENCES rooms(id)
);

-- Payments Table
CREATE TABLE IF NOT EXISTS payments (
    transaction_id VARCHAR(20) PRIMARY KEY,
    booking_id VARCHAR(20) NOT NULL,
    payment_method VARCHAR(50),
    amount_paid DECIMAL(10,2),
    payment_status ENUM('PENDING', 'SUCCESS', 'FAILED', 'REFUNDED', 'PARTIAL_REFUND') NOT NULL,
    cardholder_name VARCHAR(100),
    card_last_four VARCHAR(4),
    failure_reason VARCHAR(255),
    payment_date DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
);

-- Bills Table
CREATE TABLE IF NOT EXISTS bills (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(30) UNIQUE,
    booking_id VARCHAR(20) NOT NULL UNIQUE,
    room_charges DECIMAL(10,2),
    additional_charges DECIMAL(10,2) DEFAULT 0,
    discount_amount DECIMAL(10,2) DEFAULT 0,
    tax_percentage DECIMAL(5,2) DEFAULT 18.00,
    tax_amount DECIMAL(10,2),
    total_amount DECIMAL(10,2),
    additional_items TEXT,
    notes VARCHAR(500),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
);

-- Complaints Table
CREATE TABLE IF NOT EXISTS complaints (
    complaint_id VARCHAR(20) PRIMARY KEY,
    customer_id VARCHAR(20) NOT NULL,
    assigned_to VARCHAR(20),
    booking_id VARCHAR(20),
    category VARCHAR(100) NOT NULL,
    title VARCHAR(100) NOT NULL,
    description VARCHAR(500) NOT NULL,
    contact_preference VARCHAR(50),
    status ENUM('OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED', 'REOPENED') DEFAULT 'OPEN',
    resolution_notes TEXT,
    expected_resolution_date DATE,
    resolved_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(user_id),
    FOREIGN KEY (assigned_to) REFERENCES users(user_id)
);

-- Insert default sample rooms
INSERT IGNORE INTO rooms (room_number, room_type, room_status, price_per_night, max_adults, max_children, amenities, description, floor_number) VALUES
('S101', 'STANDARD', 'AVAILABLE', 2500.00, 2, 1, 'WiFi, AC, TV, Room Service', 'Comfortable standard room', 1),
('S102', 'STANDARD', 'AVAILABLE', 2500.00, 2, 1, 'WiFi, AC, TV, Room Service', 'Comfortable standard room', 1),
('D201', 'DELUXE', 'AVAILABLE', 5000.00, 2, 2, 'WiFi, AC, TV, Mini Bar, Balcony', 'Luxurious deluxe room with balcony', 2),
('D202', 'DELUXE', 'AVAILABLE', 5000.00, 2, 2, 'WiFi, AC, TV, Mini Bar, Balcony', 'Luxurious deluxe room with balcony', 2),
('SU301', 'SUITE', 'AVAILABLE', 10000.00, 3, 2, 'WiFi, AC, TV, Jacuzzi, Living Room, Mini Bar', 'Premium suite with jacuzzi', 3),
('SU302', 'SUITE', 'AVAILABLE', 10000.00, 3, 2, 'WiFi, AC, TV, Jacuzzi, Living Room, Mini Bar', 'Premium suite with jacuzzi', 3),
('E401', 'EXECUTIVE', 'AVAILABLE', 15000.00, 4, 2, 'WiFi, AC, TV, Business Lounge, Jacuzzi, Butler', 'Executive suite with butler service', 4),
('P501', 'PRESIDENTIAL', 'AVAILABLE', 25000.00, 6, 3, 'All Amenities, Private Pool, Butler, Chef, Limousine', 'Presidential suite - the pinnacle of luxury', 5);
