# 🏨 Grand Hotel Management System

A complete full-stack Hotel Management System built with **Spring Boot 3.2** (Backend) and **Angular 17** (Frontend).

---

## 🚀 Tech Stack

### Backend
- Spring Boot 3.2 | Java 17
- Spring Security (Session-based, JSESSIONID)
- MySQL + JPA/Hibernate
- BCryptPasswordEncoder
- iText PDF for invoice generation
- Apache Commons CSV for bulk upload
- Global Exception Handling | DTO pattern | Layered Architecture

### Frontend
- Angular 17 (Standalone components)
- Angular Material UI
- Tailwind CSS
- Reactive Forms | HTTP Interceptor | Angular Guards
- Role-based routing

---

## ⚡ Quick Start

### Prerequisites
- Java 17+
- Maven 3.8+
- MySQL 8.0+
- Node.js 18+ & npm 9+
- Angular CLI 17

---

## 🔧 Backend Setup

### 1. Configure MySQL
```sql
CREATE DATABASE hotel_db;
-- or run the schema:
mysql -u root -p < docs/schema.sql
```

### 2. Update application-dev.properties
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/hotel_db?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=YOUR_MYSQL_USERNAME
spring.datasource.password=YOUR_MYSQL_PASSWORD
```

### 3. Build & Run
```bash
cd backend
mvn clean install
mvn spring-boot:run
# OR
java -jar target/hotel-management-1.0.0.jar
```

Backend runs at: **http://localhost:8080**

### Default Users (auto-created)
| Role | Username | Password |
|------|----------|----------|
| Admin | admin | admin |
| Staff | staff1 | Staff@123 |

---

## 🎨 Frontend Setup

### 1. Install Dependencies
```bash
cd frontend
npm install
```

### 2. Run Development Server
```bash
ng serve
# OR
npm start
```

Frontend runs at: **http://localhost:4200**

---

## 📁 Project Structure

```
hotel-management/
├── backend/
│   ├── src/main/java/com/hotel/
│   │   ├── config/           # Security, CORS, Data initialization
│   │   ├── controller/       # REST controllers
│   │   ├── dto/              # Request/Response DTOs
│   │   │   ├── request/
│   │   │   └── response/
│   │   ├── entity/           # JPA entities
│   │   ├── enums/            # Enumerations
│   │   ├── exception/        # Custom exceptions & global handler
│   │   ├── repository/       # Spring Data JPA repositories
│   │   ├── security/         # UserDetailsService
│   │   ├── service/impl/     # Business logic services
│   │   └── util/             # ID generators, mappers
│   └── src/main/resources/
│       ├── application.properties
│       └── application-dev.properties
│
├── frontend/
│   └── src/app/
│       ├── components/
│       │   ├── auth/         # Login, Register, Profile
│       │   ├── booking/      # Book, Pay, My Bookings, Detail
│       │   ├── rooms/        # Search Rooms
│       │   ├── complaints/   # Register, Track
│       │   ├── admin/        # Dashboard, Rooms, Bookings, Customers, Bills, Complaints
│       │   ├── staff/        # Staff Complaints
│       │   └── shared/       # Navbar, Footer, Contact
│       ├── guards/           # Auth, Admin, Staff, Guest guards
│       ├── interceptors/     # HTTP interceptor (credentials, 401 handling)
│       ├── models/           # TypeScript interfaces
│       └── services/         # API services
│
└── docs/
    └── schema.sql
```

---

## 🔌 API Documentation

### Authentication
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | /api/auth/register | Public | Register new customer |
| POST | /api/auth/login | Public | Login & create session |
| POST | /api/auth/logout | Authenticated | Logout & invalidate session |
| GET | /api/auth/me | Authenticated | Get current user |

### Rooms
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | /api/rooms/available | Public | Search available rooms |
| GET | /api/rooms/search | Public | Filter/search all rooms |
| GET | /api/rooms/{id} | Authenticated | Get room details |
| POST | /api/rooms | ADMIN | Add new room |
| PUT | /api/rooms/{id} | ADMIN | Update room |
| PATCH | /api/rooms/{id}/status | ADMIN | Change room status |
| POST | /api/rooms/bulk-upload | ADMIN | CSV bulk upload |
| GET | /api/rooms/csv-template | ADMIN | Download CSV template |

### Bookings
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | /api/bookings | Customer | Create booking |
| GET | /api/bookings/my | Customer | My bookings |
| GET | /api/bookings/my/upcoming | Customer | Upcoming bookings |
| GET | /api/bookings/my/past | Customer | Past bookings |
| GET | /api/bookings/{id} | Customer/Admin | Get booking |
| PUT | /api/bookings/{id}/modify | Customer | Modify booking |
| PATCH | /api/bookings/{id}/cancel | Customer | Cancel booking |
| GET | /api/bookings | ADMIN | All bookings (paginated) |
| PATCH | /api/bookings/admin/{id}/cancel | ADMIN | Admin cancel |
| POST | /api/bookings/admin/create/{customerId} | ADMIN | Manual reservation |
| PUT | /api/bookings/admin/{id} | ADMIN | Admin update booking |

### Payments
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | /api/payments/process | Customer | Process payment (80% success simulation) |
| GET | /api/payments/booking/{bookingId} | Authenticated | Get payment by booking |
| GET | /api/payments | ADMIN | All payments (paginated) |
| GET | /api/payments/invoice/{bookingId} | Authenticated | Download PDF invoice |

### Complaints
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | /api/complaints | Customer | Register complaint |
| GET | /api/complaints/my | Customer | My complaints |
| GET | /api/complaints/{id} | Authenticated | Get complaint |
| PATCH | /api/complaints/{id}/confirm-resolution | Customer | Confirm resolved |
| PATCH | /api/complaints/{id}/reopen | Customer | Reopen complaint |
| GET | /api/complaints | ADMIN | All complaints |
| PATCH | /api/complaints/admin/{id}/assign | ADMIN | Assign to staff |
| PATCH | /api/complaints/admin/{id}/status | Admin/Staff | Update status |
| GET | /api/complaints/staff/assigned | Staff | Assigned complaints |

### Users
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | /api/users/profile | Authenticated | Get profile |
| PUT | /api/users/profile | Authenticated | Update profile |
| GET | /api/users/customers | ADMIN | List customers |
| GET | /api/users/staff | ADMIN | List staff |
| POST | /api/users/admin/create-customer | ADMIN | Create customer |
| POST | /api/users/admin/create-staff | ADMIN | Create staff |
| PATCH | /api/users/admin/{id}/reset-password | ADMIN | Reset password |
| PATCH | /api/users/admin/{id}/toggle-status | ADMIN | Activate/deactivate |

### Admin Dashboard & Bills
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | /api/admin/dashboard | ADMIN | Dashboard stats & charts |
| GET | /api/bills | ADMIN | All bills |
| GET | /api/bills/booking/{bookingId} | Authenticated | Bill by booking |
| PATCH | /api/bills/booking/{bookingId}/add-items | ADMIN | Add bill items |

---

## ✅ User Stories Coverage

| US | Story | Status |
|----|-------|--------|
| US001 | Customer Registration | ✅ |
| US002 | Login with session & account lock | ✅ |
| US003 | Homepage with personalized welcome | ✅ |
| US004 | Search Room Availability | ✅ |
| US005 | Book Room | ✅ |
| US006 | Pay Bill (dummy, 80/20 simulation) | ✅ |
| US007 | Generate PDF Invoice | ✅ |
| US008 | Booking History (upcoming/past) | ✅ |
| US009 | Modify Reservation (24h cutoff) | ✅ |
| US010 | Cancel Booking (free/partial/no refund) | ✅ |
| US011 | Register Complaint | ✅ |
| US012 | Track Complaint | ✅ |
| US013 | Update Profile | ✅ |
| US014 | Admin Dashboard (charts & stats) | ✅ |
| US015 | Manage Rooms (CRUD, filter, sort) | ✅ |
| US016 | Add Rooms + CSV Bulk Upload | ✅ |
| US017 | Manage Reservations (manual create) | ✅ |
| US018 | Search Reservations | ✅ |
| US019 | Manage Customer Accounts | ✅ |
| US020 | Search Bills | ✅ |
| US021 | Manage Bills (add items, taxes) | ✅ |
| US022 | Manage Complaints (Admin) | ✅ |
| US023 | Manage Complaints (Staff) | ✅ |

---

## 🔐 Security Features

- Session-based authentication (JSESSIONID cookie)
- BCrypt password encryption
- Role-based access control (RBAC)
- Account lock after 5 failed login attempts
- CSRF disabled for API (Angular SPA)
- CORS configured for localhost:4200
- Angular HTTP Interceptor with credentials
- Auth guards for protected routes

---

## 📱 Responsive Design

- Mobile (< 600px): Single column layouts
- Tablet (600-960px): 2-column grids
- Desktop (> 960px): Full multi-column layouts

---

## 🎯 Key Features

1. **PDF Invoice Generation** using iText with hotel branding
2. **CSV Bulk Room Upload** with template download
3. **Dummy Payment** - 80% success / 20% failure simulation
4. **Refund Logic** - Full (7+ days), 50% (3-6 days), No refund (<3 days)
5. **24-hour modification cutoff** for bookings
6. **Pagination, Sorting & Filtering** throughout
7. **Static local room images** (SVG fallback)
8. **Auto-generated IDs** for bookings, users, complaints, transactions
