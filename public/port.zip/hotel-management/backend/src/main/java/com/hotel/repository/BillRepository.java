package com.hotel.repository;

import com.hotel.entity.Bill;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.Optional;

public interface BillRepository extends JpaRepository<Bill, Long> {
    Optional<Bill> findByBookingBookingId(String bookingId);
    Optional<Bill> findByInvoiceNumber(String invoiceNumber);

    @Query("SELECT b FROM Bill b WHERE " +
           "(:search IS NULL OR LOWER(b.invoiceNumber) LIKE LOWER(CONCAT('%',:search,'%')) OR " +
           "LOWER(b.booking.bookingId) LIKE LOWER(CONCAT('%',:search,'%')) OR " +
           "LOWER(b.booking.customer.customerName) LIKE LOWER(CONCAT('%',:search,'%')))")
    Page<Bill> findWithFilters(@Param("search") String search, Pageable pageable);
}
