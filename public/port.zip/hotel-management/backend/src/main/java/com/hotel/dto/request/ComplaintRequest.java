package com.hotel.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ComplaintRequest {

    @NotBlank(message = "Category is required")
    private String category;

    private String bookingId;

    @NotBlank(message = "Title is required")
    @Size(min = 10, max = 100, message = "Title must be 10-100 characters")
    private String title;

    @NotBlank(message = "Description is required")
    @Size(min = 20, max = 500, message = "Description must be 20-500 characters")
    private String description;

    @NotBlank(message = "Contact preference is required")
    private String contactPreference;
}
