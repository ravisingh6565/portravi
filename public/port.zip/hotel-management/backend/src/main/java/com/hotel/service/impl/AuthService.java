package com.hotel.service.impl;

import com.hotel.dto.request.LoginRequest;
import com.hotel.dto.request.RegisterRequest;
import com.hotel.dto.response.UserResponse;
import com.hotel.entity.User;
import com.hotel.enums.Role;
import com.hotel.exception.BusinessException;
import com.hotel.exception.DuplicateResourceException;
import com.hotel.repository.UserRepository;
import com.hotel.util.IdGenerator;
import com.hotel.util.MapperUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;

    @Transactional
    public UserResponse register(RegisterRequest request) {
        if (!request.getPassword().equals(request.getConfirmPassword())) {
            throw new BusinessException("Passwords do not match");
        }
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new DuplicateResourceException("Username already exists");
        }
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email already registered");
        }
        if (userRepository.existsByMobile(request.getMobile())) {
            throw new DuplicateResourceException("Mobile number already registered");
        }

        User user = User.builder()
                .userId(IdGenerator.generateUserId())
                .customerName(request.getCustomerName())
                .email(request.getEmail())
                .mobile(request.getMobile())
                .address(request.getAddress())
                .username(request.getUsername())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(Role.ROLE_CUSTOMER)
                .active(true)
                .build();

        user = userRepository.save(user);
        return MapperUtil.toUserResponse(user);
    }

    public UserResponse login(LoginRequest request, HttpServletRequest httpRequest) {
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new BusinessException("Invalid username or password"));

        if (user.isAccountLocked()) {
            throw new BusinessException("Account is locked. Please contact support.");
        }

        if (!user.isActive()) {
            throw new BusinessException("Account is deactivated. Please contact support.");
        }

        try {
            UsernamePasswordAuthenticationToken authToken =
                    new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword());
            Authentication auth = authenticationManager.authenticate(authToken);
            SecurityContextHolder.getContext().setAuthentication(auth);

            HttpSession session = httpRequest.getSession(true);
            session.setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY,
                    SecurityContextHolder.getContext());

            // Reset failed attempts
            user.setFailedAttempts(0);
            userRepository.save(user);

            return MapperUtil.toUserResponse(user);
        } catch (BadCredentialsException e) {
            int attempts = user.getFailedAttempts() + 1;
            user.setFailedAttempts(attempts);
            if (attempts >= 5) {
                user.setAccountLocked(true);
            }
            userRepository.save(user);
            if (user.isAccountLocked()) {
                throw new BusinessException("Account locked after 5 failed attempts");
            }
            throw new BusinessException("Invalid username or password. Attempts: " + attempts + "/5");
        }
    }

    public void logout(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        SecurityContextHolder.clearContext();
    }

    public UserResponse getCurrentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || "anonymousUser".equals(auth.getPrincipal())) {
            throw new BusinessException("Not authenticated");
        }
        return userRepository.findByUsername(auth.getName())
                .map(MapperUtil::toUserResponse)
                .orElseThrow(() -> new BusinessException("User not found"));
    }
}
