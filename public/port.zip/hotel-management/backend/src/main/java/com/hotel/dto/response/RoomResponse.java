package com.hotel.dto.response;

import com.hotel.enums.RoomStatus;
import com.hotel.enums.RoomType;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class RoomResponse {
    private Long id;
    private String roomNumber;
    private RoomType roomType;
    private RoomStatus roomStatus;
    private BigDecimal pricePerNight;
    private int maxAdults;
    private int maxChildren;
    private String amenities;
    private String description;
    private int floorNumber;
    private LocalDateTime createdAt;
}
