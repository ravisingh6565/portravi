package com.hotel.dto.response;

import com.hotel.enums.PaymentStatus;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class PaymentResponse {
    private String transactionId;
    private String bookingId;
    private String paymentMethod;
    private BigDecimal amountPaid;
    private PaymentStatus paymentStatus;
    private String cardholderName;
    private String cardLastFour;
    private String failureReason;
    private LocalDateTime paymentDate;
    private String customerName;
}
