package com.hotel.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class RegisterRequest {

    @NotBlank(message = "Customer name is required")
    @Size(min = 3, message = "Name must be at least 3 characters")
    @Pattern(regexp = "^[a-zA-Z ]+$", message = "Name must contain alphabets only")
    private String customerName;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "Mobile is required")
    @Pattern(regexp = "^\\+[0-9]{1,3}[0-9]{8,10}$", message = "Mobile must have country code and 8-10 digits")
    private String mobile;

    @NotBlank(message = "Address is required")
    @Size(min = 10, message = "Address must be at least 10 characters")
    private String address;

    @NotBlank(message = "Username is required")
    @Size(min = 5, message = "Username must be at least 5 characters")
    @Pattern(regexp = "^\\S+$", message = "Username cannot contain spaces")
    private String username;

    @NotBlank(message = "Password is required")
    @Size(min = 8, message = "Password must be at least 8 characters")
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$",
             message = "Password must have 1 uppercase, 1 lowercase, 1 digit, 1 special character")
    private String password;

    @NotBlank(message = "Confirm password is required")
    private String confirmPassword;
}
