package com.hotel.enums;

public enum RoomStatus {
    AVAILABLE,
    OCCUPIED,
    MAINTENANCE,
    BLOCKED
}
