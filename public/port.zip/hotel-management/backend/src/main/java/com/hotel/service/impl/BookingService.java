package com.hotel.service.impl;

import com.hotel.dto.request.BookingRequest;
import com.hotel.dto.response.BookingResponse;
import com.hotel.entity.*;
import com.hotel.enums.BookingStatus;
import com.hotel.enums.RoomStatus;
import com.hotel.exception.BusinessException;
import com.hotel.exception.ResourceNotFoundException;
import com.hotel.repository.*;
import com.hotel.util.IdGenerator;
import com.hotel.util.MapperUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingService {

    private final BookingRepository bookingRepository;
    private final RoomRepository roomRepository;
    private final UserRepository userRepository;

    private static final BigDecimal TAX_RATE = new BigDecimal("0.18"); // 18% GST

    @Transactional
    public BookingResponse createBooking(BookingRequest request) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User customer = userRepository.findByUsername(username)
                .orElseThrow(() -> new BusinessException("Customer not found"));

        Room room = roomRepository.findById(request.getRoomId())
                .orElseThrow(() -> new ResourceNotFoundException("Room not found"));

        validateDates(request.getCheckInDate(), request.getCheckOutDate());

        long overlapping = bookingRepository.countOverlappingBookings(
                room.getId(), request.getCheckInDate(), request.getCheckOutDate());
        if (overlapping > 0) {
            throw new BusinessException("Room is not available for selected dates");
        }

        long nights = ChronoUnit.DAYS.between(request.getCheckInDate(), request.getCheckOutDate());
        BigDecimal totalAmount = room.getPricePerNight().multiply(BigDecimal.valueOf(nights));
        BigDecimal taxAmount = totalAmount.multiply(TAX_RATE);
        BigDecimal grandTotal = totalAmount.add(taxAmount);

        Booking booking = Booking.builder()
                .bookingId(IdGenerator.generateBookingId())
                .customer(customer)
                .room(room)
                .checkInDate(request.getCheckInDate())
                .checkOutDate(request.getCheckOutDate())
                .totalNights((int) nights)
                .adults(request.getAdults())
                .children(request.getChildren())
                .specialRequest(request.getSpecialRequest())
                .bookingStatus(BookingStatus.PENDING)
                .totalAmount(totalAmount)
                .taxAmount(taxAmount)
                .grandTotal(grandTotal)
                .build();

        return MapperUtil.toBookingResponse(bookingRepository.save(booking));
    }

    public List<BookingResponse> getMyBookings() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username).orElseThrow();
        return bookingRepository.findByCustomerUserId(user.getUserId())
                .stream().map(MapperUtil::toBookingResponse).collect(Collectors.toList());
    }

    public List<BookingResponse> getUpcomingBookings() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username).orElseThrow();
        return bookingRepository.findUpcomingByCustomer(user.getUserId(), LocalDate.now())
                .stream().map(MapperUtil::toBookingResponse).collect(Collectors.toList());
    }

    public List<BookingResponse> getPastBookings() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username).orElseThrow();
        return bookingRepository.findPastByCustomer(user.getUserId(), LocalDate.now())
                .stream().map(MapperUtil::toBookingResponse).collect(Collectors.toList());
    }

    public BookingResponse getBookingById(String bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found: " + bookingId));
        validateOwnership(booking);
        return MapperUtil.toBookingResponse(booking);
    }

    @Transactional
    public BookingResponse modifyBooking(String bookingId, BookingRequest request) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));
        validateOwnership(booking);

        if (booking.getBookingStatus() == BookingStatus.CANCELLED) {
            throw new BusinessException("Cannot modify a cancelled booking");
        }

        // 24-hour cutoff check
        LocalDateTime checkInDateTime = booking.getCheckInDate().atStartOfDay();
        if (LocalDateTime.now().isAfter(checkInDateTime.minusHours(24))) {
            throw new BusinessException("Cannot modify booking within 24 hours of check-in");
        }

        validateDates(request.getCheckInDate(), request.getCheckOutDate());

        long overlapping = bookingRepository.countOverlappingBookings(
                booking.getRoom().getId(), request.getCheckInDate(), request.getCheckOutDate());
        if (overlapping > 0 && !booking.getRoom().getId().equals(request.getRoomId())) {
            throw new BusinessException("Room is not available for selected dates");
        }

        long nights = ChronoUnit.DAYS.between(request.getCheckInDate(), request.getCheckOutDate());
        BigDecimal totalAmount = booking.getRoom().getPricePerNight().multiply(BigDecimal.valueOf(nights));
        BigDecimal taxAmount = totalAmount.multiply(TAX_RATE);
        BigDecimal grandTotal = totalAmount.add(taxAmount);

        booking.setCheckInDate(request.getCheckInDate());
        booking.setCheckOutDate(request.getCheckOutDate());
        booking.setTotalNights((int) nights);
        booking.setAdults(request.getAdults());
        booking.setChildren(request.getChildren());
        booking.setSpecialRequest(request.getSpecialRequest());
        booking.setTotalAmount(totalAmount);
        booking.setTaxAmount(taxAmount);
        booking.setGrandTotal(grandTotal);
        booking.setBookingStatus(BookingStatus.MODIFIED);

        return MapperUtil.toBookingResponse(bookingRepository.save(booking));
    }

    @Transactional
    public BookingResponse cancelBooking(String bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));
        validateOwnership(booking);

        if (booking.getBookingStatus() == BookingStatus.CANCELLED) {
            throw new BusinessException("Booking is already cancelled");
        }

        // Refund simulation
        long daysUntilCheckIn = ChronoUnit.DAYS.between(LocalDate.now(), booking.getCheckInDate());
        BigDecimal refundAmount;
        if (daysUntilCheckIn >= 7) {
            refundAmount = booking.getGrandTotal(); // Full refund
        } else if (daysUntilCheckIn >= 3) {
            refundAmount = booking.getGrandTotal().multiply(new BigDecimal("0.5")); // 50% refund
        } else {
            refundAmount = BigDecimal.ZERO; // No refund
        }

        booking.setBookingStatus(BookingStatus.CANCELLED);
        booking.setRefundAmount(refundAmount);

        return MapperUtil.toBookingResponse(bookingRepository.save(booking));
    }

    // Admin methods
    public Page<BookingResponse> getAllBookings(String search, BookingStatus status,
                                                 LocalDate fromDate, LocalDate toDate,
                                                 int page, int size, String sort) {
        Sort sorting = parseSort(sort);
        Pageable pageable = PageRequest.of(page, size, sorting);
        return bookingRepository.findWithFilters(search, status, fromDate, toDate, pageable)
                .map(MapperUtil::toBookingResponse);
    }

    @Transactional
    public BookingResponse adminCancelBooking(String bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));
        booking.setBookingStatus(BookingStatus.CANCELLED);
        return MapperUtil.toBookingResponse(bookingRepository.save(booking));
    }

    @Transactional
    public BookingResponse adminCreateBooking(BookingRequest request, String customerId) {
        User customer = userRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found"));
        Room room = roomRepository.findById(request.getRoomId())
                .orElseThrow(() -> new ResourceNotFoundException("Room not found"));

        validateDates(request.getCheckInDate(), request.getCheckOutDate());

        long nights = ChronoUnit.DAYS.between(request.getCheckInDate(), request.getCheckOutDate());
        BigDecimal totalAmount = room.getPricePerNight().multiply(BigDecimal.valueOf(nights));
        BigDecimal taxAmount = totalAmount.multiply(TAX_RATE);
        BigDecimal grandTotal = totalAmount.add(taxAmount);

        Booking booking = Booking.builder()
                .bookingId(IdGenerator.generateBookingId())
                .customer(customer)
                .room(room)
                .checkInDate(request.getCheckInDate())
                .checkOutDate(request.getCheckOutDate())
                .totalNights((int) nights)
                .adults(request.getAdults())
                .children(request.getChildren())
                .specialRequest(request.getSpecialRequest())
                .bookingStatus(BookingStatus.CONFIRMED)
                .totalAmount(totalAmount)
                .taxAmount(taxAmount)
                .grandTotal(grandTotal)
                .build();

        return MapperUtil.toBookingResponse(bookingRepository.save(booking));
    }

    @Transactional
    public BookingResponse adminUpdateBooking(String bookingId, BookingRequest request) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        long nights = ChronoUnit.DAYS.between(request.getCheckInDate(), request.getCheckOutDate());
        BigDecimal totalAmount = booking.getRoom().getPricePerNight().multiply(BigDecimal.valueOf(nights));
        BigDecimal taxAmount = totalAmount.multiply(TAX_RATE);
        BigDecimal grandTotal = totalAmount.add(taxAmount);

        booking.setCheckInDate(request.getCheckInDate());
        booking.setCheckOutDate(request.getCheckOutDate());
        booking.setTotalNights((int) nights);
        booking.setAdults(request.getAdults());
        booking.setChildren(request.getChildren());
        booking.setSpecialRequest(request.getSpecialRequest());
        booking.setTotalAmount(totalAmount);
        booking.setTaxAmount(taxAmount);
        booking.setGrandTotal(grandTotal);

        return MapperUtil.toBookingResponse(bookingRepository.save(booking));
    }

    private void validateOwnership(Booking booking) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        boolean isAdmin = auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        if (!isAdmin && !booking.getCustomer().getUsername().equals(auth.getName())) {
            throw new BusinessException("Access denied to this booking");
        }
    }

    private void validateDates(LocalDate checkIn, LocalDate checkOut) {
        if (!checkIn.isAfter(LocalDate.now())) {
            throw new BusinessException("Check-in date must be in the future");
        }
        if (!checkOut.isAfter(checkIn)) {
            throw new BusinessException("Check-out date must be after check-in date");
        }
    }

    private Sort parseSort(String sort) {
        if (sort == null || sort.isEmpty()) return Sort.by("createdAt").descending();
        String[] parts = sort.split(",");
        return parts.length > 1 && parts[1].equalsIgnoreCase("desc")
                ? Sort.by(parts[0]).descending()
                : Sort.by(parts[0]).ascending();
    }
}
