package com.hotel.util;

import java.util.UUID;

public class IdGenerator {

    public static String generateUserId() {
        return "USR" + UUID.randomUUID().toString().replace("-", "").substring(0, 7).toUpperCase();
    }

    public static String generateBookingId() {
        return "BKG" + UUID.randomUUID().toString().replace("-", "").substring(0, 7).toUpperCase();
    }

    public static String generateTransactionId() {
        return "TXN" + UUID.randomUUID().toString().replace("-", "").substring(0, 7).toUpperCase();
    }

    public static String generateComplaintId() {
        return "CMP" + UUID.randomUUID().toString().replace("-", "").substring(0, 7).toUpperCase();
    }

    public static String generateInvoiceNumber() {
        return "INV" + System.currentTimeMillis();
    }

    public static String generateRoomNumber(String type, int floor, int seq) {
        return String.format("%s%d%02d", type.substring(0, 1), floor, seq);
    }
}
