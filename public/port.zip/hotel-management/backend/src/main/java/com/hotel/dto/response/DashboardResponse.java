package com.hotel.dto.response;

import lombok.Data;
import java.util.Map;

@Data
public class DashboardResponse {
    private long totalBookings;
    private long dailyBookings;
    private long weeklyBookings;
    private long monthlyBookings;
    private long availableRooms;
    private long occupiedRooms;
    private long totalCustomers;
    private long openComplaints;
    private long totalRooms;
    private Map<String, Long> bookingsByStatus;
    private Map<String, Long> roomsByType;
}
