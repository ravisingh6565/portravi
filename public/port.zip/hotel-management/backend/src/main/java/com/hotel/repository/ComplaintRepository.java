package com.hotel.repository;

import com.hotel.entity.Complaint;
import com.hotel.enums.ComplaintStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface ComplaintRepository extends JpaRepository<Complaint, String> {
    List<Complaint> findByCustomerUserId(String userId);

    List<Complaint> findByAssignedToUserId(String staffId);

    @Query("SELECT c FROM Complaint c WHERE " +
           "(:search IS NULL OR LOWER(c.complaintId) LIKE LOWER(CONCAT('%',:search,'%')) OR " +
           "LOWER(c.customer.customerName) LIKE LOWER(CONCAT('%',:search,'%')) OR " +
           "LOWER(c.title) LIKE LOWER(CONCAT('%',:search,'%'))) AND " +
           "(:status IS NULL OR c.status = :status) AND " +
           "(:category IS NULL OR c.category = :category)")
    Page<Complaint> findWithFilters(@Param("search") String search,
                                     @Param("status") ComplaintStatus status,
                                     @Param("category") String category,
                                     Pageable pageable);

    @Query("SELECT c FROM Complaint c WHERE c.assignedTo.userId = :staffId AND " +
           "(:status IS NULL OR c.status = :status)")
    Page<Complaint> findByStaffAndStatus(@Param("staffId") String staffId,
                                          @Param("status") ComplaintStatus status,
                                          Pageable pageable);
}
