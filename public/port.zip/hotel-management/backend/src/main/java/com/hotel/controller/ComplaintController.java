package com.hotel.controller;

import com.hotel.dto.request.ComplaintRequest;
import com.hotel.dto.response.ComplaintResponse;
import com.hotel.enums.ComplaintStatus;
import com.hotel.service.impl.ComplaintService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/complaints")
@RequiredArgsConstructor
public class ComplaintController {

    private final ComplaintService complaintService;

    @PostMapping
    public ResponseEntity<ComplaintResponse> register(@Valid @RequestBody ComplaintRequest request) {
        return ResponseEntity.ok(complaintService.registerComplaint(request));
    }

    @GetMapping("/my")
    public ResponseEntity<List<ComplaintResponse>> getMyComplaints() {
        return ResponseEntity.ok(complaintService.getMyComplaints());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ComplaintResponse> getById(@PathVariable String id) {
        return ResponseEntity.ok(complaintService.getComplaintById(id));
    }

    @PatchMapping("/{id}/confirm-resolution")
    public ResponseEntity<ComplaintResponse> confirmResolution(@PathVariable String id) {
        return ResponseEntity.ok(complaintService.confirmResolution(id));
    }

    @PatchMapping("/{id}/reopen")
    public ResponseEntity<ComplaintResponse> reopen(@PathVariable String id) {
        return ResponseEntity.ok(complaintService.reopenComplaint(id));
    }

    // Admin
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Page<ComplaintResponse>> getAll(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) ComplaintStatus status,
            @RequestParam(required = false) String category,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(complaintService.getAllComplaints(search, status, category, page, size));
    }

    @PatchMapping("/admin/{id}/assign")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ComplaintResponse> assign(@PathVariable String id, @RequestBody Map<String, Object> body) {
        String staffId = (String) body.get("staffId");
        String notes = (String) body.get("notes");
        String dateStr = (String) body.get("expectedResolutionDate");
        LocalDate date = dateStr != null ? LocalDate.parse(dateStr) : null;
        return ResponseEntity.ok(complaintService.assignComplaint(id, staffId, notes, date));
    }

    @PatchMapping("/admin/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF')")
    public ResponseEntity<ComplaintResponse> updateStatus(@PathVariable String id, @RequestBody Map<String, String> body) {
        ComplaintStatus status = ComplaintStatus.valueOf(body.get("status"));
        String notes = body.get("notes");
        return ResponseEntity.ok(complaintService.updateComplaintStatus(id, status, notes));
    }

    // Staff
    @GetMapping("/staff/assigned")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF')")
    public ResponseEntity<Page<ComplaintResponse>> getAssigned(
            @RequestParam(required = false) ComplaintStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(complaintService.getAssignedComplaints(status, page, size));
    }
}
