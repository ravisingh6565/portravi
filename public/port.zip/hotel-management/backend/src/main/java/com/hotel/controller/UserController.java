package com.hotel.controller;

import com.hotel.dto.request.RegisterRequest;
import com.hotel.dto.response.UserResponse;
import com.hotel.enums.Role;
import com.hotel.service.impl.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping("/profile")
    public ResponseEntity<UserResponse> getProfile() {
        return ResponseEntity.ok(userService.getProfile());
    }

    @PutMapping("/profile")
    public ResponseEntity<UserResponse> updateProfile(@RequestBody RegisterRequest request) {
        return ResponseEntity.ok(userService.updateProfile(request));
    }

    // Admin
    @GetMapping("/customers")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Page<UserResponse>> getCustomers(
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(userService.getCustomers(search, page, size));
    }

    @GetMapping("/staff")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Page<UserResponse>> getStaff(
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(userService.getStaff(search, page, size));
    }

    @PostMapping("/admin/create-customer")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<UserResponse> createCustomer(@Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.ok(userService.createUser(request, Role.ROLE_CUSTOMER));
    }

    @PostMapping("/admin/create-staff")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<UserResponse> createStaff(@Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.ok(userService.createUser(request, Role.ROLE_STAFF));
    }

    @PatchMapping("/admin/{id}/reset-password")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> resetPassword(@PathVariable String id, @RequestBody Map<String, String> body) {
        userService.resetPassword(id, body.get("newPassword"));
        return ResponseEntity.ok().build();
    }

    @PatchMapping("/admin/{id}/toggle-status")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<UserResponse> toggleStatus(@PathVariable String id, @RequestBody Map<String, Boolean> body) {
        return ResponseEntity.ok(userService.toggleUserStatus(id, body.get("active")));
    }
}
