package com.hotel.enums;

public enum Role {
    ROLE_ADMIN,
    ROLE_CUSTOMER,
    ROLE_STAFF
}
