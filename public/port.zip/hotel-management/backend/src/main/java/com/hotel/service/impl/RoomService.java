package com.hotel.service.impl;

import com.hotel.dto.request.RoomRequest;
import com.hotel.dto.response.RoomResponse;
import com.hotel.entity.Room;
import com.hotel.enums.BookingStatus;
import com.hotel.enums.RoomStatus;
import com.hotel.enums.RoomType;
import com.hotel.exception.BusinessException;
import com.hotel.exception.ResourceNotFoundException;
import com.hotel.repository.BookingRepository;
import com.hotel.repository.RoomRepository;
import com.hotel.util.MapperUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.csv.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import java.io.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@RequiredArgsConstructor
public class RoomService {

    private final RoomRepository roomRepository;
    private final BookingRepository bookingRepository;
    private final AtomicInteger roomCounter = new AtomicInteger(1);

    public Page<RoomResponse> getAvailableRooms(LocalDate checkIn, LocalDate checkOut,
                                                  int adults, int children,
                                                  RoomType roomType,
                                                  int page, int size, String sort) {
        Sort sorting = parseSort(sort);
        Pageable pageable = PageRequest.of(page, size, sorting);
        return roomRepository.findAvailableRooms(checkIn, checkOut, adults, children, roomType, pageable)
                .map(MapperUtil::toRoomResponse);
    }

    public Page<RoomResponse> getAllRooms(String search, RoomType roomType, RoomStatus status,
                                          int page, int size, String sort) {
        Sort sorting = parseSort(sort);
        Pageable pageable = PageRequest.of(page, size, sorting);
        String searchParam = (search == null || search.isEmpty()) ? "" : search;
        return roomRepository.findWithFilters(searchParam, roomType, status, pageable)
                .map(MapperUtil::toRoomResponse);
    }

    public RoomResponse getRoomById(Long id) {
        return roomRepository.findById(id)
                .map(MapperUtil::toRoomResponse)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + id));
    }

    @Transactional
    public RoomResponse addRoom(RoomRequest request) {
        String roomNumber = request.getRoomNumber();
        if (roomNumber == null || roomNumber.isEmpty()) {
            roomNumber = generateRoomNumber(request.getRoomType(), request.getFloorNumber());
        }
        if (roomRepository.existsByRoomNumber(roomNumber)) {
            throw new BusinessException("Room number already exists: " + roomNumber);
        }

        Room room = Room.builder()
                .roomNumber(roomNumber)
                .roomType(request.getRoomType())
                .roomStatus(RoomStatus.AVAILABLE)
                .pricePerNight(request.getPricePerNight())
                .maxAdults(request.getMaxAdults())
                .maxChildren(request.getMaxChildren())
                .amenities(request.getAmenities())
                .description(request.getDescription())
                .floorNumber(request.getFloorNumber())
                .build();

        return MapperUtil.toRoomResponse(roomRepository.save(room));
    }

    @Transactional
    public RoomResponse updateRoom(Long id, RoomRequest request) {
        Room room = roomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found"));

        // Check active bookings
        boolean hasActiveBooking = bookingRepository
                .existsByRoomIdAndBookingStatusNotAndCheckInDateLessThanAndCheckOutDateGreaterThan(
                        id, BookingStatus.CANCELLED, LocalDate.now().plusYears(10), LocalDate.now());
        if (hasActiveBooking) {
            throw new BusinessException("Cannot edit room with active bookings");
        }

        // Room number is non-editable
        room.setRoomType(request.getRoomType());
        room.setPricePerNight(request.getPricePerNight());
        room.setMaxAdults(request.getMaxAdults());
        room.setMaxChildren(request.getMaxChildren());
        room.setAmenities(request.getAmenities());
        room.setDescription(request.getDescription());
        room.setFloorNumber(request.getFloorNumber());

        return MapperUtil.toRoomResponse(roomRepository.save(room));
    }

    @Transactional
    public void updateRoomStatus(Long id, RoomStatus status) {
        Room room = roomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found"));
        room.setRoomStatus(status);
        roomRepository.save(room);
    }

    @Transactional
    public List<RoomResponse> bulkUpload(MultipartFile file) throws IOException {
        List<RoomResponse> results = new ArrayList<>();
        try (Reader reader = new InputStreamReader(file.getInputStream());
             CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {

            for (CSVRecord record : parser) {
                try {
                    RoomRequest req = new RoomRequest();
                    req.setRoomType(RoomType.valueOf(record.get("roomType").toUpperCase()));
                    req.setPricePerNight(new BigDecimal(record.get("pricePerNight")));
                    req.setMaxAdults(Integer.parseInt(record.get("maxAdults")));
                    req.setMaxChildren(Integer.parseInt(record.get("maxChildren")));
                    req.setAmenities(record.get("amenities"));
                    req.setDescription(record.get("description"));
                    req.setFloorNumber(Integer.parseInt(record.get("floorNumber")));
                    if (record.isMapped("roomNumber") && !record.get("roomNumber").isEmpty()) {
                        req.setRoomNumber(record.get("roomNumber"));
                    }
                    results.add(addRoom(req));
                } catch (Exception e) {
                    // Skip invalid rows
                }
            }
        }
        return results;
    }

    private String generateRoomNumber(RoomType type, int floor) {
        int seq = roomCounter.getAndIncrement();
        return type.name().charAt(0) + String.valueOf(floor) + String.format("%02d", seq % 100);
    }

    private Sort parseSort(String sort) {
        if (sort == null || sort.isEmpty()) return Sort.by("id").ascending();
        String[] parts = sort.split(",");
        return parts.length > 1 && parts[1].equalsIgnoreCase("desc")
                ? Sort.by(parts[0]).descending()
                : Sort.by(parts[0]).ascending();
    }
}
