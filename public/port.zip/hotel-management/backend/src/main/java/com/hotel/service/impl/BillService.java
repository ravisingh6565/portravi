package com.hotel.service.impl;

import com.hotel.dto.response.*;
import com.hotel.entity.*;
import com.hotel.enums.PaymentStatus;
import com.hotel.exception.BusinessException;
import com.hotel.exception.ResourceNotFoundException;
import com.hotel.repository.*;
import com.hotel.util.MapperUtil;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@RequiredArgsConstructor
public class BillService {

    private final BillRepository billRepository;
    private final BookingRepository bookingRepository;
    private final PaymentRepository paymentRepository;

    public Page<BillResponse> getAllBills(String search, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return billRepository.findWithFilters(search, pageable).map(this::toBillResponse);
    }

    public BillResponse getBillByBooking(String bookingId) {
        Bill bill = billRepository.findByBookingBookingId(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Bill not found for booking: " + bookingId));
        return toBillResponse(bill);
    }

    @Transactional
    public BillResponse addBillItems(String bookingId, BigDecimal additionalCharges, String additionalItems, String notes) {
        Bill bill = billRepository.findByBookingBookingId(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Bill not found"));
        bill.setAdditionalCharges(additionalCharges);
        bill.setAdditionalItems(additionalItems);
        bill.setNotes(notes);
        BigDecimal newTotal = bill.getRoomCharges().add(additionalCharges).add(bill.getTaxAmount());
        bill.setTotalAmount(newTotal);
        return toBillResponse(billRepository.save(bill));
    }

    public byte[] generateInvoicePDF(String bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        Payment payment = paymentRepository.findByBookingBookingId(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found"));

        if (payment.getPaymentStatus() != PaymentStatus.SUCCESS) {
            throw new BusinessException("Invoice can only be generated for paid bookings");
        }

        Bill bill = billRepository.findByBookingBookingId(bookingId).orElse(null);

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, baos);
            document.open();

            // Fonts
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, new BaseColor(44, 62, 80));
            Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.WHITE);
            Font normalFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.DARK_GRAY);
            Font boldFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.DARK_GRAY);

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd MMM yyyy");
            DateTimeFormatter dtfTime = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm:ss");

            // Header
            Paragraph hotelName = new Paragraph("GRAND HOTEL & RESORT", titleFont);
            hotelName.setAlignment(Element.ALIGN_CENTER);
            document.add(hotelName);

            Paragraph subtitle = new Paragraph("123 Hotel Street, City - 400001 | Ph: +91-9876543210 | hotel@grand.com", normalFont);
            subtitle.setAlignment(Element.ALIGN_CENTER);
            document.add(subtitle);

            document.add(new Paragraph("\n"));

            // Invoice Title
            Font invFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, new BaseColor(52, 73, 94));
            Paragraph invTitle = new Paragraph("TAX INVOICE", invFont);
            invTitle.setAlignment(Element.ALIGN_CENTER);
            document.add(invTitle);

            document.add(new Paragraph("\n"));

            // Invoice details table
            PdfPTable infoTable = new PdfPTable(2);
            infoTable.setWidthPercentage(100);
            addInfoCell(infoTable, "Invoice Number:", bill != null ? bill.getInvoiceNumber() : "N/A", boldFont, normalFont);
            addInfoCell(infoTable, "Booking ID:", booking.getBookingId(), boldFont, normalFont);
            addInfoCell(infoTable, "Transaction ID:", payment.getTransactionId(), boldFont, normalFont);
            addInfoCell(infoTable, "Invoice Date:", dtfTime.format(payment.getPaymentDate()), boldFont, normalFont);
            document.add(infoTable);

            document.add(new Paragraph("\n"));

            // Customer & Room details
            PdfPTable detailsTable = new PdfPTable(2);
            detailsTable.setWidthPercentage(100);

            // Customer
            PdfPCell custCell = new PdfPCell();
            custCell.addElement(new Paragraph("Customer Details", boldFont));
            custCell.addElement(new Paragraph("Name: " + booking.getCustomer().getCustomerName(), normalFont));
            custCell.addElement(new Paragraph("Email: " + booking.getCustomer().getEmail(), normalFont));
            custCell.addElement(new Paragraph("Phone: " + booking.getCustomer().getMobile(), normalFont));
            custCell.setPadding(8);
            detailsTable.addCell(custCell);

            // Room
            PdfPCell roomCell = new PdfPCell();
            roomCell.addElement(new Paragraph("Room Details", boldFont));
            roomCell.addElement(new Paragraph("Room: " + booking.getRoom().getRoomNumber(), normalFont));
            roomCell.addElement(new Paragraph("Type: " + booking.getRoom().getRoomType(), normalFont));
            roomCell.addElement(new Paragraph("Floor: " + booking.getRoom().getFloorNumber(), normalFont));
            roomCell.setPadding(8);
            detailsTable.addCell(roomCell);
            document.add(detailsTable);

            document.add(new Paragraph("\n"));

            // Stay details
            PdfPTable stayTable = new PdfPTable(2);
            stayTable.setWidthPercentage(100);
            addInfoCell(stayTable, "Check-In:", dtf.format(booking.getCheckInDate()), boldFont, normalFont);
            addInfoCell(stayTable, "Check-Out:", dtf.format(booking.getCheckOutDate()), boldFont, normalFont);
            addInfoCell(stayTable, "Total Nights:", String.valueOf(booking.getTotalNights()), boldFont, normalFont);
            addInfoCell(stayTable, "Guests:", booking.getAdults() + " Adults, " + booking.getChildren() + " Children", boldFont, normalFont);
            document.add(stayTable);

            document.add(new Paragraph("\n"));

            // Billing
            PdfPTable billingTable = new PdfPTable(2);
            billingTable.setWidthPercentage(100);
            billingTable.setWidths(new float[]{70, 30});

            // Header row
            PdfPCell h1 = new PdfPCell(new Phrase("Description", headerFont));
            h1.setBackgroundColor(new BaseColor(44, 62, 80));
            h1.setPadding(8);
            billingTable.addCell(h1);
            PdfPCell h2 = new PdfPCell(new Phrase("Amount (INR)", headerFont));
            h2.setBackgroundColor(new BaseColor(44, 62, 80));
            h2.setPadding(8);
            billingTable.addCell(h2);

            addBillingRow(billingTable, "Room Charges (" + booking.getTotalNights() + " nights × ₹" + booking.getRoom().getPricePerNight() + ")", booking.getTotalAmount().toString(), normalFont);

            if (bill != null && bill.getAdditionalCharges() != null && bill.getAdditionalCharges().compareTo(BigDecimal.ZERO) > 0) {
                addBillingRow(billingTable, "Additional Charges", bill.getAdditionalCharges().toString(), normalFont);
            }

            addBillingRow(billingTable, "GST (18%)", booking.getTaxAmount().toString(), normalFont);

            // Total row
            PdfPCell tc1 = new PdfPCell(new Phrase("GRAND TOTAL", boldFont));
            tc1.setBackgroundColor(new BaseColor(236, 240, 241));
            tc1.setPadding(8);
            billingTable.addCell(tc1);
            PdfPCell tc2 = new PdfPCell(new Phrase("₹ " + booking.getGrandTotal(), boldFont));
            tc2.setBackgroundColor(new BaseColor(236, 240, 241));
            tc2.setPadding(8);
            billingTable.addCell(tc2);

            document.add(billingTable);

            document.add(new Paragraph("\n"));

            // Payment info
            Paragraph payInfo = new Paragraph("Payment Method: " + payment.getPaymentMethod() + " | Status: " + payment.getPaymentStatus(), boldFont);
            document.add(payInfo);

            document.add(new Paragraph("\n\nThank you for staying with us! We hope to see you again.", normalFont));

            document.close();
            return baos.toByteArray();
        } catch (Exception e) {
            throw new BusinessException("Failed to generate PDF: " + e.getMessage());
        }
    }

    private void addInfoCell(PdfPTable table, String label, String value, Font bold, Font normal) {
        PdfPCell lc = new PdfPCell(new Phrase(label, bold));
        lc.setBorder(Rectangle.NO_BORDER);
        lc.setPadding(4);
        table.addCell(lc);
        PdfPCell vc = new PdfPCell(new Phrase(value, normal));
        vc.setBorder(Rectangle.NO_BORDER);
        vc.setPadding(4);
        table.addCell(vc);
    }

    private void addBillingRow(PdfPTable table, String desc, String amount, Font font) {
        PdfPCell c1 = new PdfPCell(new Phrase(desc, font));
        c1.setPadding(8);
        table.addCell(c1);
        PdfPCell c2 = new PdfPCell(new Phrase("₹ " + amount, font));
        c2.setPadding(8);
        table.addCell(c2);
    }

    private BillResponse toBillResponse(Bill bill) {
        BillResponse r = new BillResponse();
        r.setId(bill.getId());
        r.setInvoiceNumber(bill.getInvoiceNumber());
        r.setBookingId(bill.getBooking().getBookingId());
        r.setCustomerName(bill.getBooking().getCustomer().getCustomerName());
        r.setRoomCharges(bill.getRoomCharges());
        r.setAdditionalCharges(bill.getAdditionalCharges());
        r.setDiscountAmount(bill.getDiscountAmount());
        r.setTaxPercentage(bill.getTaxPercentage());
        r.setTaxAmount(bill.getTaxAmount());
        r.setTotalAmount(bill.getTotalAmount());
        r.setAdditionalItems(bill.getAdditionalItems());
        r.setNotes(bill.getNotes());
        r.setCreatedAt(bill.getCreatedAt());
        return r;
    }
}
