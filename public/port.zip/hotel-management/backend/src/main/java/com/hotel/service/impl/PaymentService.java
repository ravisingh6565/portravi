package com.hotel.service.impl;

import com.hotel.dto.request.PaymentRequest;
import com.hotel.dto.response.PaymentResponse;
import com.hotel.entity.*;
import com.hotel.enums.BookingStatus;
import com.hotel.enums.PaymentStatus;
import com.hotel.exception.BusinessException;
import com.hotel.exception.ResourceNotFoundException;
import com.hotel.repository.*;
import com.hotel.util.IdGenerator;
import com.hotel.util.MapperUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.*;
import java.util.Random;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final BookingRepository bookingRepository;
    private final BillRepository billRepository;
    private final Random random = new Random();

    @Transactional
    public PaymentResponse processPayment(PaymentRequest request) {
        Booking booking = bookingRepository.findById(request.getBookingId())
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        if (booking.getBookingStatus() == BookingStatus.CANCELLED) {
            throw new BusinessException("Cannot pay for a cancelled booking");
        }

        // Validate expiry date
        validateExpiryDate(request.getExpiryDate());

        // 80% success, 20% failure simulation
        boolean paymentSuccess = random.nextInt(100) < 80;

        Payment payment = Payment.builder()
                .transactionId(IdGenerator.generateTransactionId())
                .booking(booking)
                .paymentMethod(request.getPaymentMethod())
                .amountPaid(booking.getGrandTotal())
                .cardholderName(request.getCardholderName())
                .cardLastFour(request.getCardNumber().substring(request.getCardNumber().length() - 4))
                .paymentDate(LocalDateTime.now())
                .build();

        if (paymentSuccess) {
            payment.setPaymentStatus(PaymentStatus.SUCCESS);
            booking.setBookingStatus(BookingStatus.CONFIRMED);

            // Generate bill
            Bill bill = Bill.builder()
                    .invoiceNumber(IdGenerator.generateInvoiceNumber())
                    .booking(booking)
                    .roomCharges(booking.getTotalAmount())
                    .additionalCharges(java.math.BigDecimal.ZERO)
                    .discountAmount(java.math.BigDecimal.ZERO)
                    .taxPercentage(new java.math.BigDecimal("18"))
                    .taxAmount(booking.getTaxAmount())
                    .totalAmount(booking.getGrandTotal())
                    .build();
            billRepository.save(bill);
        } else {
            payment.setPaymentStatus(PaymentStatus.FAILED);
            payment.setFailureReason("Transaction declined by bank. Please try again.");
        }

        bookingRepository.save(booking);
        paymentRepository.save(payment);

        return MapperUtil.toPaymentResponse(payment);
    }

    public PaymentResponse getPaymentByBooking(String bookingId) {
        Payment payment = paymentRepository.findByBookingBookingId(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found for booking: " + bookingId));
        return MapperUtil.toPaymentResponse(payment);
    }

    public Page<PaymentResponse> getAllPayments(String search, PaymentStatus status, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("paymentDate").descending());
        return paymentRepository.findWithFilters(search, status, pageable)
                .map(MapperUtil::toPaymentResponse);
    }

    private void validateExpiryDate(String expiryDate) {
        String[] parts = expiryDate.split("/");
        int month = Integer.parseInt(parts[0]);
        int year = Integer.parseInt(parts[1]) + 2000;
        YearMonth expiry = YearMonth.of(year, month);
        if (expiry.isBefore(YearMonth.now())) {
            throw new BusinessException("Card has expired");
        }
    }
}
