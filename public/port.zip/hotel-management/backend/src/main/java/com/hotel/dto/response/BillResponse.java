package com.hotel.dto.response;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class BillResponse {
    private Long id;
    private String invoiceNumber;
    private String bookingId;
    private String customerName;
    private BigDecimal roomCharges;
    private BigDecimal additionalCharges;
    private BigDecimal discountAmount;
    private BigDecimal taxPercentage;
    private BigDecimal taxAmount;
    private BigDecimal totalAmount;
    private String additionalItems;
    private String notes;
    private LocalDateTime createdAt;
}
