package com.hotel.service.impl;

import com.hotel.dto.response.DashboardResponse;
import com.hotel.enums.BookingStatus;
import com.hotel.enums.RoomStatus;
import com.hotel.enums.RoomType;
import com.hotel.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final BookingRepository bookingRepository;
    private final RoomRepository roomRepository;
    private final UserRepository userRepository;
    private final ComplaintRepository complaintRepository;

    public DashboardResponse getDashboardData() {
        DashboardResponse response = new DashboardResponse();

        response.setTotalBookings(bookingRepository.count());
        response.setDailyBookings(bookingRepository.countBookingsSince(LocalDateTime.now().minusDays(1)));
        response.setWeeklyBookings(bookingRepository.countBookingsSince(LocalDateTime.now().minusWeeks(1)));
        response.setMonthlyBookings(bookingRepository.countBookingsSince(LocalDateTime.now().minusMonths(1)));

        response.setAvailableRooms(roomRepository.countByRoomStatus(RoomStatus.AVAILABLE));
        response.setOccupiedRooms(roomRepository.countByRoomStatus(RoomStatus.OCCUPIED));
        response.setTotalRooms(roomRepository.count());

        response.setTotalCustomers(userRepository.count());

        Map<String, Long> bookingsByStatus = new HashMap<>();
        for (BookingStatus status : BookingStatus.values()) {
            bookingsByStatus.put(status.name(), bookingRepository.countByBookingStatus(status));
        }
        response.setBookingsByStatus(bookingsByStatus);

        Map<String, Long> roomsByType = new HashMap<>();
        for (RoomType type : RoomType.values()) {
            long count = roomRepository.findAll().stream()
                    .filter(r -> r.getRoomType() == type).count();
            roomsByType.put(type.name(), count);
        }
        response.setRoomsByType(roomsByType);

        return response;
    }
}
