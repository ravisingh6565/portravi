package com.hotel.controller;

import com.hotel.dto.request.BookingRequest;
import com.hotel.dto.response.BookingResponse;
import com.hotel.enums.BookingStatus;
import com.hotel.service.impl.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    @PostMapping
    public ResponseEntity<BookingResponse> createBooking(@Valid @RequestBody BookingRequest request) {
        return ResponseEntity.ok(bookingService.createBooking(request));
    }

    @GetMapping("/my")
    public ResponseEntity<List<BookingResponse>> getMyBookings() {
        return ResponseEntity.ok(bookingService.getMyBookings());
    }

    @GetMapping("/my/upcoming")
    public ResponseEntity<List<BookingResponse>> getUpcoming() {
        return ResponseEntity.ok(bookingService.getUpcomingBookings());
    }

    @GetMapping("/my/past")
    public ResponseEntity<List<BookingResponse>> getPast() {
        return ResponseEntity.ok(bookingService.getPastBookings());
    }

    @GetMapping("/{id}")
    public ResponseEntity<BookingResponse> getById(@PathVariable String id) {
        return ResponseEntity.ok(bookingService.getBookingById(id));
    }

    @PutMapping("/{id}/modify")
    public ResponseEntity<BookingResponse> modify(@PathVariable String id, @Valid @RequestBody BookingRequest request) {
        return ResponseEntity.ok(bookingService.modifyBooking(id, request));
    }

    @PatchMapping("/{id}/cancel")
    public ResponseEntity<BookingResponse> cancel(@PathVariable String id) {
        return ResponseEntity.ok(bookingService.cancelBooking(id));
    }

    // Admin endpoints
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Page<BookingResponse>> getAll(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) BookingStatus status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt,desc") String sort) {
        return ResponseEntity.ok(bookingService.getAllBookings(search, status, fromDate, toDate, page, size, sort));
    }

    @PatchMapping("/admin/{id}/cancel")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BookingResponse> adminCancel(@PathVariable String id) {
        return ResponseEntity.ok(bookingService.adminCancelBooking(id));
    }

    @PostMapping("/admin/create/{customerId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BookingResponse> adminCreate(@PathVariable String customerId,
                                                        @Valid @RequestBody BookingRequest request) {
        return ResponseEntity.ok(bookingService.adminCreateBooking(request, customerId));
    }

    @PutMapping("/admin/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BookingResponse> adminUpdate(@PathVariable String id, @Valid @RequestBody BookingRequest request) {
        return ResponseEntity.ok(bookingService.adminUpdateBooking(id, request));
    }
}
