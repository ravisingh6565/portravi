package com.hotel.util;

import com.hotel.dto.response.*;
import com.hotel.entity.*;

public class MapperUtil {

    public static UserResponse toUserResponse(User user) {
        UserResponse r = new UserResponse();
        r.setUserId(user.getUserId());
        r.setCustomerName(user.getCustomerName());
        r.setEmail(user.getEmail());
        r.setMobile(user.getMobile());
        r.setAddress(user.getAddress());
        r.setUsername(user.getUsername());
        r.setRole(user.getRole());
        r.setActive(user.isActive());
        r.setAccountLocked(user.isAccountLocked());
        r.setCreatedAt(user.getCreatedAt());
        return r;
    }

    public static RoomResponse toRoomResponse(Room room) {
        RoomResponse r = new RoomResponse();
        r.setId(room.getId());
        r.setRoomNumber(room.getRoomNumber());
        r.setRoomType(room.getRoomType());
        r.setRoomStatus(room.getRoomStatus());
        r.setPricePerNight(room.getPricePerNight());
        r.setMaxAdults(room.getMaxAdults());
        r.setMaxChildren(room.getMaxChildren());
        r.setAmenities(room.getAmenities());
        r.setDescription(room.getDescription());
        r.setFloorNumber(room.getFloorNumber());
        r.setCreatedAt(room.getCreatedAt());
        return r;
    }

    public static BookingResponse toBookingResponse(Booking booking) {
        BookingResponse r = new BookingResponse();
        r.setBookingId(booking.getBookingId());
        r.setCustomerId(booking.getCustomer().getUserId());
        r.setCustomerName(booking.getCustomer().getCustomerName());
        r.setCustomerEmail(booking.getCustomer().getEmail());
        r.setRoomId(booking.getRoom().getId());
        r.setRoomNumber(booking.getRoom().getRoomNumber());
        r.setRoomType(booking.getRoom().getRoomType().name());
        r.setCheckInDate(booking.getCheckInDate());
        r.setCheckOutDate(booking.getCheckOutDate());
        r.setTotalNights(booking.getTotalNights());
        r.setAdults(booking.getAdults());
        r.setChildren(booking.getChildren());
        r.setSpecialRequest(booking.getSpecialRequest());
        r.setBookingStatus(booking.getBookingStatus());
        r.setTotalAmount(booking.getTotalAmount());
        r.setTaxAmount(booking.getTaxAmount());
        r.setGrandTotal(booking.getGrandTotal());
        r.setRefundAmount(booking.getRefundAmount());
        if (booking.getPayment() != null) {
            r.setPaymentMethod(booking.getPayment().getPaymentMethod());
            r.setTransactionId(booking.getPayment().getTransactionId());
            r.setPaymentStatus(booking.getPayment().getPaymentStatus().name());
        }
        r.setCreatedAt(booking.getCreatedAt());
        return r;
    }

    public static PaymentResponse toPaymentResponse(Payment payment) {
        PaymentResponse r = new PaymentResponse();
        r.setTransactionId(payment.getTransactionId());
        r.setBookingId(payment.getBooking().getBookingId());
        r.setPaymentMethod(payment.getPaymentMethod());
        r.setAmountPaid(payment.getAmountPaid());
        r.setPaymentStatus(payment.getPaymentStatus());
        r.setCardholderName(payment.getCardholderName());
        r.setCardLastFour(payment.getCardLastFour());
        r.setFailureReason(payment.getFailureReason());
        r.setPaymentDate(payment.getPaymentDate());
        r.setCustomerName(payment.getBooking().getCustomer().getCustomerName());
        return r;
    }

    public static ComplaintResponse toComplaintResponse(Complaint complaint) {
        ComplaintResponse r = new ComplaintResponse();
        r.setComplaintId(complaint.getComplaintId());
        r.setCustomerId(complaint.getCustomer().getUserId());
        r.setCustomerName(complaint.getCustomer().getCustomerName());
        r.setCustomerEmail(complaint.getCustomer().getEmail());
        r.setBookingId(complaint.getBookingId());
        r.setCategory(complaint.getCategory());
        r.setTitle(complaint.getTitle());
        r.setDescription(complaint.getDescription());
        r.setContactPreference(complaint.getContactPreference());
        r.setStatus(complaint.getStatus());
        r.setResolutionNotes(complaint.getResolutionNotes());
        r.setExpectedResolutionDate(complaint.getExpectedResolutionDate());
        r.setResolvedAt(complaint.getResolvedAt());
        r.setCreatedAt(complaint.getCreatedAt());
        r.setUpdatedAt(complaint.getUpdatedAt());
        if (complaint.getAssignedTo() != null) {
            r.setAssignedToName(complaint.getAssignedTo().getCustomerName());
            r.setAssignedToId(complaint.getAssignedTo().getUserId());
        }
        return r;
    }
}
