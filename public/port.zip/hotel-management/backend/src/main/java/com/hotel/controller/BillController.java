package com.hotel.controller;

import com.hotel.dto.response.BillResponse;
import com.hotel.service.impl.BillService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.Map;

@RestController
@RequestMapping("/api/bills")
@RequiredArgsConstructor
public class BillController {

    private final BillService billService;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Page<BillResponse>> getAll(
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(billService.getAllBills(search, page, size));
    }

    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<BillResponse> getByBooking(@PathVariable String bookingId) {
        return ResponseEntity.ok(billService.getBillByBooking(bookingId));
    }

    @PatchMapping("/booking/{bookingId}/add-items")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BillResponse> addItems(@PathVariable String bookingId, @RequestBody Map<String, Object> body) {
        BigDecimal charges = new BigDecimal(body.get("additionalCharges").toString());
        String items = (String) body.get("additionalItems");
        String notes = (String) body.get("notes");
        return ResponseEntity.ok(billService.addBillItems(bookingId, charges, items, notes));
    }
}
