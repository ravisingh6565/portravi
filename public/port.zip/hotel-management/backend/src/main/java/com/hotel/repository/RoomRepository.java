package com.hotel.repository;

import com.hotel.entity.Room;
import com.hotel.enums.RoomStatus;
import com.hotel.enums.RoomType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface RoomRepository extends JpaRepository<Room, Long> {
    Optional<Room> findByRoomNumber(String roomNumber);
    boolean existsByRoomNumber(String roomNumber);

    @Query("SELECT r FROM Room r WHERE r.roomStatus = :status")
    List<Room> findByRoomStatus(@Param("status") RoomStatus status);

    @Query("SELECT r FROM Room r WHERE r.id NOT IN (" +
           "SELECT b.room.id FROM Booking b WHERE b.bookingStatus NOT IN ('CANCELLED') AND " +
           "(b.checkInDate < :checkOut AND b.checkOutDate > :checkIn)) " +
           "AND r.roomStatus = 'AVAILABLE' " +
           "AND r.maxAdults >= :adults " +
           "AND r.maxChildren >= :children " +
           "AND (:roomType IS NULL OR r.roomType = :roomType)")
    Page<Room> findAvailableRooms(@Param("checkIn") LocalDate checkIn,
                                   @Param("checkOut") LocalDate checkOut,
                                   @Param("adults") int adults,
                                   @Param("children") int children,
                                   @Param("roomType") RoomType roomType,
                                   Pageable pageable);

    @Query("SELECT r FROM Room r WHERE " +
           "(LOWER(r.roomNumber) LIKE LOWER(CONCAT('%',:search,'%')) OR " +
           "CAST(r.roomType AS string) LIKE CONCAT('%',:search,'%')) AND " +
           "(:roomType IS NULL OR r.roomType = :roomType) AND " +
           "(:status IS NULL OR r.roomStatus = :status)")
    Page<Room> findWithFilters(@Param("search") String search,
                                @Param("roomType") RoomType roomType,
                                @Param("status") RoomStatus status,
                                Pageable pageable);

    long countByRoomStatus(RoomStatus status);
}
