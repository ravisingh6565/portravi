package com.hotel.enums;

public enum RoomType {
    STANDARD,
    DELUXE,
    SUITE,
    EXECUTIVE,
    PRESIDENTIAL
}
