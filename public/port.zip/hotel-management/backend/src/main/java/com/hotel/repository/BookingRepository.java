package com.hotel.repository;

import com.hotel.entity.Booking;
import com.hotel.enums.BookingStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, String> {

    List<Booking> findByCustomerUserId(String userId);

    Page<Booking> findByCustomerUserId(String userId, Pageable pageable);

    @Query("SELECT b FROM Booking b WHERE b.customer.userId = :userId AND b.checkInDate >= :today ORDER BY b.checkInDate ASC")
    List<Booking> findUpcomingByCustomer(@Param("userId") String userId, @Param("today") LocalDate today);

    @Query("SELECT b FROM Booking b WHERE b.customer.userId = :userId AND b.checkOutDate < :today ORDER BY b.checkOutDate DESC")
    List<Booking> findPastByCustomer(@Param("userId") String userId, @Param("today") LocalDate today);

    @Query("SELECT b FROM Booking b WHERE " +
           "(:search IS NULL OR LOWER(b.bookingId) LIKE LOWER(CONCAT('%',:search,'%')) OR " +
           "LOWER(b.customer.customerName) LIKE LOWER(CONCAT('%',:search,'%')) OR " +
           "LOWER(b.room.roomNumber) LIKE LOWER(CONCAT('%',:search,'%'))) AND " +
           "(:status IS NULL OR b.bookingStatus = :status) AND " +
           "(:fromDate IS NULL OR b.checkInDate >= :fromDate) AND " +
           "(:toDate IS NULL OR b.checkOutDate <= :toDate)")
    Page<Booking> findWithFilters(@Param("search") String search,
                                   @Param("status") BookingStatus status,
                                   @Param("fromDate") LocalDate fromDate,
                                   @Param("toDate") LocalDate toDate,
                                   Pageable pageable);

    @Query("SELECT COUNT(b) FROM Booking b WHERE b.bookingStatus = 'CONFIRMED' AND b.createdAt >= :from")
    long countBookingsSince(@Param("from") LocalDateTime from);

    @Query("SELECT COUNT(b) FROM Booking b WHERE b.room.id = :roomId AND b.bookingStatus NOT IN ('CANCELLED') AND " +
           "(b.checkInDate < :checkOut AND b.checkOutDate > :checkIn)")
    long countOverlappingBookings(@Param("roomId") Long roomId,
                                   @Param("checkIn") LocalDate checkIn,
                                   @Param("checkOut") LocalDate checkOut);

    boolean existsByRoomIdAndBookingStatusNotAndCheckInDateLessThanAndCheckOutDateGreaterThan(
            Long roomId, BookingStatus status, LocalDate checkOut, LocalDate checkIn);

    long countByBookingStatus(BookingStatus status);
}
