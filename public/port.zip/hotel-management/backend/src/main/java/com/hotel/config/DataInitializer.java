package com.hotel.config;

import com.hotel.entity.User;
import com.hotel.enums.Role;
import com.hotel.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (!userRepository.existsByUsername("admin")) {
            User admin = User.builder()
                    .userId("ADMIN001")
                    .customerName("System Administrator")
                    .email("admin@hotel.com")
                    .mobile("+911234567890")
                    .address("Hotel Management System HQ")
                    .username("admin")
                    .password(passwordEncoder.encode("admin"))
                    .role(Role.ROLE_ADMIN)
                    .active(true)
                    .build();
            userRepository.save(admin);
            log.info("Default admin created: username=admin, password=admin");
        }

        if (!userRepository.existsByUsername("staff1")) {
            User staff = User.builder()
                    .userId("STAFF001")
                    .customerName("John Staff")
                    .email("staff@hotel.com")
                    .mobile("+910987654321")
                    .address("Hotel Staff Quarters")
                    .username("staff1")
                    .password(passwordEncoder.encode("Staff@123"))
                    .role(Role.ROLE_STAFF)
                    .active(true)
                    .build();
            userRepository.save(staff);
            log.info("Default staff created: username=staff1, password=Staff@123");
        }
    }
}
