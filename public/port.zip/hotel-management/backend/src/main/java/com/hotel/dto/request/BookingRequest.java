package com.hotel.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class BookingRequest {

    @NotNull(message = "Room ID is required")
    private Long roomId;

    @NotNull(message = "Check-in date is required")
    @Future(message = "Check-in date must be in the future")
    private LocalDate checkInDate;

    @NotNull(message = "Check-out date is required")
    private LocalDate checkOutDate;

    @Min(value = 1, message = "At least 1 adult required")
    @Max(value = 10, message = "Maximum 10 adults allowed")
    private int adults;

    @Min(value = 0, message = "Children cannot be negative")
    @Max(value = 5, message = "Maximum 5 children allowed")
    private int children;

    @Size(max = 500, message = "Special request too long")
    private String specialRequest;

    @NotBlank(message = "Payment method is required")
    private String paymentMethod;
}
