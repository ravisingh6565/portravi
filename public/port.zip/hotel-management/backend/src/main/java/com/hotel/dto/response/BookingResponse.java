package com.hotel.dto.response;

import com.hotel.enums.BookingStatus;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class BookingResponse {
    private String bookingId;
    private String customerId;
    private String customerName;
    private String customerEmail;
    private Long roomId;
    private String roomNumber;
    private String roomType;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private int totalNights;
    private int adults;
    private int children;
    private String specialRequest;
    private BookingStatus bookingStatus;
    private BigDecimal totalAmount;
    private BigDecimal taxAmount;
    private BigDecimal grandTotal;
    private BigDecimal refundAmount;
    private String paymentMethod;
    private String transactionId;
    private String paymentStatus;
    private LocalDateTime createdAt;
}
