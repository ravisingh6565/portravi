package com.hotel.dto.request;

import com.hotel.enums.RoomType;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.math.BigDecimal;

@Data
public class RoomRequest {

    private String roomNumber; // auto-generated if null

    @NotNull(message = "Room type is required")
    private RoomType roomType;

    @NotNull(message = "Price per night is required")
    @DecimalMin(value = "0.01", message = "Price must be positive")
    private BigDecimal pricePerNight;

    @Min(value = 1, message = "At least 1 adult capacity required")
    private int maxAdults;

    @Min(value = 0, message = "Children capacity cannot be negative")
    private int maxChildren;

    @NotBlank(message = "Amenities are required")
    private String amenities;

    @Size(max = 500)
    private String description;

    @Min(value = 1, message = "Floor number must be at least 1")
    private int floorNumber;
}
