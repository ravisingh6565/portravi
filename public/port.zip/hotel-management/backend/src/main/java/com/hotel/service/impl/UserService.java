package com.hotel.service.impl;

import com.hotel.dto.request.RegisterRequest;
import com.hotel.dto.response.UserResponse;
import com.hotel.entity.User;
import com.hotel.enums.Role;
import com.hotel.exception.BusinessException;
import com.hotel.exception.DuplicateResourceException;
import com.hotel.exception.ResourceNotFoundException;
import com.hotel.repository.UserRepository;
import com.hotel.util.IdGenerator;
import com.hotel.util.MapperUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserResponse getProfile() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByUsername(username)
                .map(MapperUtil::toUserResponse)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
    }

    @Transactional
    public UserResponse updateProfile(RegisterRequest request) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        user.setCustomerName(request.getCustomerName());
        user.setAddress(request.getAddress());
        user.setMobile(request.getMobile());

        if (request.getPassword() != null && !request.getPassword().isEmpty()) {
            if (!request.getPassword().equals(request.getConfirmPassword())) {
                throw new BusinessException("Passwords do not match");
            }
            user.setPassword(passwordEncoder.encode(request.getPassword()));
        }

        return MapperUtil.toUserResponse(userRepository.save(user));
    }

    // Admin operations
    public Page<UserResponse> getCustomers(String search, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        if (search != null && !search.isEmpty()) {
            return userRepository.findByRoleAndSearch(Role.ROLE_CUSTOMER, search, pageable)
                    .map(MapperUtil::toUserResponse);
        }
        return userRepository.findByRole(Role.ROLE_CUSTOMER, pageable)
                .map(MapperUtil::toUserResponse);
    }

    public Page<UserResponse> getStaff(String search, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        if (search != null && !search.isEmpty()) {
            return userRepository.findByRoleAndSearch(Role.ROLE_STAFF, search, pageable)
                    .map(MapperUtil::toUserResponse);
        }
        return userRepository.findByRole(Role.ROLE_STAFF, pageable)
                .map(MapperUtil::toUserResponse);
    }

    @Transactional
    public UserResponse createUser(RegisterRequest request, Role role) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new DuplicateResourceException("Username already exists");
        }
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email already registered");
        }

        User user = User.builder()
                .userId(IdGenerator.generateUserId())
                .customerName(request.getCustomerName())
                .email(request.getEmail())
                .mobile(request.getMobile())
                .address(request.getAddress())
                .username(request.getUsername())
                .password(passwordEncoder.encode(request.getPassword() != null ? request.getPassword() : "Password@123"))
                .role(role)
                .active(true)
                .build();

        return MapperUtil.toUserResponse(userRepository.save(user));
    }

    @Transactional
    public void resetPassword(String userId, String newPassword) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        user.setPassword(passwordEncoder.encode(newPassword));
        user.setFailedAttempts(0);
        user.setAccountLocked(false);
        userRepository.save(user);
    }

    @Transactional
    public UserResponse toggleUserStatus(String userId, boolean active) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        user.setActive(active);
        if (active) {
            user.setAccountLocked(false);
            user.setFailedAttempts(0);
        }
        return MapperUtil.toUserResponse(userRepository.save(user));
    }
}
