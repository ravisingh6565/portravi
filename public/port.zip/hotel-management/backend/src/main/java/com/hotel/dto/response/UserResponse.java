package com.hotel.dto.response;

import com.hotel.enums.Role;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class UserResponse {
    private String userId;
    private String customerName;
    private String email;
    private String mobile;
    private String address;
    private String username;
    private Role role;
    private boolean active;
    private boolean accountLocked;
    private LocalDateTime createdAt;
}
