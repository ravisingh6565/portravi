package com.hotel.dto.response;

import com.hotel.enums.ComplaintStatus;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class ComplaintResponse {
    private String complaintId;
    private String customerId;
    private String customerName;
    private String customerEmail;
    private String bookingId;
    private String category;
    private String title;
    private String description;
    private String contactPreference;
    private ComplaintStatus status;
    private String resolutionNotes;
    private LocalDate expectedResolutionDate;
    private String assignedToName;
    private String assignedToId;
    private LocalDateTime resolvedAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
