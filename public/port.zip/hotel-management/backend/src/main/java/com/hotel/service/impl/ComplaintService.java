package com.hotel.service.impl;

import com.hotel.dto.request.ComplaintRequest;
import com.hotel.dto.response.ComplaintResponse;
import com.hotel.entity.*;
import com.hotel.enums.ComplaintStatus;
import com.hotel.exception.BusinessException;
import com.hotel.exception.ResourceNotFoundException;
import com.hotel.repository.*;
import com.hotel.util.IdGenerator;
import com.hotel.util.MapperUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ComplaintService {

    private final ComplaintRepository complaintRepository;
    private final UserRepository userRepository;

    @Transactional
    public ComplaintResponse registerComplaint(ComplaintRequest request) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User customer = userRepository.findByUsername(username).orElseThrow();

        Complaint complaint = Complaint.builder()
                .complaintId(IdGenerator.generateComplaintId())
                .customer(customer)
                .bookingId(request.getBookingId())
                .category(request.getCategory())
                .title(request.getTitle())
                .description(request.getDescription())
                .contactPreference(request.getContactPreference())
                .status(ComplaintStatus.OPEN)
                .expectedResolutionDate(LocalDate.now().plusDays(3))
                .build();

        return MapperUtil.toComplaintResponse(complaintRepository.save(complaint));
    }

    public List<ComplaintResponse> getMyComplaints() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username).orElseThrow();
        return complaintRepository.findByCustomerUserId(user.getUserId())
                .stream().map(MapperUtil::toComplaintResponse).collect(Collectors.toList());
    }

    public ComplaintResponse getComplaintById(String id) {
        return complaintRepository.findById(id)
                .map(MapperUtil::toComplaintResponse)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint not found: " + id));
    }

    @Transactional
    public ComplaintResponse confirmResolution(String id) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint not found"));
        validateOwnership(complaint);
        complaint.setStatus(ComplaintStatus.CLOSED);
        complaint.setResolvedAt(LocalDateTime.now());
        return MapperUtil.toComplaintResponse(complaintRepository.save(complaint));
    }

    @Transactional
    public ComplaintResponse reopenComplaint(String id) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint not found"));
        validateOwnership(complaint);
        if (complaint.getStatus() == ComplaintStatus.OPEN) {
            throw new BusinessException("Complaint is already open");
        }
        complaint.setStatus(ComplaintStatus.REOPENED);
        return MapperUtil.toComplaintResponse(complaintRepository.save(complaint));
    }

    // Admin
    public Page<ComplaintResponse> getAllComplaints(String search, ComplaintStatus status, String category,
                                                     int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return complaintRepository.findWithFilters(search, status, category, pageable)
                .map(MapperUtil::toComplaintResponse);
    }

    @Transactional
    public ComplaintResponse assignComplaint(String id, String staffId, String notes, LocalDate resolutionDate) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint not found"));
        User staff = userRepository.findById(staffId)
                .orElseThrow(() -> new ResourceNotFoundException("Staff not found"));
        complaint.setAssignedTo(staff);
        complaint.setStatus(ComplaintStatus.IN_PROGRESS);
        if (notes != null) complaint.setResolutionNotes(notes);
        if (resolutionDate != null) complaint.setExpectedResolutionDate(resolutionDate);
        return MapperUtil.toComplaintResponse(complaintRepository.save(complaint));
    }

    @Transactional
    public ComplaintResponse updateComplaintStatus(String id, ComplaintStatus status, String notes) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint not found"));
        complaint.setStatus(status);
        if (notes != null) complaint.setResolutionNotes(notes);
        if (status == ComplaintStatus.RESOLVED || status == ComplaintStatus.CLOSED) {
            complaint.setResolvedAt(LocalDateTime.now());
        }
        return MapperUtil.toComplaintResponse(complaintRepository.save(complaint));
    }

    // Staff
    public Page<ComplaintResponse> getAssignedComplaints(ComplaintStatus status, int page, int size) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User staff = userRepository.findByUsername(username).orElseThrow();
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return complaintRepository.findByStaffAndStatus(staff.getUserId(), status, pageable)
                .map(MapperUtil::toComplaintResponse);
    }

    private void validateOwnership(Complaint complaint) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        boolean isAdmin = auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        if (!isAdmin && !complaint.getCustomer().getUsername().equals(auth.getName())) {
            throw new BusinessException("Access denied");
        }
    }
}
