package com.hotel.repository;

import com.hotel.entity.Payment;
import com.hotel.enums.PaymentStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, String> {
    Optional<Payment> findByBookingBookingId(String bookingId);

    @Query("SELECT p FROM Payment p WHERE " +
           "(:search IS NULL OR LOWER(p.transactionId) LIKE LOWER(CONCAT('%',:search,'%')) OR " +
           "LOWER(p.booking.bookingId) LIKE LOWER(CONCAT('%',:search,'%')) OR " +
           "LOWER(p.booking.customer.customerName) LIKE LOWER(CONCAT('%',:search,'%'))) AND " +
           "(:status IS NULL OR p.paymentStatus = :status)")
    Page<Payment> findWithFilters(@Param("search") String search,
                                   @Param("status") PaymentStatus status,
                                   Pageable pageable);
}
