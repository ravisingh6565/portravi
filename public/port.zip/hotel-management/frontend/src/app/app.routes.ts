import { Routes } from '@angular/router';
import { authGuard, adminGuard, staffGuard, guestGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  {
    path: 'register',
    canActivate: [guestGuard],
    loadComponent: () => import('./components/auth/register/register.component').then(m => m.RegisterComponent)
  },
  {
    path: 'register/success',
    loadComponent: () => import('./components/auth/register-success/register-success.component').then(m => m.RegisterSuccessComponent)
  },
  {
    path: 'login',
    canActivate: [guestGuard],
    loadComponent: () => import('./components/auth/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'home',
    canActivate: [authGuard],
    loadComponent: () => import('./components/home/home.component').then(m => m.HomeComponent)
  },
  {
    path: 'search-rooms',
    loadComponent: () => import('./components/rooms/search-rooms/search-rooms.component').then(m => m.SearchRoomsComponent)
  },
  {
    path: 'book/:roomId',
    canActivate: [authGuard],
    loadComponent: () => import('./components/booking/book-room/book-room.component').then(m => m.BookRoomComponent)
  },
  {
    path: 'payment/:bookingId',
    canActivate: [authGuard],
    loadComponent: () => import('./components/booking/payment/payment.component').then(m => m.PaymentComponent)
  },
  {
    path: 'my-bookings',
    canActivate: [authGuard],
    loadComponent: () => import('./components/booking/my-bookings/my-bookings.component').then(m => m.MyBookingsComponent)
  },
  {
    path: 'bookings/:id',
    canActivate: [authGuard],
    loadComponent: () => import('./components/booking/booking-detail/booking-detail.component').then(m => m.BookingDetailComponent)
  },
  {
    path: 'complaints',
    canActivate: [authGuard],
    loadComponent: () => import('./components/complaints/register-complaint/register-complaint.component').then(m => m.RegisterComplaintComponent)
  },
  {
    path: 'my-complaints',
    canActivate: [authGuard],
    loadComponent: () => import('./components/complaints/my-complaints/my-complaints.component').then(m => m.MyComplaintsComponent)
  },
  {
    path: 'profile',
    canActivate: [authGuard],
    loadComponent: () => import('./components/auth/profile/profile.component').then(m => m.ProfileComponent)
  },
  {
    path: 'contact',
    loadComponent: () => import('./components/shared/contact/contact.component').then(m => m.ContactComponent)
  },

  // Admin routes
  {
    path: 'admin',
    canActivate: [adminGuard],
    children: [
      {
        path: 'dashboard',
        loadComponent: () => import('./components/admin/dashboard/dashboard.component').then(m => m.DashboardComponent)
      },
      {
        path: 'rooms',
        loadComponent: () => import('./components/admin/rooms/manage-rooms.component').then(m => m.ManageRoomsComponent)
      },
      {
        path: 'bookings',
        loadComponent: () => import('./components/admin/bookings/manage-bookings.component').then(m => m.ManageBookingsComponent)
      },
      {
        path: 'customers',
        loadComponent: () => import('./components/admin/customers/manage-customers.component').then(m => m.ManageCustomersComponent)
      },
      {
        path: 'bills',
        loadComponent: () => import('./components/admin/bills/manage-bills.component').then(m => m.ManageBillsComponent)
      },
      {
        path: 'complaints',
        loadComponent: () => import('./components/admin/complaints/admin-complaints.component').then(m => m.AdminComplaintsComponent)
      },
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' }
    ]
  },

  // Staff routes
  {
    path: 'staff',
    canActivate: [staffGuard],
    children: [
      {
        path: 'complaints',
        loadComponent: () => import('./components/staff/staff-complaints/staff-complaints.component').then(m => m.StaffComplaintsComponent)
      },
      { path: '', redirectTo: 'complaints', pathMatch: 'full' }
    ]
  },

  { path: '**', redirectTo: '/home' }
];
