export interface User {
  userId: string;
  customerName: string;
  email: string;
  mobile: string;
  address: string;
  username: string;
  role: 'ROLE_ADMIN' | 'ROLE_CUSTOMER' | 'ROLE_STAFF';
  active: boolean;
  accountLocked: boolean;
  createdAt: string;
}

export interface Room {
  id: number;
  roomNumber: string;
  roomType: 'STANDARD' | 'DELUXE' | 'SUITE' | 'EXECUTIVE' | 'PRESIDENTIAL';
  roomStatus: 'AVAILABLE' | 'OCCUPIED' | 'MAINTENANCE' | 'BLOCKED';
  pricePerNight: number;
  maxAdults: number;
  maxChildren: number;
  amenities: string;
  description: string;
  floorNumber: number;
  createdAt: string;
}

export interface Booking {
  bookingId: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  roomId: number;
  roomNumber: string;
  roomType: string;
  checkInDate: string;
  checkOutDate: string;
  totalNights: number;
  adults: number;
  children: number;
  specialRequest: string;
  bookingStatus: 'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'COMPLETED' | 'MODIFIED';
  totalAmount: number;
  taxAmount: number;
  grandTotal: number;
  refundAmount: number;
  paymentMethod: string;
  transactionId: string;
  paymentStatus: string;
  createdAt: string;
}

export interface Payment {
  transactionId: string;
  bookingId: string;
  paymentMethod: string;
  amountPaid: number;
  paymentStatus: 'PENDING' | 'SUCCESS' | 'FAILED' | 'REFUNDED' | 'PARTIAL_REFUND';
  cardholderName: string;
  cardLastFour: string;
  failureReason: string;
  paymentDate: string;
  customerName: string;
}

export interface Complaint {
  complaintId: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  bookingId: string;
  category: string;
  title: string;
  description: string;
  contactPreference: string;
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'CLOSED' | 'REOPENED';
  resolutionNotes: string;
  expectedResolutionDate: string;
  assignedToName: string;
  assignedToId: string;
  resolvedAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface Bill {
  id: number;
  invoiceNumber: string;
  bookingId: string;
  customerName: string;
  roomCharges: number;
  additionalCharges: number;
  discountAmount: number;
  taxPercentage: number;
  taxAmount: number;
  totalAmount: number;
  additionalItems: string;
  notes: string;
  createdAt: string;
}

export interface DashboardData {
  totalBookings: number;
  dailyBookings: number;
  weeklyBookings: number;
  monthlyBookings: number;
  availableRooms: number;
  occupiedRooms: number;
  totalCustomers: number;
  openComplaints: number;
  totalRooms: number;
  bookingsByStatus: { [key: string]: number };
  roomsByType: { [key: string]: number };
}

export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
}

export interface ApiError {
  status: number;
  message: string;
  timestamp: string;
}
