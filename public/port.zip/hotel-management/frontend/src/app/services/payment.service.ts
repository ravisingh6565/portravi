import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Payment, PageResponse } from '../models/models';

@Injectable({ providedIn: 'root' })
export class PaymentService {
  private apiUrl = `${environment.apiUrl}/payments`;

  constructor(private http: HttpClient) {}

  processPayment(data: any): Observable<Payment> {
    return this.http.post<Payment>(`${this.apiUrl}/process`, data);
  }

  getPaymentByBooking(bookingId: string): Observable<Payment> {
    return this.http.get<Payment>(`${this.apiUrl}/booking/${bookingId}`);
  }

  getAllPayments(search?: string, status?: string, page = 0, size = 10): Observable<PageResponse<Payment>> {
    let params = new HttpParams().set('page', page).set('size', size);
    if (search) params = params.set('search', search);
    if (status) params = params.set('status', status);
    return this.http.get<PageResponse<Payment>>(this.apiUrl, { params });
  }

  downloadInvoice(bookingId: string): void {
    this.http.get(`${this.apiUrl}/invoice/${bookingId}`, { responseType: 'blob' }).subscribe(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `invoice_${bookingId}.pdf`;
      a.click();
    });
  }
}
