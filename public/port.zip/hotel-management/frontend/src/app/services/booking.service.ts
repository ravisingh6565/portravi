import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Booking, PageResponse } from '../models/models';

@Injectable({ providedIn: 'root' })
export class BookingService {
  private apiUrl = `${environment.apiUrl}/bookings`;

  constructor(private http: HttpClient) {}

  createBooking(data: any): Observable<Booking> {
    return this.http.post<Booking>(this.apiUrl, data);
  }

  getMyBookings(): Observable<Booking[]> {
    return this.http.get<Booking[]>(`${this.apiUrl}/my`);
  }

  getUpcomingBookings(): Observable<Booking[]> {
    return this.http.get<Booking[]>(`${this.apiUrl}/my/upcoming`);
  }

  getPastBookings(): Observable<Booking[]> {
    return this.http.get<Booking[]>(`${this.apiUrl}/my/past`);
  }

  getBookingById(id: string): Observable<Booking> {
    return this.http.get<Booking>(`${this.apiUrl}/${id}`);
  }

  modifyBooking(id: string, data: any): Observable<Booking> {
    return this.http.put<Booking>(`${this.apiUrl}/${id}/modify`, data);
  }

  cancelBooking(id: string): Observable<Booking> {
    return this.http.patch<Booking>(`${this.apiUrl}/${id}/cancel`, {});
  }

  getAllBookings(params: any): Observable<PageResponse<Booking>> {
    let httpParams = new HttpParams();
    Object.keys(params).forEach(k => { if (params[k] !== null && params[k] !== undefined && params[k] !== '') httpParams = httpParams.set(k, params[k]); });
    return this.http.get<PageResponse<Booking>>(this.apiUrl, { params: httpParams });
  }

  adminCancelBooking(id: string): Observable<Booking> {
    return this.http.patch<Booking>(`${this.apiUrl}/admin/${id}/cancel`, {});
  }

  adminCreateBooking(customerId: string, data: any): Observable<Booking> {
    return this.http.post<Booking>(`${this.apiUrl}/admin/create/${customerId}`, data);
  }

  adminUpdateBooking(id: string, data: any): Observable<Booking> {
    return this.http.put<Booking>(`${this.apiUrl}/admin/${id}`, data);
  }
}
