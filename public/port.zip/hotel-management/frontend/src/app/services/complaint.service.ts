import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Complaint, PageResponse } from '../models/models';

@Injectable({ providedIn: 'root' })
export class ComplaintService {
  private apiUrl = `${environment.apiUrl}/complaints`;

  constructor(private http: HttpClient) {}

  register(data: any): Observable<Complaint> {
    return this.http.post<Complaint>(this.apiUrl, data);
  }

  getMyComplaints(): Observable<Complaint[]> {
    return this.http.get<Complaint[]>(`${this.apiUrl}/my`);
  }

  getById(id: string): Observable<Complaint> {
    return this.http.get<Complaint>(`${this.apiUrl}/${id}`);
  }

  confirmResolution(id: string): Observable<Complaint> {
    return this.http.patch<Complaint>(`${this.apiUrl}/${id}/confirm-resolution`, {});
  }

  reopen(id: string): Observable<Complaint> {
    return this.http.patch<Complaint>(`${this.apiUrl}/${id}/reopen`, {});
  }

  getAll(params: any): Observable<PageResponse<Complaint>> {
    let httpParams = new HttpParams();
    Object.keys(params).forEach(k => { if (params[k] !== null && params[k] !== undefined && params[k] !== '') httpParams = httpParams.set(k, params[k]); });
    return this.http.get<PageResponse<Complaint>>(this.apiUrl, { params: httpParams });
  }

  assignComplaint(id: string, data: any): Observable<Complaint> {
    return this.http.patch<Complaint>(`${this.apiUrl}/admin/${id}/assign`, data);
  }

  updateStatus(id: string, status: string, notes?: string): Observable<Complaint> {
    return this.http.patch<Complaint>(`${this.apiUrl}/admin/${id}/status`, { status, notes });
  }

  getAssigned(status?: string, page = 0, size = 10): Observable<PageResponse<Complaint>> {
    let params = new HttpParams().set('page', page).set('size', size);
    if (status) params = params.set('status', status);
    return this.http.get<PageResponse<Complaint>>(`${this.apiUrl}/staff/assigned`, { params });
  }
}
