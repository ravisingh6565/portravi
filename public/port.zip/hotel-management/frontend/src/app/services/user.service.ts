import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { User, Bill, DashboardData, PageResponse } from '../models/models';

@Injectable({ providedIn: 'root' })
export class UserService {
  private apiUrl = `${environment.apiUrl}/users`;

  constructor(private http: HttpClient) {}

  getProfile(): Observable<User> {
    return this.http.get<User>(`${this.apiUrl}/profile`);
  }

  updateProfile(data: any): Observable<User> {
    return this.http.put<User>(`${this.apiUrl}/profile`, data);
  }

  getCustomers(search?: string, page = 0, size = 10): Observable<PageResponse<User>> {
    let params = new HttpParams().set('page', page).set('size', size);
    if (search) params = params.set('search', search);
    return this.http.get<PageResponse<User>>(`${this.apiUrl}/customers`, { params });
  }

  getStaff(search?: string, page = 0, size = 10): Observable<PageResponse<User>> {
    let params = new HttpParams().set('page', page).set('size', size);
    if (search) params = params.set('search', search);
    return this.http.get<PageResponse<User>>(`${this.apiUrl}/staff`, { params });
  }

  createCustomer(data: any): Observable<User> {
    return this.http.post<User>(`${this.apiUrl}/admin/create-customer`, data);
  }

  createStaff(data: any): Observable<User> {
    return this.http.post<User>(`${this.apiUrl}/admin/create-staff`, data);
  }

  resetPassword(userId: string, newPassword: string): Observable<void> {
    return this.http.patch<void>(`${this.apiUrl}/admin/${userId}/reset-password`, { newPassword });
  }

  toggleUserStatus(userId: string, active: boolean): Observable<User> {
    return this.http.patch<User>(`${this.apiUrl}/admin/${userId}/toggle-status`, { active });
  }

  getDashboard(): Observable<DashboardData> {
    return this.http.get<DashboardData>(`${environment.apiUrl}/admin/dashboard`);
  }

  getAllBills(search?: string, page = 0, size = 10): Observable<PageResponse<Bill>> {
    let params = new HttpParams().set('page', page).set('size', size);
    if (search) params = params.set('search', search);
    return this.http.get<PageResponse<Bill>>(`${environment.apiUrl}/bills`, { params });
  }

  getBillByBooking(bookingId: string): Observable<Bill> {
    return this.http.get<Bill>(`${environment.apiUrl}/bills/booking/${bookingId}`);
  }

  addBillItems(bookingId: string, data: any): Observable<Bill> {
    return this.http.patch<Bill>(`${environment.apiUrl}/bills/booking/${bookingId}/add-items`, data);
  }
}
