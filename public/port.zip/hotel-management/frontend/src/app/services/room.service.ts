import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Room, PageResponse } from '../models/models';

@Injectable({ providedIn: 'root' })
export class RoomService {
  private apiUrl = `${environment.apiUrl}/rooms`;

  constructor(private http: HttpClient) {}

  getAvailableRooms(params: any): Observable<PageResponse<Room>> {
    let httpParams = new HttpParams();
    Object.keys(params).forEach(k => { if (params[k] !== null && params[k] !== undefined && params[k] !== '') httpParams = httpParams.set(k, params[k]); });
    return this.http.get<PageResponse<Room>>(`${this.apiUrl}/available`, { params: httpParams });
  }

  getAllRooms(search?: string, roomType?: string, status?: string, page = 0, size = 10, sort = 'id,asc'): Observable<PageResponse<Room>> {
    let params = new HttpParams().set('page', page).set('size', size).set('sort', sort);
    if (search) params = params.set('search', search);
    if (roomType) params = params.set('roomType', roomType);
    if (status) params = params.set('status', status);
    return this.http.get<PageResponse<Room>>(`${this.apiUrl}/search`, { params });
  }

  getRoomById(id: number): Observable<Room> {
    return this.http.get<Room>(`${this.apiUrl}/${id}`);
  }

  addRoom(data: any): Observable<Room> {
    return this.http.post<Room>(this.apiUrl, data);
  }

  updateRoom(id: number, data: any): Observable<Room> {
    return this.http.put<Room>(`${this.apiUrl}/${id}`, data);
  }

  updateRoomStatus(id: number, status: string): Observable<void> {
    return this.http.patch<void>(`${this.apiUrl}/${id}/status`, null, { params: { status } });
  }

  bulkUpload(file: File): Observable<Room[]> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post<Room[]>(`${this.apiUrl}/bulk-upload`, formData);
  }

  downloadTemplate(): void {
    this.http.get(`${this.apiUrl}/csv-template`, { responseType: 'blob' }).subscribe(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'room_template.csv';
      a.click();
    });
  }
}
