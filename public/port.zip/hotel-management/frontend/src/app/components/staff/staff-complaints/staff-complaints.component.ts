import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { ComplaintService } from '../../../services/complaint.service';
import { NotificationService } from '../../../services/notification.service';
import { Complaint } from '../../../models/models';

@Component({
  selector: 'app-staff-complaints',
  standalone: true,
  imports: [CommonModule, FormsModule, MatCardModule, MatButtonModule, MatIconModule,
    MatFormFieldModule, MatSelectModule, MatPaginatorModule],
  template: `
    <div class="page-container">
      <h1 class="page-title">My Assigned Complaints</h1>

      <mat-card class="filter-card">
        <mat-form-field appearance="outline">
          <mat-label>Filter by Status</mat-label>
          <mat-select [(ngModel)]="filterStatus" (selectionChange)="load()">
            <mat-option value="">All</mat-option>
            <mat-option value="IN_PROGRESS">In Progress</mat-option>
            <mat-option value="OPEN">Open</mat-option>
            <mat-option value="RESOLVED">Resolved</mat-option>
          </mat-select>
        </mat-form-field>
      </mat-card>

      <mat-card class="complaint-card" *ngFor="let c of complaints">
        <div class="complaint-header">
          <div>
            <div class="meta">
              <span class="complaint-id">{{ c.complaintId }}</span>
              <span class="category-tag">{{ c.category }}</span>
            </div>
            <h3>{{ c.title }}</h3>
            <p class="customer">{{ c.customerName }} | {{ c.contactPreference }}</p>
          </div>
          <span class="status-badge status-{{ c.status }}">{{ c.status }}</span>
        </div>

        <p class="description">{{ c.description }}</p>

        <div class="dates">
          <span>Filed: {{ c.createdAt | date:'mediumDate' }}</span>
          <span *ngIf="c.expectedResolutionDate">Expected: {{ c.expectedResolutionDate | date:'mediumDate' }}</span>
          <span *ngIf="c.bookingId">Booking: {{ c.bookingId }}</span>
        </div>

        <div class="resolution" *ngIf="c.resolutionNotes">
          <strong>Notes:</strong> {{ c.resolutionNotes }}
        </div>

        <div class="actions" *ngIf="c.status !== 'CLOSED'">
          <button mat-stroked-button color="accent" (click)="resolve(c)" *ngIf="c.status === 'IN_PROGRESS'">
            <mat-icon>check</mat-icon> Mark Resolved
          </button>
          <button mat-stroked-button color="primary" (click)="addNote(c)">
            <mat-icon>edit_note</mat-icon> Add Note
          </button>
        </div>
      </mat-card>

      <div class="empty-state" *ngIf="complaints.length === 0">
        <mat-icon>assignment_turned_in</mat-icon>
        <p>No complaints assigned to you</p>
      </div>

      <mat-paginator [length]="total" [pageSize]="pageSize" (page)="onPage($event)"></mat-paginator>
    </div>
  `,
  styles: [`
    .filter-card { padding: 16px; margin-bottom: 16px; }
    .complaint-card { margin-bottom: 16px; padding: 20px; }
    .complaint-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; }
    .meta { display: flex; gap: 8px; margin-bottom: 4px; }
    .complaint-id { font-size: 12px; color: #666; font-family: monospace; }
    .category-tag { background: #e3f2fd; color: #1565c0; padding: 2px 8px; border-radius: 12px; font-size: 12px; }
    .complaint-header h3 { margin: 0 0 4px; font-size: 15px; }
    .customer { font-size: 13px; color: #666; }
    .description { color: #555; font-size: 14px; margin-bottom: 8px; }
    .dates { display: flex; gap: 12px; font-size: 13px; color: #666; margin-bottom: 8px; flex-wrap: wrap; }
    .resolution { background: #f0f4ff; padding: 10px; border-radius: 4px; font-size: 13px; margin-bottom: 8px; }
    .actions { display: flex; gap: 8px; }
    .empty-state { text-align: center; padding: 80px; color: #999; }
    .empty-state mat-icon { font-size: 64px; width: 64px; height: 64px; display: block; margin: 0 auto 16px; }
  `]
})
export class StaffComplaintsComponent implements OnInit {
  complaints: Complaint[] = [];
  total = 0;
  pageSize = 10;
  filterStatus = '';

  constructor(private complaintService: ComplaintService, private notify: NotificationService) {}

  ngOnInit(): void { this.load(); }

  load(page = 0): void {
    this.complaintService.getAssigned(this.filterStatus || undefined, page, this.pageSize).subscribe(res => {
      this.complaints = res.content; this.total = res.totalElements;
    });
  }

  onPage(e: PageEvent): void { this.pageSize = e.pageSize; this.load(e.pageIndex); }

  resolve(c: Complaint): void {
    const notes = prompt('Resolution notes:') || '';
    this.complaintService.updateStatus(c.complaintId, 'RESOLVED', notes).subscribe({
      next: updated => {
        const idx = this.complaints.findIndex(x => x.complaintId === c.complaintId);
        this.complaints[idx] = updated;
        this.notify.success('Complaint marked as resolved');
      },
      error: (err) => this.notify.error(err.error?.message || 'Failed')
    });
  }

  addNote(c: Complaint): void {
    const notes = prompt('Add action notes:') || '';
    if (!notes) return;
    this.complaintService.updateStatus(c.complaintId, c.status, notes).subscribe({
      next: updated => {
        const idx = this.complaints.findIndex(x => x.complaintId === c.complaintId);
        this.complaints[idx] = updated;
        this.notify.success('Note added');
      },
      error: (err) => this.notify.error(err.error?.message || 'Failed')
    });
  }
}
