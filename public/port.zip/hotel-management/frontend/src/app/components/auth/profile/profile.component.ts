import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { UserService } from '../../../services/user.service';
import { AuthService } from '../../../services/auth.service';
import { NotificationService } from '../../../services/notification.service';
import { User } from '../../../models/models';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatCardModule, MatButtonModule, MatIconModule,
    MatFormFieldModule, MatInputModule, MatProgressSpinnerModule],
  template: `
    <div class="page-container">
      <h1 class="page-title">My Profile</h1>

      <div class="profile-layout">
        <mat-card class="profile-info">
          <div class="avatar">
            <mat-icon>account_circle</mat-icon>
          </div>
          <h2>{{ user?.customerName }}</h2>
          <p class="role-badge">{{ user?.role?.replace('ROLE_', '') }}</p>
          <div class="info-list">
            <div class="info-item"><mat-icon>alternate_email</mat-icon><span>{{ user?.username }}</span></div>
            <div class="info-item"><mat-icon>email</mat-icon><span>{{ user?.email }}</span></div>
            <div class="info-item"><mat-icon>phone</mat-icon><span>{{ user?.mobile }}</span></div>
            <div class="info-item"><mat-icon>badge</mat-icon><span>{{ user?.userId }}</span></div>
            <div class="info-item"><mat-icon>calendar_today</mat-icon>
              <span>Member since {{ user?.createdAt | date:'mediumDate' }}</span>
            </div>
          </div>
        </mat-card>

        <mat-card class="profile-form">
          <h3>Update Profile</h3>
          <form [formGroup]="form" (ngSubmit)="onSave()">
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Full Name</mat-label>
              <input matInput formControlName="customerName">
              <mat-error *ngIf="f['customerName'].errors?.['required']">Required</mat-error>
              <mat-error *ngIf="f['customerName'].errors?.['minlength']">Min 3 characters</mat-error>
              <mat-error *ngIf="f['customerName'].errors?.['pattern']">Alphabets only</mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Email (read-only)</mat-label>
              <input matInput [value]="user?.email" readonly>
            </mat-form-field>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Mobile</mat-label>
              <input matInput formControlName="mobile" placeholder="+91...">
            </mat-form-field>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Address</mat-label>
              <textarea matInput formControlName="address" rows="3"></textarea>
              <mat-error *ngIf="f['address'].errors?.['minlength']">Min 10 characters</mat-error>
            </mat-form-field>

            <h4>Change Password (optional)</h4>
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>New Password</mat-label>
              <input matInput formControlName="password" type="password">
              <mat-error *ngIf="f['password'].errors?.['pattern']">Need uppercase, lowercase, digit, special char</mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Confirm New Password</mat-label>
              <input matInput formControlName="confirmPassword" type="password">
            </mat-form-field>

            <button mat-raised-button color="primary" type="submit" [disabled]="form.invalid || saving" class="save-btn">
              <mat-spinner diameter="20" *ngIf="saving"></mat-spinner>
              <span *ngIf="!saving"><mat-icon>save</mat-icon> Save Changes</span>
            </button>
          </form>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .profile-layout { display: grid; grid-template-columns: 1fr 1.5fr; gap: 24px; }
    .profile-info { padding: 24px; text-align: center; }
    .avatar mat-icon { font-size: 80px; width: 80px; height: 80px; color: #3f51b5; }
    .profile-info h2 { font-size: 20px; margin: 12px 0 4px; }
    .role-badge { background: #e8eaf6; color: #3f51b5; padding: 4px 12px; border-radius: 12px; display: inline-block; margin-bottom: 16px; font-size: 12px; font-weight: 600; }
    .info-list { text-align: left; }
    .info-item { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; font-size: 14px; color: #555; }
    .info-item mat-icon { color: #3f51b5; font-size: 20px; }
    .profile-form { padding: 24px; }
    .profile-form h3 { margin-bottom: 16px; color: #3f51b5; font-size: 18px; }
    .profile-form h4 { margin: 16px 0 8px; color: #555; font-size: 15px; }
    .full-width { width: 100%; margin-bottom: 8px; }
    .save-btn { width: 100%; height: 48px; display: flex; align-items: center; justify-content: center; gap: 8px; }

    @media (max-width: 768px) { .profile-layout { grid-template-columns: 1fr; } }
  `]
})
export class ProfileComponent implements OnInit {
  form: FormGroup;
  user: User | null = null;
  saving = false;

  constructor(private fb: FormBuilder, private userService: UserService,
              public auth: AuthService, private notify: NotificationService) {
    this.form = this.fb.group({
      customerName: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^[a-zA-Z ]+$/)]],
      mobile: ['', Validators.required],
      address: ['', Validators.minLength(10)],
      password: ['', Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)],
      confirmPassword: ['']
    });
  }

  get f() { return this.form.controls; }

  ngOnInit(): void {
    this.userService.getProfile().subscribe(u => {
      this.user = u;
      this.form.patchValue({ customerName: u.customerName, mobile: u.mobile, address: u.address });
    });
  }

  onSave(): void {
    if (this.form.invalid) return;
    const v = this.form.value;
    if (v.password && v.password !== v.confirmPassword) {
      this.notify.error('Passwords do not match');
      return;
    }
    this.saving = true;
    this.userService.updateProfile(v).subscribe({
      next: u => {
        this.user = u;
        this.saving = false;
        this.notify.success('Profile updated successfully');
      },
      error: (err) => { this.saving = false; this.notify.error(err.error?.message || 'Failed'); }
    });
  }
}
