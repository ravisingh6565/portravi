import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AuthService } from '../../../services/auth.service';
import { NotificationService } from '../../../services/notification.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, MatFormFieldModule, MatInputModule,
    MatButtonModule, MatIconModule, MatCardModule, MatProgressSpinnerModule],
  template: `
    <div class="register-page">
      <mat-card class="register-card">
        <mat-card-header>
          <mat-card-title>
            <h2>Customer Registration</h2>
          </mat-card-title>
          <mat-card-subtitle>Create your account to enjoy our services</mat-card-subtitle>
        </mat-card-header>

        <mat-card-content>
          <form [formGroup]="form" (ngSubmit)="onSubmit()">
            <div class="form-row">
              <mat-form-field appearance="outline" class="form-field">
                <mat-label>Customer Name</mat-label>
                <input matInput formControlName="customerName" placeholder="John Doe">
                <mat-icon matSuffix>person</mat-icon>
                <mat-error *ngIf="f['customerName'].errors?.['required']">Name is required</mat-error>
                <mat-error *ngIf="f['customerName'].errors?.['minlength']">Minimum 3 characters</mat-error>
                <mat-error *ngIf="f['customerName'].errors?.['pattern']">Alphabets only</mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="form-field">
                <mat-label>Email Address</mat-label>
                <input matInput formControlName="email" type="email" placeholder="john@example.com">
                <mat-icon matSuffix>email</mat-icon>
                <mat-error *ngIf="f['email'].errors?.['required']">Email is required</mat-error>
                <mat-error *ngIf="f['email'].errors?.['email']">Invalid email format</mat-error>
              </mat-form-field>
            </div>

            <div class="form-row">
              <mat-form-field appearance="outline" class="form-field">
                <mat-label>Mobile Number</mat-label>
                <input matInput formControlName="mobile" placeholder="+911234567890">
                <mat-icon matSuffix>phone</mat-icon>
                <mat-error *ngIf="f['mobile'].errors?.['required']">Mobile is required</mat-error>
                <mat-error *ngIf="f['mobile'].errors?.['pattern']">Format: +CountryCode + 8-10 digits</mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="form-field">
                <mat-label>Username</mat-label>
                <input matInput formControlName="username" placeholder="johndoe123">
                <mat-icon matSuffix>alternate_email</mat-icon>
                <mat-error *ngIf="f['username'].errors?.['required']">Username is required</mat-error>
                <mat-error *ngIf="f['username'].errors?.['minlength']">Minimum 5 characters</mat-error>
                <mat-error *ngIf="f['username'].errors?.['pattern']">No spaces allowed</mat-error>
              </mat-form-field>
            </div>

            <mat-form-field appearance="outline" class="form-field full-width">
              <mat-label>Address</mat-label>
              <textarea matInput formControlName="address" rows="2" placeholder="Enter your full address"></textarea>
              <mat-icon matSuffix>home</mat-icon>
              <mat-error *ngIf="f['address'].errors?.['required']">Address is required</mat-error>
              <mat-error *ngIf="f['address'].errors?.['minlength']">Minimum 10 characters</mat-error>
            </mat-form-field>

            <div class="form-row">
              <mat-form-field appearance="outline" class="form-field">
                <mat-label>Password</mat-label>
                <input matInput formControlName="password" [type]="showPwd ? 'text' : 'password'">
                <button mat-icon-button matSuffix type="button" (click)="showPwd = !showPwd">
                  <mat-icon>{{ showPwd ? 'visibility_off' : 'visibility' }}</mat-icon>
                </button>
                <mat-error *ngIf="f['password'].errors?.['required']">Password is required</mat-error>
                <mat-error *ngIf="f['password'].errors?.['minlength']">Minimum 8 characters</mat-error>
                <mat-error *ngIf="f['password'].errors?.['pattern']">Need uppercase, lowercase, digit, special char</mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="form-field">
                <mat-label>Confirm Password</mat-label>
                <input matInput formControlName="confirmPassword" [type]="showConfirmPwd ? 'text' : 'password'">
                <button mat-icon-button matSuffix type="button" (click)="showConfirmPwd = !showConfirmPwd">
                  <mat-icon>{{ showConfirmPwd ? 'visibility_off' : 'visibility' }}</mat-icon>
                </button>
                <mat-error *ngIf="f['confirmPassword'].errors?.['required']">Please confirm password</mat-error>
                <mat-error *ngIf="form.errors?.['passwordMismatch']">Passwords do not match</mat-error>
              </mat-form-field>
            </div>

            <div class="password-hints">
              <small>Password must contain: Uppercase, Lowercase, Digit, Special character (&#64;$!%*?&)</small>
            </div>

            <button mat-raised-button color="primary" type="submit"
                    [disabled]="form.invalid || loading" class="submit-btn">
              <mat-spinner diameter="20" *ngIf="loading"></mat-spinner>
              <span *ngIf="!loading">Register</span>
            </button>
          </form>
        </mat-card-content>

        <mat-card-actions>
          <p class="login-link">Already have an account? <a routerLink="/login">Login Now</a></p>
        </mat-card-actions>
      </mat-card>
    </div>
  `,
  styles: [`
    .register-page {
      min-height: calc(100vh - 64px);
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 24px 16px;
    }
    .register-card {
      width: 100%;
      max-width: 700px;
    }
    mat-card-header { margin-bottom: 16px; }
    h2 { font-size: 22px; color: #3f51b5; margin: 0; }
    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }
    .form-field { width: 100%; margin-bottom: 8px; }
    .full-width { grid-column: 1/-1; }
    .password-hints { font-size: 11px; color: #666; margin-bottom: 16px; }
    .submit-btn {
      width: 100%;
      height: 48px;
      font-size: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }
    .login-link { text-align: center; color: #666; }
    .login-link a { color: #3f51b5; font-weight: 600; }

    @media (max-width: 600px) {
      .form-row { grid-template-columns: 1fr; }
    }
  `]
})
export class RegisterComponent {
  form: FormGroup;
  loading = false;
  showPwd = false;
  showConfirmPwd = false;

  constructor(private fb: FormBuilder, private auth: AuthService,
              private router: Router, private notify: NotificationService) {
    this.form = this.fb.group({
      customerName: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^[a-zA-Z ]+$/)]],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, Validators.pattern(/^\+[0-9]{1,3}[0-9]{8,10}$/)]],
      address: ['', [Validators.required, Validators.minLength(10)]],
      username: ['', [Validators.required, Validators.minLength(5), Validators.pattern(/^\S+$/)]],
      password: ['', [Validators.required, Validators.minLength(8),
        Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)]],
      confirmPassword: ['', Validators.required]
    }, { validators: this.passwordMatch });
  }

  get f() { return this.form.controls; }

  passwordMatch(c: AbstractControl) {
    const pass = c.get('password')?.value;
    const conf = c.get('confirmPassword')?.value;
    return pass === conf ? null : { passwordMismatch: true };
  }

  onSubmit(): void {
    if (this.form.invalid) return;
    this.loading = true;
    this.auth.register(this.form.value).subscribe({
      next: (user) => {
        this.loading = false;
        this.router.navigate(['/register/success'], { state: { user } });
      },
      error: (err) => {
        this.loading = false;
        this.notify.error(err.error?.message || 'Registration failed');
      }
    });
  }
}
