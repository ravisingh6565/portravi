import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AuthService } from '../../../services/auth.service';
import { NotificationService } from '../../../services/notification.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, MatFormFieldModule,
    MatInputModule, MatButtonModule, MatIconModule, MatCardModule, MatProgressSpinnerModule],
  template: `
    <div class="login-page">
      <mat-card class="login-card">
        <div class="login-header">
          <mat-icon class="hotel-icon">hotel</mat-icon>
          <h2>Grand Hotel</h2>
          <p>Sign in to your account</p>
        </div>

        <form [formGroup]="form" (ngSubmit)="onSubmit()">
          <mat-form-field appearance="outline" class="form-field">
            <mat-label>Username</mat-label>
            <input matInput formControlName="username" placeholder="Enter username" autocomplete="username">
            <mat-icon matSuffix>person</mat-icon>
            <mat-error *ngIf="f['username'].errors?.['required']">Username is required</mat-error>
          </mat-form-field>

          <mat-form-field appearance="outline" class="form-field">
            <mat-label>Password</mat-label>
            <input matInput formControlName="password" [type]="showPwd ? 'text' : 'password'" autocomplete="current-password">
            <button mat-icon-button matSuffix type="button" (click)="showPwd = !showPwd">
              <mat-icon>{{ showPwd ? 'visibility_off' : 'visibility' }}</mat-icon>
            </button>
            <mat-error *ngIf="f['password'].errors?.['required']">Password is required</mat-error>
          </mat-form-field>

          <div class="error-msg" *ngIf="errorMsg">
            <mat-icon>error_outline</mat-icon>
            {{ errorMsg }}
          </div>

          <div class="forgot-link">
            <a href="#">Forgot Password?</a>
          </div>

          <button mat-raised-button color="primary" type="submit"
                  [disabled]="form.invalid || loading" class="submit-btn">
            <mat-spinner diameter="20" *ngIf="loading"></mat-spinner>
            <span *ngIf="!loading">Sign In</span>
          </button>

          <div class="register-link">
            Don't have an account? <a routerLink="/register">Register Now</a>
          </div>
        </form>

        <div class="demo-credentials">
          <p><strong>Demo Credentials:</strong></p>
          <p>Admin: admin / admin</p>
          <p>Staff: staff1 / Staff&#64;123</p>
        </div>
      </mat-card>
    </div>
  `,
  styles: [`
    .login-page {
      min-height: calc(100vh - 64px);
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 24px 16px;
    }
    .login-card { width: 100%; max-width: 420px; padding: 32px; }
    .login-header { text-align: center; margin-bottom: 24px; }
    .hotel-icon { font-size: 48px; width: 48px; height: 48px; color: #3f51b5; }
    h2 { font-size: 24px; color: #2c3e50; margin: 8px 0 4px; }
    .login-header p { color: #666; }
    .form-field { width: 100%; margin-bottom: 8px; }
    .error-msg {
      display: flex; align-items: center; gap: 8px;
      color: #c62828; background: #ffebee; padding: 8px 12px;
      border-radius: 4px; margin-bottom: 12px; font-size: 13px;
    }
    .forgot-link { text-align: right; margin-bottom: 16px; }
    .forgot-link a { color: #3f51b5; font-size: 13px; }
    .submit-btn { width: 100%; height: 48px; font-size: 16px; display: flex; align-items: center; justify-content: center; gap: 8px; }
    .register-link { text-align: center; margin-top: 16px; color: #666; }
    .register-link a { color: #3f51b5; font-weight: 600; }
    .demo-credentials {
      margin-top: 20px; padding: 12px; background: #f5f5f5;
      border-radius: 4px; font-size: 12px; color: #666;
    }
    .demo-credentials p { margin: 2px 0; }
  `]
})
export class LoginComponent {
  form: FormGroup;
  loading = false;
  showPwd = false;
  errorMsg = '';
  private returnUrl = '/home';

  constructor(private fb: FormBuilder, private auth: AuthService,
              private router: Router, private route: ActivatedRoute,
              private notify: NotificationService) {
    this.form = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
  }

  get f() { return this.form.controls; }

  onSubmit(): void {
    if (this.form.invalid) return;
    this.loading = true;
    this.errorMsg = '';
    const { username, password } = this.form.value;
    this.auth.login(username, password).subscribe({
      next: (user) => {
        this.loading = false;
        this.notify.success(`Welcome back, ${user.customerName}!`);
        if (user.role === 'ROLE_ADMIN') this.router.navigate(['/admin/dashboard']);
        else if (user.role === 'ROLE_STAFF') this.router.navigate(['/staff/complaints']);
        else this.router.navigate([this.returnUrl]);
      },
      error: (err) => {
        this.loading = false;
        this.errorMsg = err.error?.message || 'Login failed. Please try again.';
      }
    });
  }
}
