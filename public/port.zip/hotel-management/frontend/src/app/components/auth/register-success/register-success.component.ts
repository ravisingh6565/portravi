import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-register-success',
  standalone: true,
  imports: [CommonModule, RouterLink, MatCardModule, MatButtonModule, MatIconModule],
  template: `
    <div class="success-page">
      <mat-card class="success-card">
        <div class="success-icon">
          <mat-icon>check_circle</mat-icon>
        </div>
        <h2>Registration Successful!</h2>
        <p class="subtitle">Welcome to Grand Hotel Management System</p>

        <div class="user-info" *ngIf="user">
          <div class="info-row">
            <span class="label">User ID:</span>
            <span class="value user-id">{{ user.userId }}</span>
          </div>
          <div class="info-row">
            <span class="label">Name:</span>
            <span class="value">{{ user.customerName }}</span>
          </div>
          <div class="info-row">
            <span class="label">Email:</span>
            <span class="value">{{ user.email }}</span>
          </div>
        </div>

        <p class="note">Please save your User ID for future reference.</p>

        <button mat-raised-button color="primary" routerLink="/login" class="login-btn">
          <mat-icon>login</mat-icon> Login Now
        </button>
      </mat-card>
    </div>
  `,
  styles: [`
    .success-page {
      min-height: calc(100vh - 64px);
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 24px 16px;
    }
    .success-card {
      width: 100%;
      max-width: 500px;
      text-align: center;
      padding: 32px;
    }
    .success-icon mat-icon {
      font-size: 72px;
      width: 72px;
      height: 72px;
      color: #4caf50;
    }
    h2 { font-size: 26px; color: #2c3e50; margin: 16px 0 8px; }
    .subtitle { color: #666; margin-bottom: 24px; }
    .user-info {
      background: #f5f5f5;
      border-radius: 8px;
      padding: 16px;
      margin: 16px 0;
      text-align: left;
    }
    .info-row { display: flex; gap: 8px; margin-bottom: 8px; }
    .label { font-weight: 600; color: #555; min-width: 80px; }
    .user-id { font-family: monospace; font-weight: 700; color: #3f51b5; font-size: 16px; }
    .note { color: #e57373; font-size: 13px; margin-bottom: 24px; }
    .login-btn { width: 100%; height: 48px; font-size: 16px; }
  `]
})
export class RegisterSuccessComponent {
  user: any;
  constructor(private router: Router) {
    const nav = this.router.getCurrentNavigation();
    this.user = nav?.extras?.state?.['user'] || null;
    if (!this.user) this.router.navigate(['/register']);
  }
}
