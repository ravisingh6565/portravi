import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ComplaintService } from '../../../services/complaint.service';
import { NotificationService } from '../../../services/notification.service';
import { Complaint } from '../../../models/models';

@Component({
  selector: 'app-register-complaint',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule,
    MatButtonModule, MatCardModule, MatIconModule, MatSelectModule, MatProgressSpinnerModule],
  template: `
    <div class="page-container">
      <h1 class="page-title">Register Complaint</h1>

      <!-- Confirmation screen -->
      <mat-card class="success-card" *ngIf="submitted && complaint">
        <mat-icon class="success-icon">check_circle</mat-icon>
        <h2>Complaint Registered Successfully!</h2>
        <div class="complaint-info">
          <div class="info-row"><span>Complaint ID:</span><strong>{{ complaint.complaintId }}</strong></div>
          <div class="info-row"><span>Category:</span><strong>{{ complaint.category }}</strong></div>
          <div class="info-row"><span>Status:</span><span class="status-badge status-{{ complaint.status }}">{{ complaint.status }}</span></div>
          <div class="info-row"><span>Expected Resolution:</span><strong>{{ complaint.expectedResolutionDate | date:'mediumDate' }}</strong></div>
        </div>
        <div class="success-actions">
          <button mat-raised-button color="primary" (click)="resetForm()">Register Another</button>
          <button mat-stroked-button (click)="viewComplaints()">My Complaints</button>
        </div>
      </mat-card>

      <!-- Form -->
      <mat-card class="form-card" *ngIf="!submitted">
        <form [formGroup]="form" (ngSubmit)="onSubmit()">
          <div class="form-row">
            <mat-form-field appearance="outline">
              <mat-label>Category</mat-label>
              <mat-select formControlName="category">
                <mat-option *ngFor="let c of categories" [value]="c">{{ c }}</mat-option>
              </mat-select>
              <mat-error>Required</mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Booking ID (optional)</mat-label>
              <input matInput formControlName="bookingId" placeholder="BKG...">
              <mat-icon matSuffix>book</mat-icon>
            </mat-form-field>
          </div>

          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Title</mat-label>
            <input matInput formControlName="title" placeholder="Brief title for your complaint">
            <mat-hint align="end">{{ form.get('title')?.value?.length || 0 }}/100</mat-hint>
            <mat-error *ngIf="f['title'].errors?.['required']">Required</mat-error>
            <mat-error *ngIf="f['title'].errors?.['minlength']">Minimum 10 characters</mat-error>
            <mat-error *ngIf="f['title'].errors?.['maxlength']">Maximum 100 characters</mat-error>
          </mat-form-field>

          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Description</mat-label>
            <textarea matInput formControlName="description" rows="5"
                      placeholder="Please describe your complaint in detail..."></textarea>
            <mat-hint align="end">{{ form.get('description')?.value?.length || 0 }}/500</mat-hint>
            <mat-error *ngIf="f['description'].errors?.['required']">Required</mat-error>
            <mat-error *ngIf="f['description'].errors?.['minlength']">Minimum 20 characters</mat-error>
            <mat-error *ngIf="f['description'].errors?.['maxlength']">Maximum 500 characters</mat-error>
          </mat-form-field>

          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Preferred Contact Method</mat-label>
            <mat-select formControlName="contactPreference">
              <mat-option value="EMAIL">Email</mat-option>
              <mat-option value="PHONE">Phone</mat-option>
              <mat-option value="IN_PERSON">In Person</mat-option>
            </mat-select>
          </mat-form-field>

          <button mat-raised-button color="primary" type="submit"
                  [disabled]="form.invalid || loading" class="submit-btn">
            <mat-spinner diameter="20" *ngIf="loading"></mat-spinner>
            <span *ngIf="!loading"><mat-icon>send</mat-icon> Submit Complaint</span>
          </button>
        </form>
      </mat-card>
    </div>
  `,
  styles: [`
    .form-card { max-width: 700px; margin: 0 auto; padding: 24px; }
    .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .full-width { width: 100%; margin-bottom: 8px; }
    .submit-btn { width: 100%; height: 48px; font-size: 15px; display: flex; align-items: center; justify-content: center; gap: 8px; }
    .success-card { max-width: 500px; margin: 40px auto; padding: 32px; text-align: center; }
    .success-icon { font-size: 72px; width: 72px; height: 72px; color: #4caf50; }
    .success-card h2 { font-size: 22px; margin: 16px 0; }
    .complaint-info { background: #f5f5f5; border-radius: 8px; padding: 16px; margin: 16px 0; text-align: left; }
    .info-row { display: flex; gap: 8px; margin-bottom: 8px; font-size: 14px; align-items: center; }
    .info-row span:first-child { color: #666; min-width: 140px; }
    .success-actions { display: flex; gap: 12px; justify-content: center; }

    @media (max-width: 600px) {
      .form-row { grid-template-columns: 1fr; }
    }
  `]
})
export class RegisterComplaintComponent {
  form: FormGroup;
  loading = false;
  submitted = false;
  complaint: Complaint | null = null;

  categories = ['Room Quality', 'Staff Behavior', 'Food & Beverage', 'Facilities', 'Billing', 'Safety', 'Housekeeping', 'Other'];

  constructor(private fb: FormBuilder, private complaintService: ComplaintService,
              private notify: NotificationService, private router: Router) {
    this.form = this.fb.group({
      category: ['', Validators.required],
      bookingId: [''],
      title: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(100)]],
      description: ['', [Validators.required, Validators.minLength(20), Validators.maxLength(500)]],
      contactPreference: ['EMAIL', Validators.required]
    });
  }

  get f() { return this.form.controls; }

  onSubmit(): void {
    if (this.form.invalid) return;
    this.loading = true;
    this.complaintService.register(this.form.value).subscribe({
      next: (c) => {
        this.loading = false;
        this.complaint = c;
        this.submitted = true;
        this.notify.success(`Complaint ${c.complaintId} registered!`);
      },
      error: (err) => {
        this.loading = false;
        this.notify.error(err.error?.message || 'Failed to register complaint');
      }
    });
  }

  resetForm(): void {
    this.submitted = false;
    this.complaint = null;
    this.form.reset({ contactPreference: 'EMAIL' });
  }

  viewComplaints(): void {
    this.router.navigate(['/my-complaints']);
  }
}
