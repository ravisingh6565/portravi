import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatExpansionModule } from '@angular/material/expansion';
import { ComplaintService } from '../../../services/complaint.service';
import { NotificationService } from '../../../services/notification.service';
import { Complaint } from '../../../models/models';

@Component({
  selector: 'app-my-complaints',
  standalone: true,
  imports: [CommonModule, RouterLink, MatCardModule, MatButtonModule, MatIconModule, MatExpansionModule],
  template: `
    <div class="page-container">
      <div class="header-row">
        <h1 class="page-title">My Complaints</h1>
        <button mat-raised-button color="primary" routerLink="/complaints">
          <mat-icon>add</mat-icon> New Complaint
        </button>
      </div>

      <mat-card class="complaint-card" *ngFor="let c of complaints">
        <div class="complaint-header">
          <div class="complaint-title">
            <h3>{{ c.title }}</h3>
            <div class="meta">
              <span class="complaint-id">{{ c.complaintId }}</span>
              <span class="category-tag">{{ c.category }}</span>
            </div>
          </div>
          <span class="status-badge status-{{ c.status }}">{{ c.status }}</span>
        </div>

        <div class="complaint-body">
          <p class="description">{{ c.description }}</p>
          <div class="complaint-info">
            <span *ngIf="c.bookingId"><mat-icon>book</mat-icon> {{ c.bookingId }}</span>
            <span><mat-icon>event</mat-icon> Filed: {{ c.createdAt | date:'mediumDate' }}</span>
            <span *ngIf="c.expectedResolutionDate">
              <mat-icon>schedule</mat-icon> Expected: {{ c.expectedResolutionDate | date:'mediumDate' }}
            </span>
            <span *ngIf="c.assignedToName">
              <mat-icon>support_agent</mat-icon> Assigned to: {{ c.assignedToName }}
            </span>
          </div>
          <div class="resolution" *ngIf="c.resolutionNotes">
            <strong>Resolution Notes:</strong> {{ c.resolutionNotes }}
          </div>
        </div>

        <div class="complaint-actions">
          <button mat-stroked-button color="primary" (click)="confirmResolution(c)"
                  *ngIf="c.status === 'RESOLVED'">
            <mat-icon>check</mat-icon> Confirm Resolution
          </button>
          <button mat-stroked-button color="warn" (click)="reopen(c)"
                  *ngIf="c.status === 'RESOLVED' || c.status === 'CLOSED'">
            <mat-icon>refresh</mat-icon> Reopen
          </button>
          <span class="closed-note" *ngIf="c.status === 'CLOSED'">This complaint is closed and read-only</span>
        </div>
      </mat-card>

      <div class="empty-state" *ngIf="complaints.length === 0">
        <mat-icon>chat_bubble_outline</mat-icon>
        <p>No complaints registered</p>
        <button mat-raised-button color="primary" routerLink="/complaints">Register Complaint</button>
      </div>
    </div>
  `,
  styles: [`
    .header-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
    .complaint-card { margin-bottom: 16px; padding: 20px; }
    .complaint-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px; }
    .complaint-title h3 { margin: 0 0 4px; font-size: 16px; }
    .meta { display: flex; gap: 8px; }
    .complaint-id { font-size: 12px; color: #666; font-family: monospace; }
    .category-tag { background: #e3f2fd; color: #1565c0; padding: 2px 8px; border-radius: 12px; font-size: 12px; }
    .description { color: #555; font-size: 14px; margin-bottom: 12px; }
    .complaint-info { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 8px; font-size: 13px; color: #666; }
    .complaint-info span { display: flex; align-items: center; gap: 4px; }
    .complaint-info mat-icon { font-size: 14px; }
    .resolution { background: #f0f4ff; padding: 10px; border-radius: 4px; font-size: 13px; margin-bottom: 12px; }
    .complaint-actions { display: flex; gap: 8px; flex-wrap: wrap; }
    .closed-note { color: #999; font-size: 13px; display: flex; align-items: center; }
    .empty-state { text-align: center; padding: 80px; color: #999; }
    .empty-state mat-icon { font-size: 64px; width: 64px; height: 64px; display: block; margin: 0 auto 16px; }
    .page-title { margin: 0; }
  `]
})
export class MyComplaintsComponent implements OnInit {
  complaints: Complaint[] = [];

  constructor(private complaintService: ComplaintService, private notify: NotificationService) {}

  ngOnInit(): void {
    this.complaintService.getMyComplaints().subscribe(c => this.complaints = c);
  }

  confirmResolution(c: Complaint): void {
    this.complaintService.confirmResolution(c.complaintId).subscribe({
      next: updated => {
        const idx = this.complaints.findIndex(x => x.complaintId === c.complaintId);
        this.complaints[idx] = updated;
        this.notify.success('Resolution confirmed. Complaint closed.');
      },
      error: (err) => this.notify.error(err.error?.message || 'Failed')
    });
  }

  reopen(c: Complaint): void {
    this.complaintService.reopen(c.complaintId).subscribe({
      next: updated => {
        const idx = this.complaints.findIndex(x => x.complaintId === c.complaintId);
        this.complaints[idx] = updated;
        this.notify.success('Complaint reopened');
      },
      error: (err) => this.notify.error(err.error?.message || 'Failed')
    });
  }
}
