import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatDividerModule } from '@angular/material/divider';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, MatToolbarModule, MatButtonModule, MatIconModule, MatMenuModule, MatDividerModule],
  template: `
    <mat-toolbar color="primary" class="navbar">
      <div class="nav-brand">
        <mat-icon>hotel</mat-icon>
        <span class="brand-name">Grand Hotel</span>
      </div>

      <!-- Desktop nav -->
      <nav class="desktop-nav" *ngIf="auth.isLoggedIn">
        <ng-container *ngIf="auth.isCustomer || auth.isAdmin">
          <a mat-button routerLink="/home" routerLinkActive="active-link">Home</a>
          <a mat-button routerLink="/search-rooms" routerLinkActive="active-link">Search Rooms</a>
          <a mat-button routerLink="/my-bookings" routerLinkActive="active-link" *ngIf="auth.isCustomer">My Bookings</a>
          <a mat-button routerLink="/complaints" routerLinkActive="active-link" *ngIf="auth.isCustomer">Register Complaint</a>
          <a mat-button routerLink="/my-complaints" routerLinkActive="active-link" *ngIf="auth.isCustomer">Track Complaints</a>
          <a mat-button routerLink="/contact" routerLinkActive="active-link">Contact Us</a>
        </ng-container>

        <ng-container *ngIf="auth.isAdmin">
          <a mat-button routerLink="/admin/dashboard" routerLinkActive="active-link">Dashboard</a>
          <a mat-button routerLink="/admin/rooms" routerLinkActive="active-link">Rooms</a>
          <a mat-button routerLink="/admin/bookings" routerLinkActive="active-link">Reservations</a>
          <a mat-button routerLink="/admin/customers" routerLinkActive="active-link">Customers</a>
          <a mat-button routerLink="/admin/bills" routerLinkActive="active-link">Bills</a>
          <a mat-button routerLink="/admin/complaints" routerLinkActive="active-link">Complaints</a>
        </ng-container>

        <ng-container *ngIf="auth.isStaff">
          <a mat-button routerLink="/staff/complaints" routerLinkActive="active-link">My Assignments</a>
        </ng-container>
      </nav>

      <span class="spacer"></span>

      <!-- User menu -->
      <ng-container *ngIf="auth.isLoggedIn; else guestNav">
        <button mat-button [matMenuTriggerFor]="userMenu" class="user-menu-btn">
          <mat-icon>account_circle</mat-icon>
          <span class="user-name">{{ auth.currentUser?.customerName }}</span>
          <mat-icon>arrow_drop_down</mat-icon>
        </button>
        <mat-menu #userMenu="matMenu">
          <button mat-menu-item routerLink="/profile">
            <mat-icon>person</mat-icon> Profile
          </button>
          <button mat-menu-item (click)="logout()">
            <mat-icon>logout</mat-icon> Logout
          </button>
        </mat-menu>
      </ng-container>

      <ng-template #guestNav>
        <a mat-button routerLink="/login">Login</a>
        <a mat-raised-button color="accent" routerLink="/register">Register</a>
      </ng-template>

      <!-- Mobile menu -->
      <button mat-icon-button [matMenuTriggerFor]="mobileMenu" class="mobile-menu-btn">
        <mat-icon>menu</mat-icon>
      </button>
      <mat-menu #mobileMenu="matMenu">
        <ng-container *ngIf="auth.isLoggedIn">
          <button mat-menu-item routerLink="/home" *ngIf="!auth.isStaff">Home</button>
          <button mat-menu-item routerLink="/search-rooms" *ngIf="!auth.isStaff">Search Rooms</button>
          <button mat-menu-item routerLink="/my-bookings" *ngIf="auth.isCustomer">My Bookings</button>
          <button mat-menu-item routerLink="/complaints" *ngIf="auth.isCustomer">Register Complaint</button>
          <button mat-menu-item routerLink="/my-complaints" *ngIf="auth.isCustomer">Track Complaints</button>
          <button mat-menu-item routerLink="/admin/dashboard" *ngIf="auth.isAdmin">Dashboard</button>
          <button mat-menu-item routerLink="/admin/rooms" *ngIf="auth.isAdmin">Rooms</button>
          <button mat-menu-item routerLink="/admin/bookings" *ngIf="auth.isAdmin">Reservations</button>
          <button mat-menu-item routerLink="/admin/customers" *ngIf="auth.isAdmin">Customers</button>
          <button mat-menu-item routerLink="/admin/bills" *ngIf="auth.isAdmin">Bills</button>
          <button mat-menu-item routerLink="/admin/complaints" *ngIf="auth.isAdmin">Complaints</button>
          <button mat-menu-item routerLink="/staff/complaints" *ngIf="auth.isStaff">My Assignments</button>
          <mat-divider></mat-divider>
          <button mat-menu-item routerLink="/profile">Profile</button>
          <button mat-menu-item (click)="logout()">Logout</button>
        </ng-container>
        <ng-container *ngIf="!auth.isLoggedIn">
          <button mat-menu-item routerLink="/login">Login</button>
          <button mat-menu-item routerLink="/register">Register</button>
        </ng-container>
      </mat-menu>
    </mat-toolbar>
  `,
  styles: [`
    .navbar {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
    }
    .nav-brand {
      display: flex;
      align-items: center;
      gap: 8px;
      text-decoration: none;
      color: white;
    }
    .brand-name {
      font-size: 18px;
      font-weight: 600;
    }
    .desktop-nav {
      display: flex;
      gap: 4px;
      margin-left: 16px;
    }
    .spacer { flex: 1; }
    .user-menu-btn { display: flex; align-items: center; gap: 4px; }
    .user-name { max-width: 120px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .active-link { background: rgba(255,255,255,0.15); border-radius: 4px; }
    .mobile-menu-btn { display: none !important; }

    @media (max-width: 960px) {
      .desktop-nav { display: none; }
      .mobile-menu-btn { display: flex !important; }
      .user-menu-btn .user-name { display: none; }
    }
  `]
})
export class NavbarComponent {
  constructor(public auth: AuthService, private router: Router) {}

  logout(): void {
    this.auth.logout();
  }
}
