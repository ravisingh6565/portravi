import { Component } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <footer class="footer">
      <div class="footer-content">
        <div class="footer-section">
          <div class="footer-brand">
            <mat-icon>hotel</mat-icon>
            <h3>Grand Hotel & Resort</h3>
          </div>
          <p>Experience luxury and comfort like never before. Your perfect stay awaits.</p>
        </div>
        <div class="footer-section">
          <h4>Quick Links</h4>
          <ul>
            <li>Home</li>
            <li>Rooms & Suites</li>
            <li>Contact Us</li>
            <li>Booking Policy</li>
          </ul>
        </div>
        <div class="footer-section">
          <h4>Contact Info</h4>
          <p><mat-icon style="font-size:14px;vertical-align:middle">location_on</mat-icon> 123 Hotel Street, City - 400001</p>
          <p><mat-icon style="font-size:14px;vertical-align:middle">phone</mat-icon> +91-9876543210</p>
          <p><mat-icon style="font-size:14px;vertical-align:middle">email</mat-icon> hotel&#64;grand.com</p>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; 2024 Grand Hotel Management System. All rights reserved.</p>
      </div>
    </footer>
  `,
  styles: [`
    .footer {
      background: #2c3e50;
      color: #ecf0f1;
      margin-top: auto;
    }
    .footer-content {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr;
      gap: 32px;
      max-width: 1200px;
      margin: 0 auto;
      padding: 40px 16px;
    }
    .footer-brand {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 12px;
    }
    .footer-brand h3 { font-size: 18px; }
    .footer-section p { color: #bdc3c7; line-height: 1.6; }
    .footer-section h4 { margin-bottom: 12px; color: #e74c3c; }
    .footer-section ul { list-style: none; }
    .footer-section ul li { color: #bdc3c7; margin-bottom: 6px; cursor: pointer; }
    .footer-section ul li:hover { color: white; }
    .footer-bottom {
      text-align: center;
      padding: 16px;
      background: #1a252f;
      color: #7f8c8d;
      font-size: 13px;
    }

    @media (max-width: 768px) {
      .footer-content {
        grid-template-columns: 1fr;
        gap: 24px;
      }
    }
  `]
})
export class FooterComponent {}
