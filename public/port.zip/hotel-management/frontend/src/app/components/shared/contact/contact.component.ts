import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatIconModule],
  template: `
    <div class="page-container">
      <h1 class="page-title">Contact Us</h1>
      <div class="contact-layout">
        <mat-card class="contact-info">
          <h2>Grand Hotel & Resort</h2>
          <div class="contact-item">
            <mat-icon color="primary">location_on</mat-icon>
            <div><strong>Address</strong><p>123 Hotel Street, City - 400001</p></div>
          </div>
          <div class="contact-item">
            <mat-icon color="primary">phone</mat-icon>
            <div><strong>Phone</strong><p>+91-9876543210</p></div>
          </div>
          <div class="contact-item">
            <mat-icon color="primary">email</mat-icon>
            <div><strong>Email</strong><p>hotel&#64;grand.com</p></div>
          </div>
          <div class="contact-item">
            <mat-icon color="primary">access_time</mat-icon>
            <div><strong>Hours</strong><p>24/7 - We're always here for you</p></div>
          </div>
        </mat-card>
        <mat-card class="map-placeholder">
          <div class="map-img">
            <mat-icon>map</mat-icon>
            <p>Grand Hotel & Resort</p>
            <p>123 Hotel Street, City - 400001</p>
          </div>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .contact-layout { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
    .contact-info { padding: 24px; }
    .contact-info h2 { color: #3f51b5; margin-bottom: 24px; }
    .contact-item { display: flex; gap: 16px; margin-bottom: 20px; align-items: flex-start; }
    .contact-item mat-icon { font-size: 28px; width: 28px; height: 28px; margin-top: 2px; }
    .contact-item strong { display: block; margin-bottom: 4px; }
    .contact-item p { color: #666; margin: 0; }
    .map-placeholder { display: flex; align-items: center; justify-content: center; min-height: 300px; }
    .map-img { text-align: center; color: #666; }
    .map-img mat-icon { font-size: 80px; width: 80px; height: 80px; color: #3f51b5; }
    @media (max-width: 768px) { .contact-layout { grid-template-columns: 1fr; } }
  `]
})
export class ContactComponent {}
