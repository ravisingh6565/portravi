import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { ComplaintService } from '../../../services/complaint.service';
import { UserService } from '../../../services/user.service';
import { NotificationService } from '../../../services/notification.service';
import { Complaint, User } from '../../../models/models';

@Component({
  selector: 'app-admin-complaints',
  standalone: true,
  imports: [CommonModule, FormsModule, MatCardModule, MatButtonModule, MatIconModule,
    MatFormFieldModule, MatInputModule, MatSelectModule, MatTableModule, MatPaginatorModule],
  template: `
    <div class="page-container">
      <h1 class="page-title">Manage Complaints</h1>

      <mat-card class="filter-card">
        <div class="filter-row">
          <mat-form-field appearance="outline" class="filter-field">
            <mat-label>Search</mat-label>
            <input matInput [(ngModel)]="search" (input)="load()" placeholder="Complaint ID, customer, title...">
            <mat-icon matSuffix>search</mat-icon>
          </mat-form-field>
          <mat-form-field appearance="outline" class="filter-field">
            <mat-label>Status</mat-label>
            <mat-select [(ngModel)]="filterStatus" (selectionChange)="load()">
              <mat-option value="">All</mat-option>
              <mat-option value="OPEN">Open</mat-option>
              <mat-option value="IN_PROGRESS">In Progress</mat-option>
              <mat-option value="RESOLVED">Resolved</mat-option>
              <mat-option value="CLOSED">Closed</mat-option>
            </mat-select>
          </mat-form-field>
          <mat-form-field appearance="outline" class="filter-field">
            <mat-label>Category</mat-label>
            <mat-select [(ngModel)]="filterCategory" (selectionChange)="load()">
              <mat-option value="">All</mat-option>
              <mat-option *ngFor="let c of categories" [value]="c">{{ c }}</mat-option>
            </mat-select>
          </mat-form-field>
        </div>
      </mat-card>

      <mat-card class="complaint-card" *ngFor="let c of complaints">
        <div class="complaint-header">
          <div>
            <div class="complaint-meta">
              <span class="complaint-id">{{ c.complaintId }}</span>
              <span class="category-tag">{{ c.category }}</span>
            </div>
            <h3>{{ c.title }}</h3>
            <p class="customer-info">{{ c.customerName }} | {{ c.customerEmail }}</p>
          </div>
          <span class="status-badge status-{{ c.status }}">{{ c.status }}</span>
        </div>
        <p class="description">{{ c.description }}</p>

        <div class="complaint-footer">
          <div class="dates">
            <span>Filed: {{ c.createdAt | date:'mediumDate' }}</span>
            <span *ngIf="c.expectedResolutionDate">Expected: {{ c.expectedResolutionDate | date:'mediumDate' }}</span>
            <span *ngIf="c.assignedToName">Assigned to: <strong>{{ c.assignedToName }}</strong></span>
          </div>
          <div class="complaint-actions">
            <mat-select placeholder="Assign to Staff" class="assign-select" *ngIf="c.status === 'OPEN'"
                        (selectionChange)="assign(c, $event.value)">
              <mat-option *ngFor="let s of staffList" [value]="s.userId">{{ s.customerName }}</mat-option>
            </mat-select>
            <button mat-stroked-button color="primary" (click)="updateStatus(c, 'IN_PROGRESS')" *ngIf="c.status === 'OPEN' || c.status === 'REOPENED'">
              <mat-icon>play_arrow</mat-icon> Start
            </button>
            <button mat-stroked-button color="accent" (click)="updateStatus(c, 'RESOLVED')" *ngIf="c.status === 'IN_PROGRESS'">
              <mat-icon>check</mat-icon> Resolve
            </button>
            <button mat-stroked-button (click)="updateStatus(c, 'CLOSED')" *ngIf="c.status === 'RESOLVED'">
              <mat-icon>lock</mat-icon> Close
            </button>
          </div>
        </div>

        <div class="resolution" *ngIf="c.resolutionNotes">
          <strong>Notes:</strong> {{ c.resolutionNotes }}
        </div>
      </mat-card>

      <div class="empty-state" *ngIf="complaints.length === 0">
        <mat-icon>chat_bubble_outline</mat-icon>
        <p>No complaints found</p>
      </div>

      <mat-paginator [length]="total" [pageSize]="pageSize" [pageSizeOptions]="[10, 20]"
                     (page)="onPage($event)"></mat-paginator>
    </div>
  `,
  styles: [`
    .filter-card { padding: 16px; margin-bottom: 16px; }
    .filter-row { display: flex; gap: 16px; flex-wrap: wrap; }
    .filter-field { flex: 1; min-width: 150px; }
    .complaint-card { margin-bottom: 16px; padding: 20px; }
    .complaint-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; }
    .complaint-meta { display: flex; gap: 8px; margin-bottom: 4px; }
    .complaint-id { font-size: 12px; color: #666; font-family: monospace; }
    .category-tag { background: #e3f2fd; color: #1565c0; padding: 2px 8px; border-radius: 12px; font-size: 12px; }
    .complaint-header h3 { margin: 0 0 4px; font-size: 15px; }
    .customer-info { font-size: 13px; color: #666; }
    .description { color: #555; font-size: 14px; margin-bottom: 12px; }
    .complaint-footer { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; }
    .dates { display: flex; flex-wrap: wrap; gap: 12px; font-size: 13px; color: #666; }
    .complaint-actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
    .assign-select { width: 180px; }
    .resolution { background: #f0f4ff; padding: 10px; border-radius: 4px; font-size: 13px; margin-top: 8px; }
    .empty-state { text-align: center; padding: 80px; color: #999; }
    .empty-state mat-icon { font-size: 64px; width: 64px; height: 64px; display: block; margin: 0 auto 16px; }
  `]
})
export class AdminComplaintsComponent implements OnInit {
  complaints: Complaint[] = [];
  staffList: User[] = [];
  total = 0;
  pageSize = 10;
  search = '';
  filterStatus = '';
  filterCategory = '';
  categories = ['Room Quality', 'Staff Behavior', 'Food & Beverage', 'Facilities', 'Billing', 'Safety', 'Housekeeping', 'Other'];

  constructor(private complaintService: ComplaintService, private userService: UserService,
              private notify: NotificationService) {}

  ngOnInit(): void {
    this.load();
    this.userService.getStaff(undefined, 0, 100).subscribe(res => this.staffList = res.content);
  }

  load(page = 0): void {
    const params: any = { page, size: this.pageSize };
    if (this.search) params.search = this.search;
    if (this.filterStatus) params.status = this.filterStatus;
    if (this.filterCategory) params.category = this.filterCategory;
    this.complaintService.getAll(params).subscribe(res => {
      this.complaints = res.content; this.total = res.totalElements;
    });
  }

  onPage(e: PageEvent): void { this.pageSize = e.pageSize; this.load(e.pageIndex); }

  assign(c: Complaint, staffId: string): void {
    const notes = prompt('Resolution notes (optional):') || '';
    this.complaintService.assignComplaint(c.complaintId, { staffId, notes }).subscribe({
      next: updated => {
        const idx = this.complaints.findIndex(x => x.complaintId === c.complaintId);
        this.complaints[idx] = updated;
        this.notify.success('Complaint assigned');
      },
      error: (err) => this.notify.error(err.error?.message || 'Failed')
    });
  }

  updateStatus(c: Complaint, status: string): void {
    const notes = prompt('Add notes (optional):') || '';
    this.complaintService.updateStatus(c.complaintId, status, notes).subscribe({
      next: updated => {
        const idx = this.complaints.findIndex(x => x.complaintId === c.complaintId);
        this.complaints[idx] = updated;
        this.notify.success(`Status updated to ${status}`);
      },
      error: (err) => this.notify.error(err.error?.message || 'Failed')
    });
  }
}
