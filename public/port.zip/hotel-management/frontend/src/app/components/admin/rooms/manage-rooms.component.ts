import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatExpansionModule } from '@angular/material/expansion';
import { RoomService } from '../../../services/room.service';
import { NotificationService } from '../../../services/notification.service';
import { Room } from '../../../models/models';

@Component({
  selector: 'app-manage-rooms',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, MatCardModule, MatButtonModule, MatIconModule,
    MatFormFieldModule, MatInputModule, MatSelectModule, MatTableModule, MatPaginatorModule,
    MatSortModule, MatDialogModule, MatProgressSpinnerModule, MatExpansionModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1 class="page-title">Manage Rooms</h1>
        <div class="header-actions">
          <button mat-stroked-button (click)="downloadTemplate()">
            <mat-icon>download</mat-icon> CSV Template
          </button>
          <label mat-stroked-button color="accent" class="upload-label">
            <mat-icon>upload</mat-icon> Bulk Upload
            <input type="file" accept=".csv" (change)="bulkUpload($event)" hidden>
          </label>
          <button mat-raised-button color="primary" (click)="showAddForm = !showAddForm">
            <mat-icon>add</mat-icon> Add Room
          </button>
        </div>
      </div>

      <!-- Add Room Form -->
      <mat-expansion-panel [expanded]="showAddForm" (closed)="showAddForm = false" class="add-form-panel">
        <mat-expansion-panel-header>
          <mat-panel-title>{{ editingRoom ? 'Edit Room' : 'Add New Room' }}</mat-panel-title>
        </mat-expansion-panel-header>
        <form [formGroup]="roomForm" (ngSubmit)="onSubmit()">
          <div class="form-grid">
            <mat-form-field appearance="outline">
              <mat-label>Room Type</mat-label>
              <mat-select formControlName="roomType">
                <mat-option *ngFor="let t of roomTypes" [value]="t">{{ t }}</mat-option>
              </mat-select>
              <mat-error>Required</mat-error>
            </mat-form-field>
            <mat-form-field appearance="outline">
              <mat-label>Price per Night (₹)</mat-label>
              <input matInput type="number" formControlName="pricePerNight">
              <mat-error>Required (positive value)</mat-error>
            </mat-form-field>
            <mat-form-field appearance="outline">
              <mat-label>Max Adults</mat-label>
              <input matInput type="number" formControlName="maxAdults" min="1">
              <mat-error>Required (min 1)</mat-error>
            </mat-form-field>
            <mat-form-field appearance="outline">
              <mat-label>Max Children</mat-label>
              <input matInput type="number" formControlName="maxChildren" min="0">
            </mat-form-field>
            <mat-form-field appearance="outline">
              <mat-label>Floor Number</mat-label>
              <input matInput type="number" formControlName="floorNumber" min="1">
            </mat-form-field>
            <mat-form-field appearance="outline" *ngIf="!editingRoom">
              <mat-label>Room Number (auto if empty)</mat-label>
              <input matInput formControlName="roomNumber">
            </mat-form-field>
          </div>
          <mat-form-field appearance="outline" style="width:100%">
            <mat-label>Amenities (comma-separated)</mat-label>
            <input matInput formControlName="amenities" placeholder="WiFi, AC, TV, Mini Bar">
            <mat-error>Required</mat-error>
          </mat-form-field>
          <mat-form-field appearance="outline" style="width:100%">
            <mat-label>Description</mat-label>
            <textarea matInput formControlName="description" rows="2"></textarea>
          </mat-form-field>
          <div class="form-actions">
            <button mat-raised-button color="primary" type="submit" [disabled]="roomForm.invalid || saving">
              <mat-spinner diameter="16" *ngIf="saving"></mat-spinner>
              {{ editingRoom ? 'Update Room' : 'Add Room' }}
            </button>
            <button mat-stroked-button type="button" (click)="cancelEdit()">Cancel</button>
          </div>
        </form>
      </mat-expansion-panel>

      <!-- Filter row -->
      <mat-card class="filter-card">
        <div class="filter-row">
          <mat-form-field appearance="outline" class="filter-field">
            <mat-label>Search</mat-label>
            <input matInput [(ngModel)]="searchQuery" (input)="loadRooms()" placeholder="Room number...">
            <mat-icon matSuffix>search</mat-icon>
          </mat-form-field>
          <mat-form-field appearance="outline" class="filter-field">
            <mat-label>Room Type</mat-label>
            <mat-select [(ngModel)]="filterType" (selectionChange)="loadRooms()">
              <mat-option value="">All Types</mat-option>
              <mat-option *ngFor="let t of roomTypes" [value]="t">{{ t }}</mat-option>
            </mat-select>
          </mat-form-field>
          <mat-form-field appearance="outline" class="filter-field">
            <mat-label>Status</mat-label>
            <mat-select [(ngModel)]="filterStatus" (selectionChange)="loadRooms()">
              <mat-option value="">All</mat-option>
              <mat-option value="AVAILABLE">Available</mat-option>
              <mat-option value="OCCUPIED">Occupied</mat-option>
              <mat-option value="MAINTENANCE">Maintenance</mat-option>
              <mat-option value="BLOCKED">Blocked</mat-option>
            </mat-select>
          </mat-form-field>
        </div>
      </mat-card>

      <!-- Table -->
      <mat-card>
        <div class="table-wrapper">
          <table mat-table [dataSource]="rooms" class="full-table">
            <ng-container matColumnDef="roomNumber">
              <th mat-header-cell *matHeaderCellDef>Room No.</th>
              <td mat-cell *matCellDef="let r">{{ r.roomNumber }}</td>
            </ng-container>
            <ng-container matColumnDef="roomType">
              <th mat-header-cell *matHeaderCellDef>Type</th>
              <td mat-cell *matCellDef="let r">{{ r.roomType }}</td>
            </ng-container>
            <ng-container matColumnDef="roomStatus">
              <th mat-header-cell *matHeaderCellDef>Status</th>
              <td mat-cell *matCellDef="let r">
                <span class="status-badge status-{{ r.roomStatus }}">{{ r.roomStatus }}</span>
              </td>
            </ng-container>
            <ng-container matColumnDef="pricePerNight">
              <th mat-header-cell *matHeaderCellDef>Price/Night</th>
              <td mat-cell *matCellDef="let r">₹{{ r.pricePerNight | number:'1.0-0' }}</td>
            </ng-container>
            <ng-container matColumnDef="capacity">
              <th mat-header-cell *matHeaderCellDef>Capacity</th>
              <td mat-cell *matCellDef="let r">{{ r.maxAdults }}A + {{ r.maxChildren }}C</td>
            </ng-container>
            <ng-container matColumnDef="floor">
              <th mat-header-cell *matHeaderCellDef>Floor</th>
              <td mat-cell *matCellDef="let r">{{ r.floorNumber }}</td>
            </ng-container>
            <ng-container matColumnDef="actions">
              <th mat-header-cell *matHeaderCellDef>Actions</th>
              <td mat-cell *matCellDef="let r">
                <button mat-icon-button color="primary" (click)="editRoom(r)" title="Edit">
                  <mat-icon>edit</mat-icon>
                </button>
                <button mat-icon-button (click)="changeStatus(r, 'MAINTENANCE')" title="Maintenance">
                  <mat-icon>build</mat-icon>
                </button>
                <button mat-icon-button color="warn" (click)="changeStatus(r, 'BLOCKED')" title="Block">
                  <mat-icon>block</mat-icon>
                </button>
                <button mat-icon-button color="accent" (click)="changeStatus(r, 'AVAILABLE')"
                        title="Set Available" *ngIf="r.roomStatus !== 'AVAILABLE'">
                  <mat-icon>check_circle</mat-icon>
                </button>
              </td>
            </ng-container>
            <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
            <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
          </table>
        </div>
        <mat-paginator [length]="totalRooms" [pageSize]="pageSize" [pageSizeOptions]="[10, 20, 50]"
                       (page)="onPageChange($event)"></mat-paginator>
      </mat-card>
    </div>
  `,
  styles: [`
    .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
    .header-actions { display: flex; gap: 8px; flex-wrap: wrap; }
    .upload-label {
      display: flex; align-items: center; gap: 4px;
      padding: 0 16px; height: 36px; cursor: pointer;
      border: 1px solid rgba(0,0,0,0.23); border-radius: 4px;
      font-size: 14px;
    }
    .add-form-panel { margin-bottom: 16px; }
    .form-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 8px; }
    .form-actions { display: flex; gap: 8px; }
    .filter-card { padding: 16px; margin-bottom: 16px; }
    .filter-row { display: flex; gap: 16px; }
    .filter-field { flex: 1; }
    .table-wrapper { overflow-x: auto; }
    .full-table { width: 100%; }
    .page-title { margin: 0; }

    @media (max-width: 768px) {
      .page-header { flex-direction: column; align-items: flex-start; gap: 8px; }
      .form-grid { grid-template-columns: 1fr 1fr; }
      .filter-row { flex-direction: column; }
    }
  `]
})
export class ManageRoomsComponent implements OnInit {
  rooms: Room[] = [];
  displayedColumns = ['roomNumber', 'roomType', 'roomStatus', 'pricePerNight', 'capacity', 'floor', 'actions'];
  totalRooms = 0;
  pageSize = 10;
  currentPage = 0;
  searchQuery = '';
  filterType = '';
  filterStatus = '';
  showAddForm = false;
  editingRoom: Room | null = null;
  saving = false;
  roomForm: FormGroup;
  roomTypes = ['STANDARD', 'DELUXE', 'SUITE', 'EXECUTIVE', 'PRESIDENTIAL'];

  constructor(private roomService: RoomService, private notify: NotificationService, private fb: FormBuilder) {
    this.roomForm = this.fb.group({
      roomNumber: [''],
      roomType: ['', Validators.required],
      pricePerNight: ['', [Validators.required, Validators.min(0.01)]],
      maxAdults: [2, [Validators.required, Validators.min(1)]],
      maxChildren: [0],
      floorNumber: [1, [Validators.required, Validators.min(1)]],
      amenities: ['', Validators.required],
      description: ['']
    });
  }

  ngOnInit(): void { this.loadRooms(); }

  loadRooms(page = 0): void {
    this.currentPage = page;
    this.roomService.getAllRooms(this.searchQuery, this.filterType || undefined, this.filterStatus || undefined,
      page, this.pageSize).subscribe(res => {
      this.rooms = res.content;
      this.totalRooms = res.totalElements;
    });
  }

  onPageChange(e: PageEvent): void { this.pageSize = e.pageSize; this.loadRooms(e.pageIndex); }

  editRoom(room: Room): void {
    this.editingRoom = room;
    this.showAddForm = true;
    this.roomForm.patchValue({
      roomType: room.roomType,
      pricePerNight: room.pricePerNight,
      maxAdults: room.maxAdults,
      maxChildren: room.maxChildren,
      floorNumber: room.floorNumber,
      amenities: room.amenities,
      description: room.description
    });
  }

  cancelEdit(): void { this.editingRoom = null; this.showAddForm = false; this.roomForm.reset({ maxAdults: 2, maxChildren: 0, floorNumber: 1 }); }

  onSubmit(): void {
    if (this.roomForm.invalid) return;
    this.saving = true;
    const action = this.editingRoom
      ? this.roomService.updateRoom(this.editingRoom.id, this.roomForm.value)
      : this.roomService.addRoom(this.roomForm.value);
    action.subscribe({
      next: () => {
        this.saving = false;
        this.notify.success(this.editingRoom ? 'Room updated' : 'Room added');
        this.cancelEdit();
        this.loadRooms();
      },
      error: (err) => { this.saving = false; this.notify.error(err.error?.message || 'Failed'); }
    });
  }

  changeStatus(room: Room, status: string): void {
    this.roomService.updateRoomStatus(room.id, status).subscribe({
      next: () => { this.notify.success('Status updated'); this.loadRooms(); },
      error: (err) => this.notify.error(err.error?.message || 'Failed')
    });
  }

  downloadTemplate(): void { this.roomService.downloadTemplate(); }

  bulkUpload(e: Event): void {
    const file = (e.target as HTMLInputElement).files?.[0];
    if (!file) return;
    this.roomService.bulkUpload(file).subscribe({
      next: (rooms) => { this.notify.success(`${rooms.length} rooms uploaded`); this.loadRooms(); },
      error: (err) => this.notify.error(err.error?.message || 'Upload failed')
    });
  }
}
