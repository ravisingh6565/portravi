import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatExpansionModule } from '@angular/material/expansion';
import { BookingService } from '../../../services/booking.service';
import { PaymentService } from '../../../services/payment.service';
import { NotificationService } from '../../../services/notification.service';
import { Booking } from '../../../models/models';

@Component({
  selector: 'app-manage-bookings',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, MatCardModule, MatButtonModule, MatIconModule,
    MatFormFieldModule, MatInputModule, MatSelectModule, MatTableModule, MatPaginatorModule,
    MatProgressSpinnerModule, MatExpansionModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1 class="page-title">Manage Reservations</h1>
        <button mat-raised-button color="primary" (click)="showCreateForm = !showCreateForm">
          <mat-icon>add</mat-icon> New Reservation
        </button>
      </div>

      <mat-expansion-panel [expanded]="showCreateForm" class="create-form-panel">
        <mat-expansion-panel-header><mat-panel-title>Create Reservation Manually</mat-panel-title></mat-expansion-panel-header>
        <form [formGroup]="createForm" (ngSubmit)="onCreate()">
          <div class="form-grid">
            <mat-form-field appearance="outline"><mat-label>Customer ID</mat-label>
              <input matInput formControlName="customerId" placeholder="USR..."><mat-error>Required</mat-error></mat-form-field>
            <mat-form-field appearance="outline"><mat-label>Room ID</mat-label>
              <input matInput type="number" formControlName="roomId"><mat-error>Required</mat-error></mat-form-field>
            <mat-form-field appearance="outline"><mat-label>Check-in Date</mat-label>
              <input matInput type="date" formControlName="checkInDate" [min]="minDate"><mat-error>Required</mat-error></mat-form-field>
            <mat-form-field appearance="outline"><mat-label>Check-out Date</mat-label>
              <input matInput type="date" formControlName="checkOutDate"><mat-error>Required</mat-error></mat-form-field>
            <mat-form-field appearance="outline"><mat-label>Adults</mat-label>
              <input matInput type="number" formControlName="adults" min="1"></mat-form-field>
            <mat-form-field appearance="outline"><mat-label>Children</mat-label>
              <input matInput type="number" formControlName="children" min="0"></mat-form-field>
          </div>
          <mat-form-field appearance="outline" style="width:100%"><mat-label>Special Request</mat-label>
            <textarea matInput formControlName="specialRequest" rows="2"></textarea></mat-form-field>
          <div class="form-actions">
            <button mat-raised-button color="primary" type="submit" [disabled]="createForm.invalid || creating">
              <mat-spinner diameter="16" *ngIf="creating"></mat-spinner>
              Create Reservation
            </button>
            <button mat-stroked-button type="button" (click)="showCreateForm = false">Cancel</button>
          </div>
        </form>
      </mat-expansion-panel>

      <!-- Filters -->
      <mat-card class="filter-card">
        <div class="filter-row">
          <mat-form-field appearance="outline" class="filter-field">
            <mat-label>Search</mat-label>
            <input matInput [(ngModel)]="search" (input)="loadBookings()" placeholder="Booking ID, customer, room...">
            <mat-icon matSuffix>search</mat-icon>
          </mat-form-field>
          <mat-form-field appearance="outline" class="filter-field">
            <mat-label>Status</mat-label>
            <mat-select [(ngModel)]="filterStatus" (selectionChange)="loadBookings()">
              <mat-option value="">All</mat-option>
              <mat-option value="PENDING">Pending</mat-option>
              <mat-option value="CONFIRMED">Confirmed</mat-option>
              <mat-option value="CANCELLED">Cancelled</mat-option>
              <mat-option value="COMPLETED">Completed</mat-option>
              <mat-option value="MODIFIED">Modified</mat-option>
            </mat-select>
          </mat-form-field>
          <mat-form-field appearance="outline" class="filter-field">
            <mat-label>From Date</mat-label>
            <input matInput type="date" [(ngModel)]="fromDate" (change)="loadBookings()">
          </mat-form-field>
          <mat-form-field appearance="outline" class="filter-field">
            <mat-label>To Date</mat-label>
            <input matInput type="date" [(ngModel)]="toDate" (change)="loadBookings()">
          </mat-form-field>
        </div>
      </mat-card>

      <!-- Table -->
      <mat-card>
        <div class="table-wrapper">
          <table mat-table [dataSource]="bookings" class="full-table">
            <ng-container matColumnDef="bookingId">
              <th mat-header-cell *matHeaderCellDef>Booking ID</th>
              <td mat-cell *matCellDef="let b">{{ b.bookingId }}</td>
            </ng-container>
            <ng-container matColumnDef="customerName">
              <th mat-header-cell *matHeaderCellDef>Customer</th>
              <td mat-cell *matCellDef="let b">{{ b.customerName }}</td>
            </ng-container>
            <ng-container matColumnDef="roomNumber">
              <th mat-header-cell *matHeaderCellDef>Room</th>
              <td mat-cell *matCellDef="let b">{{ b.roomType }} - {{ b.roomNumber }}</td>
            </ng-container>
            <ng-container matColumnDef="checkInDate">
              <th mat-header-cell *matHeaderCellDef>Check-in</th>
              <td mat-cell *matCellDef="let b">{{ b.checkInDate | date:'mediumDate' }}</td>
            </ng-container>
            <ng-container matColumnDef="checkOutDate">
              <th mat-header-cell *matHeaderCellDef>Check-out</th>
              <td mat-cell *matCellDef="let b">{{ b.checkOutDate | date:'mediumDate' }}</td>
            </ng-container>
            <ng-container matColumnDef="grandTotal">
              <th mat-header-cell *matHeaderCellDef>Total</th>
              <td mat-cell *matCellDef="let b">₹{{ b.grandTotal | number:'1.0-0' }}</td>
            </ng-container>
            <ng-container matColumnDef="bookingStatus">
              <th mat-header-cell *matHeaderCellDef>Status</th>
              <td mat-cell *matCellDef="let b">
                <span class="status-badge status-{{ b.bookingStatus }}">{{ b.bookingStatus }}</span>
              </td>
            </ng-container>
            <ng-container matColumnDef="actions">
              <th mat-header-cell *matHeaderCellDef>Actions</th>
              <td mat-cell *matCellDef="let b">
                <button mat-icon-button color="warn" (click)="cancelBooking(b)"
                        *ngIf="b.bookingStatus !== 'CANCELLED'" title="Cancel">
                  <mat-icon>cancel</mat-icon>
                </button>
                <button mat-icon-button (click)="downloadInvoice(b.bookingId)"
                        *ngIf="b.paymentStatus === 'SUCCESS'" title="Invoice">
                  <mat-icon>download</mat-icon>
                </button>
              </td>
            </ng-container>
            <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
            <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
          </table>
        </div>
        <mat-paginator [length]="total" [pageSize]="pageSize" [pageSizeOptions]="[10, 20, 50]"
                       (page)="onPageChange($event)"></mat-paginator>
      </mat-card>
    </div>
  `,
  styles: [`
    .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
    .create-form-panel { margin-bottom: 16px; }
    .form-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 8px; }
    .form-actions { display: flex; gap: 8px; }
    .filter-card { padding: 16px; margin-bottom: 16px; }
    .filter-row { display: flex; gap: 16px; flex-wrap: wrap; }
    .filter-field { min-width: 150px; flex: 1; }
    .table-wrapper { overflow-x: auto; }
    .full-table { width: 100%; }
    .page-title { margin: 0; }
    @media (max-width: 768px) { .form-grid { grid-template-columns: 1fr 1fr; } .page-header { flex-direction: column; gap: 8px; align-items: flex-start; } }
  `]
})
export class ManageBookingsComponent implements OnInit {
  bookings: Booking[] = [];
  displayedColumns = ['bookingId', 'customerName', 'roomNumber', 'checkInDate', 'checkOutDate', 'grandTotal', 'bookingStatus', 'actions'];
  total = 0;
  pageSize = 10;
  currentPage = 0;
  search = '';
  filterStatus = '';
  fromDate = '';
  toDate = '';
  showCreateForm = false;
  creating = false;
  createForm: FormGroup;
  minDate = new Date().toISOString().split('T')[0];

  constructor(private bookingService: BookingService, private paymentService: PaymentService,
              private notify: NotificationService, private fb: FormBuilder) {
    this.createForm = this.fb.group({
      customerId: ['', Validators.required],
      roomId: ['', Validators.required],
      checkInDate: ['', Validators.required],
      checkOutDate: ['', Validators.required],
      adults: [1],
      children: [0],
      specialRequest: [''],
      paymentMethod: ['CREDIT_CARD']
    });
  }

  ngOnInit(): void { this.loadBookings(); }

  loadBookings(page = 0): void {
    const params: any = { page, size: this.pageSize, sort: 'createdAt,desc' };
    if (this.search) params.search = this.search;
    if (this.filterStatus) params.status = this.filterStatus;
    if (this.fromDate) params.fromDate = this.fromDate;
    if (this.toDate) params.toDate = this.toDate;
    this.bookingService.getAllBookings(params).subscribe(res => {
      this.bookings = res.content;
      this.total = res.totalElements;
    });
  }

  onPageChange(e: PageEvent): void { this.pageSize = e.pageSize; this.loadBookings(e.pageIndex); }

  cancelBooking(b: Booking): void {
    if (!confirm(`Cancel booking ${b.bookingId}?`)) return;
    this.bookingService.adminCancelBooking(b.bookingId).subscribe({
      next: () => { this.notify.success('Booking cancelled'); this.loadBookings(); },
      error: (err) => this.notify.error(err.error?.message || 'Failed')
    });
  }

  downloadInvoice(bookingId: string): void { this.paymentService.downloadInvoice(bookingId); }

  onCreate(): void {
    if (this.createForm.invalid) return;
    this.creating = true;
    const { customerId, ...bookingData } = this.createForm.value;
    this.bookingService.adminCreateBooking(customerId, bookingData).subscribe({
      next: () => { this.creating = false; this.notify.success('Reservation created'); this.showCreateForm = false; this.loadBookings(); },
      error: (err) => { this.creating = false; this.notify.error(err.error?.message || 'Failed'); }
    });
  }
}
