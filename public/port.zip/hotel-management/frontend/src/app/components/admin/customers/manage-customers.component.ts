import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTabsModule } from '@angular/material/tabs';
import { UserService } from '../../../services/user.service';
import { NotificationService } from '../../../services/notification.service';
import { User } from '../../../models/models';

@Component({
  selector: 'app-manage-customers',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, MatCardModule, MatButtonModule, MatIconModule,
    MatFormFieldModule, MatInputModule, MatSelectModule, MatTableModule, MatPaginatorModule,
    MatProgressSpinnerModule, MatExpansionModule, MatTabsModule],
  template: `
    <div class="page-container">
      <h1 class="page-title">Manage Customer Accounts</h1>

      <mat-tab-group>
        <mat-tab label="Customers">
          <div class="tab-content">
            <mat-card class="filter-card">
              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Search Customers</mat-label>
                <input matInput [(ngModel)]="searchCustomer" (input)="loadCustomers()" placeholder="Name, email, username...">
                <mat-icon matSuffix>search</mat-icon>
              </mat-form-field>
            </mat-card>

            <mat-card>
              <div class="table-wrapper">
                <table mat-table [dataSource]="customers" class="full-table">
                  <ng-container matColumnDef="userId"><th mat-header-cell *matHeaderCellDef>User ID</th>
                    <td mat-cell *matCellDef="let u">{{ u.userId }}</td></ng-container>
                  <ng-container matColumnDef="customerName"><th mat-header-cell *matHeaderCellDef>Name</th>
                    <td mat-cell *matCellDef="let u">{{ u.customerName }}</td></ng-container>
                  <ng-container matColumnDef="email"><th mat-header-cell *matHeaderCellDef>Email</th>
                    <td mat-cell *matCellDef="let u">{{ u.email }}</td></ng-container>
                  <ng-container matColumnDef="username"><th mat-header-cell *matHeaderCellDef>Username</th>
                    <td mat-cell *matCellDef="let u">{{ u.username }}</td></ng-container>
                  <ng-container matColumnDef="status"><th mat-header-cell *matHeaderCellDef>Status</th>
                    <td mat-cell *matCellDef="let u">
                      <span class="status-badge" [class.status-CONFIRMED]="u.active" [class.status-CANCELLED]="!u.active">
                        {{ u.active ? 'Active' : 'Inactive' }}
                      </span>
                    </td></ng-container>
                  <ng-container matColumnDef="actions"><th mat-header-cell *matHeaderCellDef>Actions</th>
                    <td mat-cell *matCellDef="let u">
                      <button mat-icon-button (click)="resetPwd(u)" title="Reset Password"><mat-icon>lock_reset</mat-icon></button>
                      <button mat-icon-button [color]="u.active ? 'warn' : 'primary'" (click)="toggleStatus(u)" [title]="u.active ? 'Deactivate' : 'Activate'">
                        <mat-icon>{{ u.active ? 'person_off' : 'person' }}</mat-icon>
                      </button>
                    </td></ng-container>
                  <tr mat-header-row *matHeaderRowDef="custColumns"></tr>
                  <tr mat-row *matRowDef="let row; columns: custColumns;"></tr>
                </table>
              </div>
              <mat-paginator [length]="totalCustomers" [pageSize]="custPageSize" [pageSizeOptions]="[10, 20]"
                             (page)="onCustPage($event)"></mat-paginator>
            </mat-card>
          </div>
        </mat-tab>

        <mat-tab label="Staff">
          <div class="tab-content">
            <mat-card>
              <div class="table-wrapper">
                <table mat-table [dataSource]="staff" class="full-table">
                  <ng-container matColumnDef="userId"><th mat-header-cell *matHeaderCellDef>User ID</th>
                    <td mat-cell *matCellDef="let u">{{ u.userId }}</td></ng-container>
                  <ng-container matColumnDef="customerName"><th mat-header-cell *matHeaderCellDef>Name</th>
                    <td mat-cell *matCellDef="let u">{{ u.customerName }}</td></ng-container>
                  <ng-container matColumnDef="email"><th mat-header-cell *matHeaderCellDef>Email</th>
                    <td mat-cell *matCellDef="let u">{{ u.email }}</td></ng-container>
                  <ng-container matColumnDef="username"><th mat-header-cell *matHeaderCellDef>Username</th>
                    <td mat-cell *matCellDef="let u">{{ u.username }}</td></ng-container>
                  <ng-container matColumnDef="status"><th mat-header-cell *matHeaderCellDef>Status</th>
                    <td mat-cell *matCellDef="let u">
                      <span class="status-badge" [class.status-CONFIRMED]="u.active" [class.status-CANCELLED]="!u.active">
                        {{ u.active ? 'Active' : 'Inactive' }}
                      </span>
                    </td></ng-container>
                  <ng-container matColumnDef="actions"><th mat-header-cell *matHeaderCellDef>Actions</th>
                    <td mat-cell *matCellDef="let u">
                      <button mat-icon-button (click)="resetPwd(u)" title="Reset Password"><mat-icon>lock_reset</mat-icon></button>
                      <button mat-icon-button [color]="u.active ? 'warn' : 'primary'" (click)="toggleStatus(u)">
                        <mat-icon>{{ u.active ? 'person_off' : 'person' }}</mat-icon>
                      </button>
                    </td></ng-container>
                  <tr mat-header-row *matHeaderRowDef="custColumns"></tr>
                  <tr mat-row *matRowDef="let row; columns: custColumns;"></tr>
                </table>
              </div>
            </mat-card>
          </div>
        </mat-tab>

        <mat-tab label="Create User">
          <div class="tab-content">
            <mat-card class="create-form-card">
              <h3>Create New User</h3>
              <form [formGroup]="createForm" (ngSubmit)="onCreateUser()">
                <div class="form-grid">
                  <mat-form-field appearance="outline"><mat-label>Full Name</mat-label>
                    <input matInput formControlName="customerName"><mat-error>Required (3+ chars, alpha)</mat-error></mat-form-field>
                  <mat-form-field appearance="outline"><mat-label>Email</mat-label>
                    <input matInput type="email" formControlName="email"><mat-error>Valid email required</mat-error></mat-form-field>
                  <mat-form-field appearance="outline"><mat-label>Mobile</mat-label>
                    <input matInput formControlName="mobile" placeholder="+91..."><mat-error>Required</mat-error></mat-form-field>
                  <mat-form-field appearance="outline"><mat-label>Username</mat-label>
                    <input matInput formControlName="username"><mat-error>Min 5 chars, no spaces</mat-error></mat-form-field>
                  <mat-form-field appearance="outline"><mat-label>Password</mat-label>
                    <input matInput type="password" formControlName="password"><mat-error>Min 8 chars</mat-error></mat-form-field>
                  <mat-form-field appearance="outline"><mat-label>Role</mat-label>
                    <mat-select formControlName="role">
                      <mat-option value="CUSTOMER">Customer</mat-option>
                      <mat-option value="STAFF">Staff</mat-option>
                    </mat-select></mat-form-field>
                </div>
                <mat-form-field appearance="outline" style="width:100%"><mat-label>Address</mat-label>
                  <input matInput formControlName="address"></mat-form-field>
                <button mat-raised-button color="primary" type="submit" [disabled]="createForm.invalid || creating">
                  <mat-spinner diameter="16" *ngIf="creating"></mat-spinner>
                  Create User
                </button>
              </form>
            </mat-card>
          </div>
        </mat-tab>
      </mat-tab-group>
    </div>
  `,
  styles: [`
    .tab-content { padding: 16px 0; }
    .filter-card { padding: 16px; margin-bottom: 16px; }
    .full-width { width: 100%; }
    .table-wrapper { overflow-x: auto; }
    .full-table { width: 100%; }
    .create-form-card { max-width: 800px; padding: 24px; }
    .create-form-card h3 { margin-bottom: 16px; color: #3f51b5; }
    .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 8px; }
    @media (max-width: 600px) { .form-grid { grid-template-columns: 1fr; } }
  `]
})
export class ManageCustomersComponent implements OnInit {
  customers: User[] = [];
  staff: User[] = [];
  custColumns = ['userId', 'customerName', 'email', 'username', 'status', 'actions'];
  totalCustomers = 0;
  custPageSize = 10;
  searchCustomer = '';
  creating = false;
  createForm: FormGroup;

  constructor(private userService: UserService, private notify: NotificationService, private fb: FormBuilder) {
    this.createForm = this.fb.group({
      customerName: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^[a-zA-Z ]+$/)]],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', Validators.required],
      address: [''],
      username: ['', [Validators.required, Validators.minLength(5)]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: [''],
      role: ['CUSTOMER']
    });
  }

  ngOnInit(): void { this.loadCustomers(); this.loadStaff(); }

  loadCustomers(page = 0): void {
    this.userService.getCustomers(this.searchCustomer, page, this.custPageSize).subscribe(res => {
      this.customers = res.content; this.totalCustomers = res.totalElements;
    });
  }

  loadStaff(): void {
    this.userService.getStaff(undefined, 0, 50).subscribe(res => this.staff = res.content);
  }

  onCustPage(e: PageEvent): void { this.custPageSize = e.pageSize; this.loadCustomers(e.pageIndex); }

  resetPwd(u: User): void {
    const newPwd = prompt(`New password for ${u.username}:`);
    if (!newPwd) return;
    this.userService.resetPassword(u.userId, newPwd).subscribe({
      next: () => this.notify.success('Password reset'),
      error: (err) => this.notify.error(err.error?.message || 'Failed')
    });
  }

  toggleStatus(u: User): void {
    this.userService.toggleUserStatus(u.userId, !u.active).subscribe({
      next: updated => {
        const arr = u.role === 'ROLE_CUSTOMER' ? this.customers : this.staff;
        const idx = arr.findIndex(x => x.userId === u.userId);
        if (idx >= 0) arr[idx] = updated;
        this.notify.success(`User ${updated.active ? 'activated' : 'deactivated'}`);
      },
      error: (err) => this.notify.error(err.error?.message || 'Failed')
    });
  }

  onCreateUser(): void {
    if (this.createForm.invalid) return;
    this.creating = true;
    const { role, ...data } = this.createForm.value;
    data.confirmPassword = data.password;
    const action = role === 'STAFF' ? this.userService.createStaff(data) : this.userService.createCustomer(data);
    action.subscribe({
      next: () => {
        this.creating = false;
        this.notify.success('User created');
        this.createForm.reset({ role: 'CUSTOMER' });
        this.loadCustomers(); this.loadStaff();
      },
      error: (err) => { this.creating = false; this.notify.error(err.error?.message || 'Failed'); }
    });
  }
}
