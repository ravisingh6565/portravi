import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { PaymentService } from '../../../services/payment.service';
import { UserService } from '../../../services/user.service';
import { NotificationService } from '../../../services/notification.service';
import { Bill } from '../../../models/models';

@Component({
  selector: 'app-manage-bills',
  standalone: true,
  imports: [CommonModule, FormsModule, MatCardModule, MatButtonModule, MatIconModule,
    MatFormFieldModule, MatInputModule, MatTableModule, MatPaginatorModule],
  template: `
    <div class="page-container">
      <h1 class="page-title">Manage Bills</h1>

      <mat-card class="filter-card">
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Search Bills</mat-label>
          <input matInput [(ngModel)]="search" (input)="loadBills()" placeholder="Invoice number, booking ID, customer...">
          <mat-icon matSuffix>search</mat-icon>
        </mat-form-field>
      </mat-card>

      <mat-card>
        <div class="table-wrapper">
          <table mat-table [dataSource]="bills" class="full-table">
            <ng-container matColumnDef="invoiceNumber"><th mat-header-cell *matHeaderCellDef>Invoice #</th>
              <td mat-cell *matCellDef="let b">{{ b.invoiceNumber }}</td></ng-container>
            <ng-container matColumnDef="bookingId"><th mat-header-cell *matHeaderCellDef>Booking ID</th>
              <td mat-cell *matCellDef="let b">{{ b.bookingId }}</td></ng-container>
            <ng-container matColumnDef="customerName"><th mat-header-cell *matHeaderCellDef>Customer</th>
              <td mat-cell *matCellDef="let b">{{ b.customerName }}</td></ng-container>
            <ng-container matColumnDef="roomCharges"><th mat-header-cell *matHeaderCellDef>Room Charges</th>
              <td mat-cell *matCellDef="let b">₹{{ b.roomCharges | number:'1.0-0' }}</td></ng-container>
            <ng-container matColumnDef="taxAmount"><th mat-header-cell *matHeaderCellDef>Tax (18%)</th>
              <td mat-cell *matCellDef="let b">₹{{ b.taxAmount | number:'1.0-0' }}</td></ng-container>
            <ng-container matColumnDef="totalAmount"><th mat-header-cell *matHeaderCellDef>Total</th>
              <td mat-cell *matCellDef="let b"><strong>₹{{ b.totalAmount | number:'1.0-0' }}</strong></td></ng-container>
            <ng-container matColumnDef="createdAt"><th mat-header-cell *matHeaderCellDef>Date</th>
              <td mat-cell *matCellDef="let b">{{ b.createdAt | date:'mediumDate' }}</td></ng-container>
            <ng-container matColumnDef="actions"><th mat-header-cell *matHeaderCellDef>Actions</th>
              <td mat-cell *matCellDef="let b">
                <button mat-icon-button (click)="download(b.bookingId)" title="Download Invoice">
                  <mat-icon>download</mat-icon>
                </button>
                <button mat-icon-button color="accent" (click)="addItems(b)" title="Add Items">
                  <mat-icon>add_circle</mat-icon>
                </button>
              </td></ng-container>
            <tr mat-header-row *matHeaderRowDef="columns"></tr>
            <tr mat-row *matRowDef="let row; columns: columns;"></tr>
          </table>
        </div>
        <mat-paginator [length]="total" [pageSize]="pageSize" [pageSizeOptions]="[10, 20]"
                       (page)="onPage($event)"></mat-paginator>
      </mat-card>
    </div>
  `,
  styles: [`
    .filter-card { padding: 16px; margin-bottom: 16px; }
    .full-width { width: 100%; }
    .table-wrapper { overflow-x: auto; }
    .full-table { width: 100%; }
  `]
})
export class ManageBillsComponent implements OnInit {
  bills: Bill[] = [];
  columns = ['invoiceNumber', 'bookingId', 'customerName', 'roomCharges', 'taxAmount', 'totalAmount', 'createdAt', 'actions'];
  total = 0;
  pageSize = 10;
  search = '';

  constructor(private paymentService: PaymentService, private userService: UserService,
              private notify: NotificationService) {}

  ngOnInit(): void { this.loadBills(); }

  loadBills(page = 0): void {
    this.userService.getAllBills(this.search, page, this.pageSize).subscribe(res => {
      this.bills = res.content; this.total = res.totalElements;
    });
  }

  onPage(e: PageEvent): void { this.pageSize = e.pageSize; this.loadBills(e.pageIndex); }

  download(bookingId: string): void { this.paymentService.downloadInvoice(bookingId); }

  addItems(bill: Bill): void {
    const charges = prompt(`Additional charges for ${bill.bookingId}:`, '0');
    if (charges === null) return;
    const items = prompt('Additional items description:') || '';
    const notes = prompt('Notes:') || '';
    this.userService.addBillItems(bill.bookingId, {
      additionalCharges: +charges, additionalItems: items, notes
    }).subscribe({
      next: () => { this.notify.success('Bill updated'); this.loadBills(); },
      error: (err) => this.notify.error(err.error?.message || 'Failed')
    });
  }
}
