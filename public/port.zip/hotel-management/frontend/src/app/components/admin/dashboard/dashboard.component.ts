import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { UserService } from '../../../services/user.service';
import { AuthService } from '../../../services/auth.service';
import { DashboardData } from '../../../models/models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, MatCardModule, MatIconModule, MatButtonModule, MatProgressSpinnerModule],
  template: `
    <div class="page-container">
      <div class="dashboard-header">
        <h1>Welcome, {{ auth.currentUser?.customerName }}! 👋</h1>
        <p>Here's what's happening at Grand Hotel today</p>
      </div>

      <div *ngIf="loading" class="loading-center"><mat-spinner></mat-spinner></div>

      <ng-container *ngIf="data && !loading">
        <!-- Stats cards -->
        <div class="stats-grid">
          <mat-card class="stat-card blue" routerLink="/admin/bookings">
            <div class="stat-icon"><mat-icon>book_online</mat-icon></div>
            <div class="stat-info">
              <span class="stat-value">{{ data.totalBookings }}</span>
              <span class="stat-label">Total Bookings</span>
            </div>
          </mat-card>
          <mat-card class="stat-card green">
            <div class="stat-icon"><mat-icon>hotel</mat-icon></div>
            <div class="stat-info">
              <span class="stat-value">{{ data.availableRooms }}</span>
              <span class="stat-label">Available Rooms</span>
            </div>
          </mat-card>
          <mat-card class="stat-card orange" routerLink="/admin/customers">
            <div class="stat-icon"><mat-icon>people</mat-icon></div>
            <div class="stat-info">
              <span class="stat-value">{{ data.totalCustomers }}</span>
              <span class="stat-label">Total Users</span>
            </div>
          </mat-card>
          <mat-card class="stat-card red" routerLink="/admin/complaints">
            <div class="stat-icon"><mat-icon>report_problem</mat-icon></div>
            <div class="stat-info">
              <span class="stat-value">{{ data.openComplaints }}</span>
              <span class="stat-label">Open Complaints</span>
            </div>
          </mat-card>
        </div>

        <!-- Period stats -->
        <div class="period-stats">
          <mat-card class="period-card">
            <h3>Bookings Overview</h3>
            <div class="period-row">
              <div class="period-item">
                <span class="period-value">{{ data.dailyBookings }}</span>
                <span class="period-label">Today</span>
              </div>
              <div class="period-item">
                <span class="period-value">{{ data.weeklyBookings }}</span>
                <span class="period-label">This Week</span>
              </div>
              <div class="period-item">
                <span class="period-value">{{ data.monthlyBookings }}</span>
                <span class="period-label">This Month</span>
              </div>
            </div>
          </mat-card>

          <mat-card class="period-card">
            <h3>Room Status</h3>
            <div class="period-row">
              <div class="period-item">
                <span class="period-value green-text">{{ data.availableRooms }}</span>
                <span class="period-label">Available</span>
              </div>
              <div class="period-item">
                <span class="period-value red-text">{{ data.occupiedRooms }}</span>
                <span class="period-label">Occupied</span>
              </div>
              <div class="period-item">
                <span class="period-value">{{ data.totalRooms }}</span>
                <span class="period-label">Total Rooms</span>
              </div>
            </div>
          </mat-card>
        </div>

        <!-- Booking status breakdown -->
        <div class="charts-row">
          <mat-card class="chart-card">
            <h3>Booking Status Breakdown</h3>
            <div class="status-bars">
              <div class="status-bar-row" *ngFor="let entry of bookingStatusEntries">
                <span class="status-label">{{ entry.key }}</span>
                <div class="bar-wrapper">
                  <div class="bar" [style.width]="getBarWidth(entry.value) + '%'"
                       [class]="'bar-' + entry.key"></div>
                </div>
                <span class="bar-value">{{ entry.value }}</span>
              </div>
            </div>
          </mat-card>

          <mat-card class="chart-card">
            <h3>Rooms by Type</h3>
            <div class="status-bars">
              <div class="status-bar-row" *ngFor="let entry of roomTypeEntries">
                <span class="status-label">{{ entry.key }}</span>
                <div class="bar-wrapper">
                  <div class="bar bar-room" [style.width]="getRoomBarWidth(entry.value) + '%'"></div>
                </div>
                <span class="bar-value">{{ entry.value }}</span>
              </div>
            </div>
          </mat-card>
        </div>

        <!-- Quick actions -->
        <mat-card class="quick-actions">
          <h3>Quick Actions</h3>
          <div class="actions-grid">
            <button mat-raised-button color="primary" routerLink="/admin/rooms">
              <mat-icon>add</mat-icon> Add Room
            </button>
            <button mat-raised-button color="primary" routerLink="/admin/bookings">
              <mat-icon>add</mat-icon> New Reservation
            </button>
            <button mat-raised-button color="primary" routerLink="/admin/customers">
              <mat-icon>person_add</mat-icon> Add Customer
            </button>
            <button mat-raised-button color="primary" routerLink="/admin/complaints">
              <mat-icon>support</mat-icon> Manage Complaints
            </button>
          </div>
        </mat-card>
      </ng-container>
    </div>
  `,
  styles: [`
    .dashboard-header { margin-bottom: 24px; }
    .dashboard-header h1 { font-size: 28px; color: #2c3e50; }
    .dashboard-header p { color: #666; }

    .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }
    .stat-card {
      display: flex; align-items: center; gap: 16px; padding: 20px;
      cursor: pointer; transition: transform 0.2s;
    }
    .stat-card:hover { transform: translateY(-2px); }
    .stat-icon mat-icon { font-size: 40px; width: 40px; height: 40px; color: white; }
    .stat-card.blue { background: linear-gradient(135deg, #3f51b5, #7c4dff); color: white; }
    .stat-card.green { background: linear-gradient(135deg, #43a047, #66bb6a); color: white; }
    .stat-card.orange { background: linear-gradient(135deg, #ff8f00, #ffb300); color: white; }
    .stat-card.red { background: linear-gradient(135deg, #e53935, #ef5350); color: white; }
    .stat-value { font-size: 32px; font-weight: 700; display: block; }
    .stat-label { font-size: 13px; opacity: 0.9; }

    .period-stats { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px; }
    .period-card { padding: 20px; }
    .period-card h3 { margin-bottom: 16px; color: #3f51b5; }
    .period-row { display: grid; grid-template-columns: repeat(3, 1fr); text-align: center; }
    .period-value { font-size: 28px; font-weight: 700; display: block; color: #2c3e50; }
    .period-label { font-size: 13px; color: #666; }
    .green-text { color: #43a047 !important; }
    .red-text { color: #e53935 !important; }

    .charts-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px; }
    .chart-card { padding: 20px; }
    .chart-card h3 { margin-bottom: 16px; color: #3f51b5; }
    .status-bars { display: flex; flex-direction: column; gap: 10px; }
    .status-bar-row { display: flex; align-items: center; gap: 8px; }
    .status-label { font-size: 12px; width: 100px; flex-shrink: 0; }
    .bar-wrapper { flex: 1; background: #f0f0f0; border-radius: 4px; height: 20px; overflow: hidden; }
    .bar { height: 100%; border-radius: 4px; transition: width 0.5s; }
    .bar-CONFIRMED { background: #43a047; }
    .bar-PENDING { background: #ff8f00; }
    .bar-CANCELLED { background: #e53935; }
    .bar-COMPLETED { background: #1565c0; }
    .bar-MODIFIED { background: #6a1b9a; }
    .bar-room { background: #3f51b5; }
    .bar-value { font-size: 12px; font-weight: 600; width: 30px; }

    .quick-actions { padding: 20px; }
    .quick-actions h3 { margin-bottom: 16px; color: #3f51b5; }
    .actions-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
    .loading-center { display: flex; justify-content: center; padding: 80px; }

    @media (max-width: 960px) {
      .stats-grid { grid-template-columns: repeat(2, 1fr); }
      .charts-row, .period-stats, .actions-grid { grid-template-columns: 1fr; }
    }
    @media (max-width: 600px) {
      .stats-grid { grid-template-columns: 1fr 1fr; }
    }
  `]
})
export class DashboardComponent implements OnInit {
  data: DashboardData | null = null;
  loading = true;
  bookingStatusEntries: { key: string; value: number }[] = [];
  roomTypeEntries: { key: string; value: number }[] = [];
  maxBookingCount = 1;
  maxRoomCount = 1;

  constructor(public auth: AuthService, private userService: UserService) {}

  ngOnInit(): void {
    this.userService.getDashboard().subscribe({
      next: d => {
        this.data = d;
        this.loading = false;
        this.bookingStatusEntries = Object.entries(d.bookingsByStatus).map(([key, value]) => ({ key, value: +value }));
        this.roomTypeEntries = Object.entries(d.roomsByType).map(([key, value]) => ({ key, value: +value }));
        this.maxBookingCount = Math.max(1, ...this.bookingStatusEntries.map(e => e.value));
        this.maxRoomCount = Math.max(1, ...this.roomTypeEntries.map(e => e.value));
      },
      error: () => this.loading = false
    });
  }

  getBarWidth(v: number): number {
    return Math.round((v / this.maxBookingCount) * 100);
  }

  getRoomBarWidth(v: number): number {
    return Math.round((v / this.maxRoomCount) * 100);
  }
}
