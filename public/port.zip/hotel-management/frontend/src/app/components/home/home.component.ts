import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { AuthService } from '../../services/auth.service';
import { BookingService } from '../../services/booking.service';
import { Booking } from '../../models/models';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink, MatButtonModule, MatCardModule, MatIconModule],
  template: `
    <div class="home-hero">
      <div class="hero-content">
        <h1>Welcome, {{ auth.currentUser?.customerName }}!</h1>
        <p>Discover luxury and comfort at Grand Hotel &amp; Resort</p>
        <div class="hero-actions">
          <button mat-raised-button color="accent" routerLink="/search-rooms" class="hero-btn">
            <mat-icon>search</mat-icon> Search Rooms
          </button>
          <button mat-stroked-button routerLink="/my-bookings" class="hero-btn ghost-btn" *ngIf="auth.isCustomer">
            <mat-icon>book_online</mat-icon> My Bookings
          </button>
          <button mat-stroked-button routerLink="/admin/dashboard" class="hero-btn ghost-btn" *ngIf="auth.isAdmin">
            <mat-icon>dashboard</mat-icon> Dashboard
          </button>
        </div>
      </div>
    </div>

    <div class="page-container">
      <div class="stats-grid" *ngIf="auth.isCustomer">
        <mat-card class="stat-card" routerLink="/my-bookings">
          <mat-icon>upcoming</mat-icon>
          <div class="stat-info">
            <span class="stat-value">{{ upcomingCount }}</span>
            <span class="stat-label">Upcoming Stays</span>
          </div>
        </mat-card>
        <mat-card class="stat-card" routerLink="/my-bookings">
          <mat-icon>history</mat-icon>
          <div class="stat-info">
            <span class="stat-value">{{ pastCount }}</span>
            <span class="stat-label">Past Stays</span>
          </div>
        </mat-card>
        <mat-card class="stat-card" routerLink="/complaints">
          <mat-icon>report_problem</mat-icon>
          <div class="stat-info">
            <span class="stat-value">Register</span>
            <span class="stat-label">New Complaint</span>
          </div>
        </mat-card>
        <mat-card class="stat-card" routerLink="/my-complaints">
          <mat-icon>track_changes</mat-icon>
          <div class="stat-info">
            <span class="stat-value">Track</span>
            <span class="stat-label">My Complaints</span>
          </div>
        </mat-card>
      </div>

      <h2 class="section-title">Why Choose Us</h2>
      <div class="features-grid">
        <mat-card class="feature-card" *ngFor="let f of features">
          <mat-icon color="primary">{{ f.icon }}</mat-icon>
          <h3>{{ f.title }}</h3>
          <p>{{ f.desc }}</p>
        </mat-card>
      </div>

      <ng-container *ngIf="upcomingBookings.length > 0">
        <h2 class="section-title">Upcoming Bookings</h2>
        <mat-card class="booking-card" *ngFor="let b of upcomingBookings.slice(0,3)">
          <div class="booking-info">
            <div>
              <strong>{{ b.roomType }} - Room {{ b.roomNumber }}</strong>
              <p class="dates">{{ b.checkInDate | date:'mediumDate' }} &rarr; {{ b.checkOutDate | date:'mediumDate' }} ({{ b.totalNights }} nights)</p>
            </div>
            <div class="booking-right">
              <span class="status-badge status-{{ b.bookingStatus }}">{{ b.bookingStatus }}</span>
              <button mat-stroked-button color="primary" [routerLink]="['/bookings', b.bookingId]" style="margin-left:8px">View</button>
            </div>
          </div>
        </mat-card>
        <a routerLink="/my-bookings" *ngIf="upcomingBookings.length > 3" mat-button color="primary">View All Bookings</a>
      </ng-container>
    </div>
  `,
  styles: [`
    .home-hero {
      background: linear-gradient(135deg, #3f51b5 0%, #7c4dff 100%);
      color: white;
      padding: 80px 16px;
      text-align: center;
    }
    .hero-content h1 { font-size: 36px; margin-bottom: 12px; }
    .hero-content p { font-size: 18px; opacity: 0.9; margin-bottom: 32px; }
    .hero-actions { display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; }
    .hero-btn { height: 48px; font-size: 15px; }
    .ghost-btn { color: white !important; border-color: white !important; }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 16px;
      margin: 24px 0;
    }
    .stat-card {
      display: flex; align-items: center; gap: 16px;
      padding: 20px; cursor: pointer; transition: transform 0.2s;
    }
    .stat-card:hover { transform: translateY(-2px); box-shadow: 0 4px 16px rgba(0,0,0,0.15); }
    .stat-card mat-icon { font-size: 36px; width: 36px; height: 36px; color: #3f51b5; }
    .stat-value { font-size: 24px; font-weight: 700; color: #2c3e50; display: block; }
    .stat-label { font-size: 13px; color: #666; }

    .section-title { font-size: 22px; font-weight: 600; color: #2c3e50; margin: 24px 0 16px; }

    .features-grid {
      display: grid; grid-template-columns: repeat(4, 1fr);
      gap: 16px; margin-bottom: 32px;
    }
    .feature-card { padding: 24px; text-align: center; }
    .feature-card mat-icon { font-size: 48px; width: 48px; height: 48px; margin-bottom: 12px; }
    .feature-card h3 { margin-bottom: 8px; }
    .feature-card p { color: #666; font-size: 14px; }

    .booking-card { margin-bottom: 12px; padding: 16px; }
    .booking-info { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
    .booking-info strong { font-size: 15px; }
    .dates { color: #666; font-size: 13px; margin-top: 4px; }
    .booking-right { display: flex; align-items: center; }

    @media (max-width: 960px) {
      .features-grid, .stats-grid { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 600px) {
      .features-grid, .stats-grid { grid-template-columns: 1fr; }
      .hero-content h1 { font-size: 24px; }
      .booking-info { flex-direction: column; align-items: flex-start; }
    }
  `]
})
export class HomeComponent implements OnInit {
  upcomingBookings: Booking[] = [];
  upcomingCount = 0;
  pastCount = 0;

  features = [
    { icon: 'king_bed', title: 'Luxury Rooms', desc: 'Standard, Deluxe, Suite & Presidential rooms for every need' },
    { icon: 'room_service', title: '24/7 Room Service', desc: 'Round-the-clock service to meet all your needs' },
    { icon: 'pool', title: 'World-Class Amenities', desc: 'Pool, Spa, Gym, Restaurant and more' },
    { icon: 'security', title: 'Secure & Safe', desc: '24/7 security and safety protocols for your peace of mind' }
  ];

  constructor(public auth: AuthService, private bookingService: BookingService) {}

  ngOnInit(): void {
    if (this.auth.isCustomer) {
      this.bookingService.getUpcomingBookings().subscribe(b => {
        this.upcomingBookings = b;
        this.upcomingCount = b.length;
      });
      this.bookingService.getPastBookings().subscribe(b => this.pastCount = b.length);
    }
  }
}
