import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { BookingService } from '../../../services/booking.service';
import { PaymentService } from '../../../services/payment.service';
import { NotificationService } from '../../../services/notification.service';
import { Booking, Payment } from '../../../models/models';

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule,
    MatButtonModule, MatCardModule, MatIconModule, MatSelectModule, MatProgressSpinnerModule, MatDividerModule],
  template: `
    <div class="page-container">
      <h1 class="page-title">Payment</h1>

      <!-- Success state -->
      <mat-card class="result-card success" *ngIf="paymentResult && paymentResult.paymentStatus === 'SUCCESS'">
        <mat-icon class="result-icon">check_circle</mat-icon>
        <h2>Payment Successful!</h2>
        <div class="result-details">
          <p><strong>Booking ID:</strong> {{ paymentResult.bookingId }}</p>
          <p><strong>Transaction ID:</strong> {{ paymentResult.transactionId }}</p>
          <p><strong>Amount Paid:</strong> ₹{{ paymentResult.amountPaid | number:'1.0-0' }}</p>
          <p><strong>Payment Method:</strong> {{ paymentResult.paymentMethod }}</p>
        </div>
        <div class="result-actions">
          <button mat-raised-button color="primary" (click)="downloadInvoice()">
            <mat-icon>download</mat-icon> Download Invoice
          </button>
          <button mat-stroked-button routerLink="/my-bookings">My Bookings</button>
        </div>
      </mat-card>

      <!-- Failure state -->
      <mat-card class="result-card failure" *ngIf="paymentResult && paymentResult.paymentStatus === 'FAILED'">
        <mat-icon class="result-icon">cancel</mat-icon>
        <h2>Payment Failed</h2>
        <p>{{ paymentResult.failureReason }}</p>
        <div class="result-actions">
          <button mat-raised-button color="primary" (click)="paymentResult = null">Try Again</button>
          <button mat-stroked-button routerLink="/my-bookings">My Bookings</button>
        </div>
      </mat-card>

      <div class="payment-layout" *ngIf="!paymentResult && booking">
        <!-- Booking summary -->
        <mat-card class="booking-summary">
          <h3>Booking Summary</h3>
          <div class="summary-row"><span>Booking ID</span><strong>{{ booking.bookingId }}</strong></div>
          <div class="summary-row"><span>Room</span><strong>{{ booking.roomType }} - {{ booking.roomNumber }}</strong></div>
          <div class="summary-row"><span>Check-in</span><strong>{{ booking.checkInDate | date:'mediumDate' }}</strong></div>
          <div class="summary-row"><span>Check-out</span><strong>{{ booking.checkOutDate | date:'mediumDate' }}</strong></div>
          <div class="summary-row"><span>Nights</span><strong>{{ booking.totalNights }}</strong></div>
          <div class="summary-row"><span>Guests</span><strong>{{ booking.adults }} Adults, {{ booking.children }} Children</strong></div>
          <mat-divider style="margin:12px 0"></mat-divider>
          <div class="summary-row"><span>Room Charges</span><span>₹{{ booking.totalAmount | number:'1.0-0' }}</span></div>
          <div class="summary-row"><span>GST (18%)</span><span>₹{{ booking.taxAmount | number:'1.0-0' }}</span></div>
          <div class="summary-row total"><span>Grand Total</span><strong>₹{{ booking.grandTotal | number:'1.0-0' }}</strong></div>
        </mat-card>

        <!-- Payment form -->
        <mat-card class="payment-form-card">
          <h3>Card Payment Details</h3>
          <div class="security-badge"><mat-icon>lock</mat-icon> Secure Payment - 256-bit SSL</div>

          <form [formGroup]="form" (ngSubmit)="onPay()">
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Cardholder Name</mat-label>
              <input matInput formControlName="cardholderName" placeholder="As on card">
              <mat-icon matSuffix>person</mat-icon>
              <mat-error *ngIf="f['cardholderName'].errors?.['required']">Required</mat-error>
              <mat-error *ngIf="f['cardholderName'].errors?.['pattern']">Alphabets only</mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Card Number</mat-label>
              <input matInput formControlName="cardNumber" placeholder="1234 5678 9012 3456"
                     maxlength="16" (input)="formatCard($event)">
              <mat-icon matSuffix>credit_card</mat-icon>
              <mat-error *ngIf="f['cardNumber'].errors?.['pattern']">Must be 16 digits</mat-error>
            </mat-form-field>

            <div class="card-row">
              <mat-form-field appearance="outline">
                <mat-label>Expiry (MM/YY)</mat-label>
                <input matInput formControlName="expiryDate" placeholder="MM/YY" maxlength="5" (input)="formatExpiry($event)">
                <mat-error *ngIf="f['expiryDate'].errors?.['pattern']">Format MM/YY</mat-error>
              </mat-form-field>
              <mat-form-field appearance="outline">
                <mat-label>CVV</mat-label>
                <input matInput formControlName="cvv" type="password" maxlength="4" placeholder="***">
                <mat-error *ngIf="f['cvv'].errors?.['pattern']">3-4 digits</mat-error>
              </mat-form-field>
            </div>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Payment Method</mat-label>
              <mat-select formControlName="paymentMethod">
                <mat-option value="CREDIT_CARD">Credit Card</mat-option>
                <mat-option value="DEBIT_CARD">Debit Card</mat-option>
                <mat-option value="NET_BANKING">Net Banking</mat-option>
              </mat-select>
            </mat-form-field>

            <div class="disclaimer">
              <mat-icon>info</mat-icon>
              <small>This is a simulated payment. No real money is charged.</small>
            </div>

            <button mat-raised-button color="primary" type="submit"
                    [disabled]="form.invalid || loading" class="pay-btn">
              <mat-spinner diameter="20" *ngIf="loading"></mat-spinner>
              <span *ngIf="!loading"><mat-icon>lock</mat-icon> Pay ₹{{ booking.grandTotal | number:'1.0-0' }}</span>
            </button>
          </form>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .payment-layout { display: grid; grid-template-columns: 1fr 1.5fr; gap: 24px; }
    .booking-summary { padding: 20px; }
    .booking-summary h3 { margin-bottom: 16px; color: #3f51b5; font-size: 18px; }
    .summary-row { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 14px; }
    .summary-row span:first-child { color: #666; }
    .summary-row.total { font-size: 16px; border-top: 2px solid #3f51b5; padding-top: 10px; margin-top: 4px; }
    .payment-form-card { padding: 20px; }
    .payment-form-card h3 { margin-bottom: 8px; color: #3f51b5; font-size: 18px; }
    .security-badge { display: flex; align-items: center; gap: 4px; color: #43a047; font-size: 13px; margin-bottom: 16px; }
    .full-width { width: 100%; margin-bottom: 8px; }
    .card-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .disclaimer { display: flex; align-items: center; gap: 8px; color: #ff8f00; font-size: 12px; margin-bottom: 16px; }
    .pay-btn { width: 100%; height: 52px; font-size: 16px; display: flex; align-items: center; justify-content: center; gap: 8px; }
    .result-card { text-align: center; padding: 40px; max-width: 500px; margin: 40px auto; }
    .result-card.success .result-icon { font-size: 72px; width: 72px; height: 72px; color: #4caf50; }
    .result-card.failure .result-icon { font-size: 72px; width: 72px; height: 72px; color: #f44336; }
    .result-card h2 { font-size: 26px; margin: 16px 0; }
    .result-details { background: #f5f5f5; border-radius: 8px; padding: 16px; margin: 16px 0; text-align: left; }
    .result-details p { margin-bottom: 6px; font-size: 14px; }
    .result-actions { display: flex; gap: 12px; justify-content: center; margin-top: 20px; }

    @media (max-width: 768px) {
      .payment-layout { grid-template-columns: 1fr; }
      .card-row { grid-template-columns: 1fr; }
    }
  `],
})
export class PaymentComponent implements OnInit {
  form: FormGroup;
  booking: Booking | null = null;
  paymentResult: Payment | null = null;
  loading = false;

  constructor(private fb: FormBuilder, private route: ActivatedRoute,
              private router: Router, private bookingService: BookingService,
              private paymentService: PaymentService, private notify: NotificationService) {
    this.form = this.fb.group({
      cardholderName: ['', [Validators.required, Validators.pattern(/^[a-zA-Z ]+$/)]],
      cardNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{16}$/)]],
      expiryDate: ['', [Validators.required, Validators.pattern(/^(0[1-9]|1[0-2])\/[0-9]{2}$/)]],
      cvv: ['', [Validators.required, Validators.pattern(/^[0-9]{3,4}$/)]],
      paymentMethod: ['CREDIT_CARD', Validators.required]
    });
  }

  ngOnInit(): void {
    const bookingId = this.route.snapshot.params['bookingId'];
    this.bookingService.getBookingById(bookingId).subscribe({
      next: b => this.booking = b,
      error: () => { this.notify.error('Booking not found'); this.router.navigate(['/my-bookings']); }
    });
  }

  get f() { return this.form.controls; }

  formatCard(e: Event): void {
    const input = e.target as HTMLInputElement;
    input.value = input.value.replace(/\D/g, '');
  }

  formatExpiry(e: Event): void {
    const input = e.target as HTMLInputElement;
    let v = input.value.replace(/\D/g, '');
    if (v.length >= 2) v = v.slice(0,2) + '/' + v.slice(2,4);
    input.value = v;
    this.form.get('expiryDate')!.setValue(v, { emitEvent: false });
  }

  onPay(): void {
    if (this.form.invalid || !this.booking) return;
    this.loading = true;
    const payload = { ...this.form.value, bookingId: this.booking.bookingId };
    this.paymentService.processPayment(payload).subscribe({
      next: (result) => {
        this.loading = false;
        this.paymentResult = result;
        if (result.paymentStatus === 'SUCCESS') {
          this.notify.success('Payment successful!');
        } else {
          this.notify.error('Payment failed. Please try again.');
        }
      },
      error: (err) => {
        this.loading = false;
        this.notify.error(err.error?.message || 'Payment failed');
      }
    });
  }

  downloadInvoice(): void {
    if (this.paymentResult) {
      this.paymentService.downloadInvoice(this.paymentResult.bookingId);
    }
  }
}
