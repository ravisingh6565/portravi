import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { BookingService } from '../../../services/booking.service';
import { PaymentService } from '../../../services/payment.service';
import { NotificationService } from '../../../services/notification.service';
import { Booking } from '../../../models/models';

@Component({
  selector: 'app-my-bookings',
  standalone: true,
  imports: [CommonModule, RouterLink, MatCardModule, MatButtonModule, MatIconModule,
    MatTabsModule, MatProgressSpinnerModule, MatDialogModule],
  template: `
    <div class="page-container">
      <h1 class="page-title">My Bookings</h1>

      <mat-tab-group>
        <mat-tab label="Upcoming ({{ upcoming.length }})">
          <div class="bookings-list">
            <div *ngIf="loading" class="loading-center"><mat-spinner></mat-spinner></div>
            <mat-card class="booking-card" *ngFor="let b of upcoming">
              <div class="booking-header">
                <div>
                  <h3>{{ b.roomType }} Room - {{ b.roomNumber }}</h3>
                  <p class="booking-id">Booking ID: {{ b.bookingId }}</p>
                </div>
                <span class="status-badge status-{{ b.bookingStatus }}">{{ b.bookingStatus }}</span>
              </div>
              <div class="booking-body">
                <div class="info-grid">
                  <div class="info-item">
                    <mat-icon>event</mat-icon>
                    <div>
                      <small>Check-in</small>
                      <strong>{{ b.checkInDate | date:'mediumDate' }}</strong>
                    </div>
                  </div>
                  <div class="info-item">
                    <mat-icon>event</mat-icon>
                    <div>
                      <small>Check-out</small>
                      <strong>{{ b.checkOutDate | date:'mediumDate' }}</strong>
                    </div>
                  </div>
                  <div class="info-item">
                    <mat-icon>nights_stay</mat-icon>
                    <div>
                      <small>Nights</small>
                      <strong>{{ b.totalNights }}</strong>
                    </div>
                  </div>
                  <div class="info-item">
                    <mat-icon>payments</mat-icon>
                    <div>
                      <small>Total</small>
                      <strong>₹{{ b.grandTotal | number:'1.0-0' }}</strong>
                    </div>
                  </div>
                </div>
              </div>
              <div class="booking-actions">
                <button mat-stroked-button color="primary" [routerLink]="['/bookings', b.bookingId]">
                  <mat-icon>visibility</mat-icon> View
                </button>
                <button mat-stroked-button color="accent" [routerLink]="['/bookings', b.bookingId]"
                        *ngIf="canModify(b) && b.bookingStatus !== 'CANCELLED'">
                  <mat-icon>edit</mat-icon> Modify
                </button>
                <button mat-stroked-button color="warn" (click)="cancelBooking(b)"
                        *ngIf="b.bookingStatus !== 'CANCELLED'">
                  <mat-icon>cancel</mat-icon> Cancel
                </button>
                <button mat-stroked-button (click)="downloadInvoice(b.bookingId)"
                        *ngIf="b.paymentStatus === 'SUCCESS'">
                  <mat-icon>download</mat-icon> Invoice
                </button>
              </div>
            </mat-card>
            <div class="empty-state" *ngIf="!loading && upcoming.length === 0">
              <mat-icon>hotel</mat-icon>
              <p>No upcoming bookings</p>
              <button mat-raised-button color="primary" routerLink="/search-rooms">Search Rooms</button>
            </div>
          </div>
        </mat-tab>

        <mat-tab label="Past ({{ past.length }})">
          <div class="bookings-list">
            <mat-card class="booking-card" *ngFor="let b of past">
              <div class="booking-header">
                <div>
                  <h3>{{ b.roomType }} Room - {{ b.roomNumber }}</h3>
                  <p class="booking-id">Booking ID: {{ b.bookingId }}</p>
                </div>
                <span class="status-badge status-{{ b.bookingStatus }}">{{ b.bookingStatus }}</span>
              </div>
              <div class="booking-body">
                <div class="info-grid">
                  <div class="info-item">
                    <mat-icon>event</mat-icon>
                    <div><small>Check-in</small><strong>{{ b.checkInDate | date:'mediumDate' }}</strong></div>
                  </div>
                  <div class="info-item">
                    <mat-icon>event</mat-icon>
                    <div><small>Check-out</small><strong>{{ b.checkOutDate | date:'mediumDate' }}</strong></div>
                  </div>
                  <div class="info-item">
                    <mat-icon>payments</mat-icon>
                    <div><small>Total</small><strong>₹{{ b.grandTotal | number:'1.0-0' }}</strong></div>
                  </div>
                  <div class="info-item" *ngIf="b.refundAmount">
                    <mat-icon>undo</mat-icon>
                    <div><small>Refund</small><strong>₹{{ b.refundAmount | number:'1.0-0' }}</strong></div>
                  </div>
                </div>
              </div>
              <div class="booking-actions">
                <button mat-stroked-button color="primary" [routerLink]="['/bookings', b.bookingId]">
                  <mat-icon>visibility</mat-icon> View
                </button>
                <button mat-stroked-button (click)="downloadInvoice(b.bookingId)"
                        *ngIf="b.paymentStatus === 'SUCCESS'">
                  <mat-icon>download</mat-icon> Invoice
                </button>
              </div>
            </mat-card>
            <div class="empty-state" *ngIf="past.length === 0">
              <mat-icon>history</mat-icon>
              <p>No past bookings</p>
            </div>
          </div>
        </mat-tab>
      </mat-tab-group>
    </div>
  `,
  styles: [`
    .bookings-list { padding: 16px 0; }
    .booking-card { margin-bottom: 16px; padding: 20px; }
    .booking-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px; }
    .booking-header h3 { font-size: 16px; margin: 0 0 4px; }
    .booking-id { font-size: 12px; color: #666; }
    .info-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 16px; }
    .info-item { display: flex; align-items: center; gap: 8px; }
    .info-item mat-icon { color: #3f51b5; }
    .info-item small { display: block; font-size: 11px; color: #666; }
    .info-item strong { display: block; font-size: 14px; }
    .booking-actions { display: flex; gap: 8px; flex-wrap: wrap; }
    .empty-state { text-align: center; padding: 60px; color: #999; }
    .empty-state mat-icon { font-size: 60px; width: 60px; height: 60px; display: block; margin: 0 auto 16px; }
    .loading-center { display: flex; justify-content: center; padding: 40px; }

    @media (max-width: 768px) {
      .info-grid { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 480px) {
      .info-grid { grid-template-columns: 1fr 1fr; }
    }
  `]
})
export class MyBookingsComponent implements OnInit {
  upcoming: Booking[] = [];
  past: Booking[] = [];
  loading = true;

  constructor(private bookingService: BookingService, private paymentService: PaymentService,
              private notify: NotificationService) {}

  ngOnInit(): void {
    this.loadBookings();
  }

  loadBookings(): void {
    this.loading = true;
    this.bookingService.getUpcomingBookings().subscribe(b => { this.upcoming = b; this.loading = false; });
    this.bookingService.getPastBookings().subscribe(b => this.past = b);
  }

  canModify(b: Booking): boolean {
    if (b.bookingStatus === 'CANCELLED') return false;
    const checkIn = new Date(b.checkInDate);
    const now = new Date();
    const diff = (checkIn.getTime() - now.getTime()) / (1000 * 60 * 60);
    return diff > 24;
  }

  cancelBooking(b: Booking): void {
    if (!confirm(`Cancel booking ${b.bookingId}?`)) return;
    this.bookingService.cancelBooking(b.bookingId).subscribe({
      next: (updated) => {
        this.notify.success(`Booking cancelled. Refund: ₹${updated.refundAmount || 0}`);
        this.loadBookings();
      },
      error: (err) => this.notify.error(err.error?.message || 'Cancellation failed')
    });
  }

  downloadInvoice(bookingId: string): void {
    this.paymentService.downloadInvoice(bookingId);
  }
}
