import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { BookingService } from '../../../services/booking.service';
import { PaymentService } from '../../../services/payment.service';
import { NotificationService } from '../../../services/notification.service';
import { Booking } from '../../../models/models';

@Component({
  selector: 'app-booking-detail',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, MatCardModule, MatButtonModule,
    MatIconModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatExpansionModule, MatProgressSpinnerModule],
  template: `
    <div class="page-container" *ngIf="booking">
      <div class="detail-header">
        <button mat-icon-button routerLink="/my-bookings"><mat-icon>arrow_back</mat-icon></button>
        <h1 class="page-title">Booking Details</h1>
      </div>

      <div class="detail-layout">
        <div class="main-info">
          <mat-card class="info-card">
            <h3>Booking Information</h3>
            <div class="info-grid">
              <div class="info-item"><span>Booking ID</span><strong>{{ booking.bookingId }}</strong></div>
              <div class="info-item"><span>Status</span>
                <span class="status-badge status-{{ booking.bookingStatus }}">{{ booking.bookingStatus }}</span>
              </div>
              <div class="info-item"><span>Room</span><strong>{{ booking.roomType }} - {{ booking.roomNumber }}</strong></div>
              <div class="info-item"><span>Check-in</span><strong>{{ booking.checkInDate | date:'fullDate' }}</strong></div>
              <div class="info-item"><span>Check-out</span><strong>{{ booking.checkOutDate | date:'fullDate' }}</strong></div>
              <div class="info-item"><span>Nights</span><strong>{{ booking.totalNights }}</strong></div>
              <div class="info-item"><span>Adults</span><strong>{{ booking.adults }}</strong></div>
              <div class="info-item"><span>Children</span><strong>{{ booking.children }}</strong></div>
              <div class="info-item" *ngIf="booking.specialRequest"><span>Special Request</span><strong>{{ booking.specialRequest }}</strong></div>
            </div>
          </mat-card>

          <mat-card class="info-card" *ngIf="booking.transactionId">
            <h3>Payment Information</h3>
            <div class="info-grid">
              <div class="info-item"><span>Transaction ID</span><strong>{{ booking.transactionId }}</strong></div>
              <div class="info-item"><span>Payment Method</span><strong>{{ booking.paymentMethod }}</strong></div>
              <div class="info-item"><span>Payment Status</span>
                <span class="status-badge status-{{ booking.paymentStatus }}">{{ booking.paymentStatus }}</span>
              </div>
            </div>
          </mat-card>

          <!-- Modify form -->
          <mat-expansion-panel *ngIf="canModify">
            <mat-expansion-panel-header>
              <mat-panel-title><mat-icon>edit</mat-icon> Modify Reservation</mat-panel-title>
            </mat-expansion-panel-header>
            <form [formGroup]="modifyForm" (ngSubmit)="onModify()">
              <div class="form-row">
                <mat-form-field appearance="outline">
                  <mat-label>New Check-in</mat-label>
                  <input matInput type="date" formControlName="checkInDate" [min]="minDate">
                </mat-form-field>
                <mat-form-field appearance="outline">
                  <mat-label>New Check-out</mat-label>
                  <input matInput type="date" formControlName="checkOutDate">
                </mat-form-field>
              </div>
              <mat-form-field appearance="outline" style="width:100%">
                <mat-label>Special Request</mat-label>
                <textarea matInput formControlName="specialRequest" rows="2"></textarea>
              </mat-form-field>
              <button mat-raised-button color="primary" type="submit" [disabled]="modifyForm.invalid || modifying">
                <mat-spinner diameter="16" *ngIf="modifying"></mat-spinner>
                Save Changes
              </button>
            </form>
          </mat-expansion-panel>

          <div class="cutoff-warning" *ngIf="!canModify && booking.bookingStatus !== 'CANCELLED'">
            <mat-icon>warning</mat-icon>
            <span>Modification not allowed within 24 hours of check-in</span>
          </div>
        </div>

        <div class="side-info">
          <mat-card class="cost-card">
            <h3>Cost Breakdown</h3>
            <div class="cost-row"><span>Room Charges</span><span>₹{{ booking.totalAmount | number:'1.0-0' }}</span></div>
            <div class="cost-row"><span>GST (18%)</span><span>₹{{ booking.taxAmount | number:'1.0-0' }}</span></div>
            <div class="cost-row total"><span>Grand Total</span><strong>₹{{ booking.grandTotal | number:'1.0-0' }}</strong></div>
            <div class="cost-row refund" *ngIf="booking.refundAmount">
              <span>Refund Amount</span><span>₹{{ booking.refundAmount | number:'1.0-0' }}</span>
            </div>
          </mat-card>

          <div class="action-btns">
            <button mat-raised-button color="primary" (click)="downloadInvoice()"
                    *ngIf="booking.paymentStatus === 'SUCCESS'">
              <mat-icon>download</mat-icon> Download Invoice
            </button>
            <button mat-raised-button color="warn" (click)="cancel()"
                    *ngIf="booking.bookingStatus !== 'CANCELLED'">
              <mat-icon>cancel</mat-icon> Cancel Booking
            </button>
            <button mat-stroked-button [routerLink]="['/payment', booking.bookingId]"
                    *ngIf="booking.bookingStatus === 'PENDING' && !booking.transactionId">
              <mat-icon>payment</mat-icon> Complete Payment
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .detail-header { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
    .detail-layout { display: grid; grid-template-columns: 1.5fr 1fr; gap: 24px; }
    .info-card { padding: 20px; margin-bottom: 16px; }
    .info-card h3 { color: #3f51b5; margin-bottom: 16px; font-size: 16px; }
    .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .info-item { }
    .info-item span { font-size: 12px; color: #666; display: block; }
    .info-item strong { font-size: 14px; }
    .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 8px; }
    .cutoff-warning { display: flex; align-items: center; gap: 8px; color: #f57f17; background: #fff8e1; padding: 12px; border-radius: 8px; }
    .cost-card { padding: 20px; margin-bottom: 16px; }
    .cost-card h3 { color: #3f51b5; margin-bottom: 16px; }
    .cost-row { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px; }
    .cost-row.total { border-top: 2px solid #3f51b5; padding-top: 8px; font-size: 16px; font-weight: 700; }
    .cost-row.refund { color: #43a047; }
    .action-btns { display: flex; flex-direction: column; gap: 12px; }
    .action-btns button { height: 44px; }

    @media (max-width: 768px) {
      .detail-layout { grid-template-columns: 1fr; }
      .info-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class BookingDetailComponent implements OnInit {
  booking: Booking | null = null;
  modifyForm: FormGroup;
  canModify = false;
  modifying = false;
  minDate = '';

  constructor(private route: ActivatedRoute, private router: Router,
              private bookingService: BookingService, private paymentService: PaymentService,
              private notify: NotificationService, private fb: FormBuilder) {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    this.minDate = tomorrow.toISOString().split('T')[0];
    this.modifyForm = this.fb.group({
      checkInDate: ['', Validators.required],
      checkOutDate: ['', Validators.required],
      adults: [1],
      children: [0],
      specialRequest: [''],
      paymentMethod: ['CREDIT_CARD']
    });
  }

  ngOnInit(): void {
    const id = this.route.snapshot.params['id'];
    this.bookingService.getBookingById(id).subscribe({
      next: b => {
        this.booking = b;
        this.modifyForm.patchValue({
          checkInDate: b.checkInDate,
          checkOutDate: b.checkOutDate,
          adults: b.adults,
          children: b.children,
          specialRequest: b.specialRequest
        });
        const checkIn = new Date(b.checkInDate);
        const now = new Date();
        const diff = (checkIn.getTime() - now.getTime()) / (1000 * 60 * 60);
        this.canModify = diff > 24 && b.bookingStatus !== 'CANCELLED';
      },
      error: () => { this.notify.error('Booking not found'); this.router.navigate(['/my-bookings']); }
    });
  }

  onModify(): void {
    if (!this.booking) return;
    this.modifying = true;
    this.bookingService.modifyBooking(this.booking.bookingId, this.modifyForm.value).subscribe({
      next: b => {
        this.booking = b;
        this.modifying = false;
        this.notify.success('Booking modified successfully');
      },
      error: (err) => {
        this.modifying = false;
        this.notify.error(err.error?.message || 'Modification failed');
      }
    });
  }

  cancel(): void {
    if (!this.booking || !confirm('Cancel this booking?')) return;
    this.bookingService.cancelBooking(this.booking.bookingId).subscribe({
      next: b => {
        this.booking = b;
        this.notify.success(`Booking cancelled. Refund: ₹${b.refundAmount || 0}`);
      },
      error: (err) => this.notify.error(err.error?.message || 'Cancellation failed')
    });
  }

  downloadInvoice(): void {
    if (this.booking) this.paymentService.downloadInvoice(this.booking.bookingId);
  }
}
