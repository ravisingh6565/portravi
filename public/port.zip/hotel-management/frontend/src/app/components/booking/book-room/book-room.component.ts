import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { RoomService } from '../../../services/room.service';
import { BookingService } from '../../../services/booking.service';
import { AuthService } from '../../../services/auth.service';
import { NotificationService } from '../../../services/notification.service';
import { Room } from '../../../models/models';

@Component({
  selector: 'app-book-room',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule,
    MatButtonModule, MatCardModule, MatIconModule, MatSelectModule, MatProgressSpinnerModule],
  template: `
    <div class="page-container">
      <h1 class="page-title">Book Room</h1>

      <div class="booking-layout" *ngIf="room">
        <mat-card class="room-summary">
          <img class="room-img" src="assets/hotel-room.jpg" [alt]="room.roomType" (error)="onImgErr($event)">
          <mat-card-content>
            <h2>{{ room.roomType }} Room</h2>
            <p class="room-num">Room {{ room.roomNumber }} | Floor {{ room.floorNumber }}</p>
            <div class="amenities">{{ room.amenities }}</div>
            <div class="price-display">
              <span class="price-label">Price per night</span>
              <span class="price-value">₹{{ room.pricePerNight | number:'1.0-0' }}</span>
            </div>
            <div class="cost-breakdown" *ngIf="totalNights > 0">
              <div class="cost-row">
                <span>{{ totalNights }} night(s) × ₹{{ room.pricePerNight }}</span>
                <span>₹{{ roomCharges | number:'1.0-0' }}</span>
              </div>
              <div class="cost-row">
                <span>GST (18%)</span>
                <span>₹{{ taxAmount | number:'1.0-0' }}</span>
              </div>
              <div class="cost-row total">
                <span>Total</span>
                <span>₹{{ grandTotal | number:'1.0-0' }}</span>
              </div>
            </div>
          </mat-card-content>
        </mat-card>

        <mat-card class="booking-form-card">
          <mat-card-header>
            <mat-card-title>Booking Details</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <form [formGroup]="form" (ngSubmit)="onSubmit()">
              <div class="prefilled">
                <div class="info-row">
                  <mat-icon>person</mat-icon>
                  <span><strong>Guest:</strong> {{ auth.currentUser?.customerName }}</span>
                </div>
                <div class="info-row">
                  <mat-icon>email</mat-icon>
                  <span><strong>Email:</strong> {{ auth.currentUser?.email }}</span>
                </div>
              </div>

              <div class="date-row">
                <mat-form-field appearance="outline">
                  <mat-label>Check-in Date</mat-label>
                  <input matInput formControlName="checkInDate" type="date" [min]="minDate">
                  <mat-error>Required</mat-error>
                </mat-form-field>
                <mat-form-field appearance="outline">
                  <mat-label>Check-out Date</mat-label>
                  <input matInput formControlName="checkOutDate" type="date" [min]="minCheckOut">
                  <mat-error>Required</mat-error>
                </mat-form-field>
              </div>

              <div class="nights-display" *ngIf="totalNights > 0">
                <mat-icon>nights_stay</mat-icon> {{ totalNights }} Night(s)
              </div>

              <div class="date-row">
                <mat-form-field appearance="outline">
                  <mat-label>Adults</mat-label>
                  <mat-select formControlName="adults">
                    <mat-option *ngFor="let i of range(1, room.maxAdults+1)" [value]="i">{{ i }}</mat-option>
                  </mat-select>
                </mat-form-field>
                <mat-form-field appearance="outline">
                  <mat-label>Children</mat-label>
                  <mat-select formControlName="children">
                    <mat-option *ngFor="let i of range(0, room.maxChildren+1)" [value]="i">{{ i }}</mat-option>
                  </mat-select>
                </mat-form-field>
              </div>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Special Request (optional)</mat-label>
                <textarea matInput formControlName="specialRequest" rows="3"
                          placeholder="Any special requirements..."></textarea>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Payment Method</mat-label>
                <mat-select formControlName="paymentMethod">
                  <mat-option value="CREDIT_CARD">Credit Card</mat-option>
                  <mat-option value="DEBIT_CARD">Debit Card</mat-option>
                  <mat-option value="NET_BANKING">Net Banking</mat-option>
                </mat-select>
              </mat-form-field>

              <button mat-raised-button color="primary" type="submit"
                      [disabled]="form.invalid || loading || totalNights <= 0" class="proceed-btn">
                <mat-spinner diameter="20" *ngIf="loading"></mat-spinner>
                <span *ngIf="!loading">Proceed to Pay — ₹{{ grandTotal | number:'1.0-0' }}</span>
              </button>
            </form>
          </mat-card-content>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .booking-layout { display: grid; grid-template-columns: 1fr 1.5fr; gap: 24px; }
    .room-summary { overflow: hidden; }
    .room-img { width: 100%; height: 200px; object-fit: cover; }
    .room-summary mat-card-content { padding: 16px; }
    .room-summary h2 { font-size: 20px; margin-bottom: 4px; }
    .room-num { color: #666; font-size: 13px; margin-bottom: 8px; }
    .amenities { font-size: 12px; color: #555; padding: 8px; background: #f5f5f5; border-radius: 4px; margin-bottom: 12px; }
    .price-display { display: flex; justify-content: space-between; margin-bottom: 12px; }
    .price-label { color: #666; }
    .price-value { font-size: 20px; font-weight: 700; color: #3f51b5; }
    .cost-breakdown { border-top: 1px solid #eee; padding-top: 12px; }
    .cost-row { display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 14px; }
    .cost-row.total { font-weight: 700; font-size: 16px; border-top: 1px solid #eee; padding-top: 8px; margin-top: 4px; color: #3f51b5; }
    .prefilled { background: #f0f4ff; border-radius: 8px; padding: 12px; margin-bottom: 16px; }
    .info-row { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; font-size: 14px; }
    .info-row mat-icon { font-size: 16px; color: #3f51b5; }
    .date-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .full-width { width: 100%; }
    .nights-display { display: flex; align-items: center; gap: 4px; color: #3f51b5; font-weight: 500; margin: -8px 0 8px; }
    .proceed-btn { width: 100%; height: 52px; font-size: 16px; display: flex; align-items: center; justify-content: center; gap: 8px; }

    @media (max-width: 768px) {
      .booking-layout { grid-template-columns: 1fr; }
      .date-row { grid-template-columns: 1fr; }
    }
  `]
})
export class BookRoomComponent implements OnInit {
  form: FormGroup;
  room: Room | null = null;
  loading = false;
  minDate = '';
  minCheckOut = '';
  totalNights = 0;
  roomCharges = 0;
  taxAmount = 0;
  grandTotal = 0;

  constructor(private fb: FormBuilder, private route: ActivatedRoute,
              private router: Router, private roomService: RoomService,
              private bookingService: BookingService, public auth: AuthService,
              private notify: NotificationService) {
    const today = new Date();
    today.setDate(today.getDate() + 1);
    this.minDate = today.toISOString().split('T')[0];

    this.form = this.fb.group({
      checkInDate: [this.route.snapshot.queryParams['checkIn'] || '', Validators.required],
      checkOutDate: [this.route.snapshot.queryParams['checkOut'] || '', Validators.required],
      adults: [+(this.route.snapshot.queryParams['adults'] || 1), [Validators.required, Validators.min(1)]],
      children: [+(this.route.snapshot.queryParams['children'] || 0)],
      specialRequest: [''],
      paymentMethod: ['CREDIT_CARD', Validators.required]
    });
  }

  ngOnInit(): void {
    const roomId = this.route.snapshot.params['roomId'];
    this.roomService.getRoomById(+roomId).subscribe({
      next: r => { this.room = r; this.calculateCost(); },
      error: () => { this.notify.error('Room not found'); this.router.navigate(['/search-rooms']); }
    });

    this.form.get('checkInDate')!.valueChanges.subscribe(() => this.calculateCost());
    this.form.get('checkOutDate')!.valueChanges.subscribe(() => this.calculateCost());
  }

  calculateCost(): void {
    const ci = this.form.get('checkInDate')!.value;
    const co = this.form.get('checkOutDate')!.value;
    if (ci && co && this.room) {
      const diff = (new Date(co).getTime() - new Date(ci).getTime()) / (1000 * 60 * 60 * 24);
      this.totalNights = diff > 0 ? diff : 0;
      this.roomCharges = this.totalNights * +this.room.pricePerNight;
      this.taxAmount = this.roomCharges * 0.18;
      this.grandTotal = this.roomCharges + this.taxAmount;
    }
  }

  range(start: number, end: number): number[] {
    return Array.from({ length: end - start }, (_, i) => i + start);
  }

  onSubmit(): void {
    if (this.form.invalid || !this.room) return;
    this.loading = true;
    const payload = { ...this.form.value, roomId: this.room.id };
    this.bookingService.createBooking(payload).subscribe({
      next: (booking) => {
        this.loading = false;
        this.notify.success('Booking created! Proceeding to payment...');
        this.router.navigate(['/payment', booking.bookingId]);
      },
      error: (err) => {
        this.loading = false;
        this.notify.error(err.error?.message || 'Booking failed');
      }
    });
  }

  onImgErr(e: Event): void {
    (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MDAiIGhlaWdodD0iMjAwIj48cmVjdCBmaWxsPSIjM2Y1MWI1IiB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIvPjx0ZXh0IGZpbGw9IiNmZmYiIHg9IjUwJSIgeT0iNTAlIiBmb250LXNpemU9IjI0IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+SG90ZWwgUm9vbTwvdGV4dD48L3N2Zz4=';
  }
}
