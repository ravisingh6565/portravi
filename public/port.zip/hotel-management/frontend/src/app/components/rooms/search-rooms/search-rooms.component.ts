import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatChipsModule } from '@angular/material/chips';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { RoomService } from '../../../services/room.service';
import { AuthService } from '../../../services/auth.service';
import { Room, PageResponse } from '../../../models/models';

@Component({
  selector: 'app-search-rooms',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, MatFormFieldModule, MatInputModule,
    MatButtonModule, MatCardModule, MatIconModule, MatSelectModule, MatDatepickerModule,
    MatNativeDateModule, MatChipsModule, MatPaginatorModule, MatProgressSpinnerModule],
  template: `
    <div class="page-container">
      <h1 class="page-title">Search Room Availability</h1>

      <mat-card class="search-card">
        <form [formGroup]="searchForm" (ngSubmit)="onSearch()">
          <div class="search-grid">
            <mat-form-field appearance="outline">
              <mat-label>Check-in Date</mat-label>
              <input matInput [matDatepicker]="checkInPicker" formControlName="checkIn" [min]="tomorrow">
              <mat-datepicker-toggle matSuffix [for]="checkInPicker"></mat-datepicker-toggle>
              <mat-datepicker #checkInPicker></mat-datepicker>
              <mat-error>Check-in date is required (future only)</mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Check-out Date</mat-label>
              <input matInput [matDatepicker]="checkOutPicker" formControlName="checkOut" [min]="minCheckOut">
              <mat-datepicker-toggle matSuffix [for]="checkOutPicker"></mat-datepicker-toggle>
              <mat-datepicker #checkOutPicker></mat-datepicker>
              <mat-error>Check-out must be after check-in</mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Adults</mat-label>
              <mat-select formControlName="adults">
                <mat-option *ngFor="let i of [1,2,3,4,5,6,7,8,9,10]" [value]="i">{{ i }}</mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Children</mat-label>
              <mat-select formControlName="children">
                <mat-option *ngFor="let i of [0,1,2,3,4,5]" [value]="i">{{ i }}</mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Room Type</mat-label>
              <mat-select formControlName="roomType">
                <mat-option value="">Any</mat-option>
                <mat-option *ngFor="let t of roomTypes" [value]="t">{{ t }}</mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Sort By</mat-label>
              <mat-select formControlName="sort">
                <mat-option value="pricePerNight,asc">Price: Low to High</mat-option>
                <mat-option value="pricePerNight,desc">Price: High to Low</mat-option>
                <mat-option value="roomType,asc">Room Type</mat-option>
              </mat-select>
            </mat-form-field>
          </div>

          <button mat-raised-button color="primary" type="submit" [disabled]="loading" class="search-btn">
            <mat-icon>search</mat-icon> Search Rooms
          </button>
        </form>
      </mat-card>

      <div class="search-results" *ngIf="searched">
        <div class="results-header">
          <h2>{{ loading ? 'Searching...' : totalRooms + ' Room(s) Found' }}</h2>
        </div>

        <div *ngIf="loading" class="loading-center">
          <mat-spinner></mat-spinner>
        </div>

        <div class="rooms-grid" *ngIf="!loading">
          <mat-card class="room-card" *ngFor="let room of rooms">
            <img class="room-image" src="assets/hotel-room.jpg" [alt]="room.roomType" (error)="onImgError($event)">
            <mat-card-content class="room-content">
              <div class="room-header">
                <h3>{{ room.roomType }} Room</h3>
                <span class="status-badge status-{{ room.roomStatus }}">{{ room.roomStatus }}</span>
              </div>
              <p class="room-number">Room {{ room.roomNumber }} | Floor {{ room.floorNumber }}</p>
              <div class="room-details">
                <span><mat-icon>people</mat-icon> {{ room.maxAdults }} Adults, {{ room.maxChildren }} Children</span>
                <span class="price">₹{{ room.pricePerNight | number:'1.0-0' }}/night</span>
              </div>
              <div class="amenities">
                <mat-icon>wifi</mat-icon>
                <span class="amenities-text">{{ room.amenities }}</span>
              </div>
              <p class="description" *ngIf="room.description">{{ room.description }}</p>
              <div class="total-cost" *ngIf="nights > 0">
                Total for {{ nights }} night(s): <strong>₹{{ (room.pricePerNight * nights * 1.18) | number:'1.0-0' }}</strong> (incl. 18% GST)
              </div>
              <button mat-raised-button color="primary" class="book-btn"
                      [disabled]="room.roomStatus !== 'AVAILABLE'"
                      (click)="bookRoom(room)">
                {{ auth.isLoggedIn ? 'Book Now' : 'Login to Book' }}
              </button>
            </mat-card-content>
          </mat-card>

          <div class="no-results" *ngIf="rooms.length === 0">
            <mat-icon>hotel</mat-icon>
            <p>No rooms available for the selected criteria. Please try different dates.</p>
          </div>
        </div>

        <mat-paginator *ngIf="totalRooms > 0"
                       [length]="totalRooms"
                       [pageSize]="pageSize"
                       [pageSizeOptions]="[5, 10, 20]"
                       (page)="onPageChange($event)">
        </mat-paginator>
      </div>
    </div>
  `,
  styles: [`
    .search-card { margin-bottom: 24px; padding: 24px; }
    .search-grid {
      display: grid; grid-template-columns: repeat(3, 1fr);
      gap: 16px; margin-bottom: 16px;
    }
    .search-btn { height: 48px; font-size: 15px; }
    .results-header { margin-bottom: 16px; }
    .results-header h2 { font-size: 18px; color: #555; }
    .rooms-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
    .room-card { overflow: hidden; }
    .room-image { width: 100%; height: 200px; object-fit: cover; }
    .room-content { padding: 16px; }
    .room-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
    .room-header h3 { font-size: 16px; font-weight: 600; margin: 0; }
    .room-number { color: #666; font-size: 13px; margin-bottom: 8px; }
    .room-details { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
    .room-details mat-icon { font-size: 16px; vertical-align: middle; }
    .room-details span { display: flex; align-items: center; gap: 4px; font-size: 13px; color: #555; }
    .price { font-size: 18px; font-weight: 700; color: #3f51b5; }
    .amenities { display: flex; align-items: center; gap: 4px; margin-bottom: 8px; }
    .amenities mat-icon { font-size: 16px; color: #43a047; }
    .amenities-text { font-size: 12px; color: #666; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .description { font-size: 13px; color: #777; margin-bottom: 8px; }
    .total-cost { font-size: 13px; color: #333; background: #f5f5f5; padding: 8px; border-radius: 4px; margin-bottom: 12px; }
    .book-btn { width: 100%; }
    .loading-center { display: flex; justify-content: center; padding: 60px; }
    .no-results { grid-column: 1/-1; text-align: center; padding: 60px; color: #999; }
    .no-results mat-icon { font-size: 60px; width: 60px; height: 60px; display: block; margin: 0 auto 16px; }

    @media (max-width: 960px) {
      .search-grid { grid-template-columns: 1fr 1fr; }
      .rooms-grid { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 600px) {
      .search-grid { grid-template-columns: 1fr; }
      .rooms-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class SearchRoomsComponent implements OnInit {
  searchForm!: FormGroup;
  rooms: Room[] = [];
  searched = false;
  loading = false;
  totalRooms = 0;
  pageSize = 9;
  currentPage = 0;
  nights = 0;
  tomorrow = new Date();
  minCheckOut = new Date();

  roomTypes = ['STANDARD', 'DELUXE', 'SUITE', 'EXECUTIVE', 'PRESIDENTIAL'];

  constructor(private fb: FormBuilder, private roomService: RoomService,
              public auth: AuthService, private router: Router) {
    this.tomorrow.setDate(this.tomorrow.getDate() + 1);
  }
  get form() { return this.searchForm; }
  set form(v: FormGroup) { this.searchForm = v; }

  ngOnInit(): void {
    this.searchForm = this.fb.group({
      checkIn: [null, Validators.required],
      checkOut: [null, Validators.required],
      adults: [1],
      children: [0],
      roomType: [''],
      sort: ['pricePerNight,asc']
    });

    this.searchForm.get('checkIn')!.valueChanges.subscribe(v => {
      if (v) {
        const d = new Date(v);
        d.setDate(d.getDate() + 1);
        this.minCheckOut = d;
        this.calculateNights();
      }
    });

    this.searchForm.get('checkOut')!.valueChanges.subscribe(() => this.calculateNights());
  }

  calculateNights(): void {
    const ci = this.searchForm.get('checkIn')!.value;
    const co = this.searchForm.get('checkOut')!.value;
    if (ci && co) {
      const diff = (new Date(co).getTime() - new Date(ci).getTime()) / (1000 * 60 * 60 * 24);
      this.nights = diff > 0 ? diff : 0;
    }
  }

  onSearch(page = 0): void {
    if (this.searchForm.invalid) return;
    this.loading = true;
    this.searched = true;
    this.currentPage = page;

    const v = this.searchForm.value;
    const formatDate = (d: Date) => {
      const dd = new Date(d);
      return `${dd.getFullYear()}-${String(dd.getMonth()+1).padStart(2,'0')}-${String(dd.getDate()).padStart(2,'0')}`;
    };

    const params: any = {
      checkIn: formatDate(v.checkIn),
      checkOut: formatDate(v.checkOut),
      adults: v.adults,
      children: v.children,
      page,
      size: this.pageSize,
      sort: v.sort
    };
    if (v.roomType) params.roomType = v.roomType;

    this.roomService.getAvailableRooms(params).subscribe({
      next: (res: PageResponse<Room>) => {
        this.rooms = res.content;
        this.totalRooms = res.totalElements;
        this.loading = false;
      },
      error: () => { this.loading = false; this.rooms = []; }
    });
  }

  onPageChange(e: PageEvent): void {
    this.pageSize = e.pageSize;
    this.onSearch(e.pageIndex);
  }

  bookRoom(room: Room): void {
    if (!this.auth.isLoggedIn) {
      this.router.navigate(['/login'], { queryParams: { returnUrl: `/book/${room.id}` } });
      return;
    }
    const v = this.searchForm.value;
    const formatDate = (d: Date) => {
      const dd = new Date(d);
      return `${dd.getFullYear()}-${String(dd.getMonth()+1).padStart(2,'0')}-${String(dd.getDate()).padStart(2,'0')}`;
    };
    this.router.navigate(['/book', room.id], {
      queryParams: { checkIn: formatDate(v.checkIn), checkOut: formatDate(v.checkOut), adults: v.adults, children: v.children }
    });
  }

  onImgError(e: Event): void {
    (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MDAiIGhlaWdodD0iMjAwIiB2aWV3Qm94PSIwIDAgNDAwIDIwMCI+PHJlY3QgZmlsbD0iIzNmNTFiNSIgd2lkdGg9IjQwMCIgaGVpZ2h0PSIyMDAiLz48dGV4dCBmaWxsPSIjZmZmIiB4PSI1MCUiIHk9IjUwJSIgZm9udC1zaXplPSIyNCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkhvdGVsIFJvb208L3RleHQ+PC9zdmc+';
  }
}
