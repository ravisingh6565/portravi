import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const authGuard: CanActivateFn = (route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (!auth.isLoggedIn) {
    router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }
  return true;
};

export const adminGuard: CanActivateFn = (route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (!auth.isLoggedIn) {
    router.navigate(['/login']);
    return false;
  }
  if (!auth.isAdmin) {
    router.navigate(['/home']);
    return false;
  }
  return true;
};

export const staffGuard: CanActivateFn = (route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (!auth.isLoggedIn) {
    router.navigate(['/login']);
    return false;
  }
  if (!auth.isStaff && !auth.isAdmin) {
    router.navigate(['/home']);
    return false;
  }
  return true;
};

export const guestGuard: CanActivateFn = (route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.isLoggedIn) {
    if (auth.isAdmin) router.navigate(['/admin/dashboard']);
    else if (auth.isStaff) router.navigate(['/staff/complaints']);
    else router.navigate(['/home']);
    return false;
  }
  return true;
};
